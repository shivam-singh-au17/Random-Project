module.exports = {
    MONGODB_URL: "mongodb://127.0.0.1:27017/itax",
    PORT: 3000,
    MINIO: {
        endPoint: "localhost",
        port: 9000,
        useSSL: false,
        accessKey: "minioadmin",
        secretKey: "minioadmin",
        bucketName: "itax",
    },
    // for more options visit this URL  https://nodemailer.com/about/
    MAIL: {
        TRANSPORT: {
            service: "gmail",
            auth: {
                user: "ariantech.development@gmail.com",
                pass: "Ariantech@123",
            },
        },
        SENDERADDRESS: "iTAX",
        ADMINEMAIL: "ariantech.development@gmail.com",
    },
    // for forget password
    HOST : "smtp.gmail.com",
    USER : "ariantech.development@gmail.com",
    PASS : "Ariantech@123",
    SERVICE : "gmail",
};
