const nodemailer = require("nodemailer");
const config = require("../config");
const sendEmail = async (email, subject, text) => {
    try {
        const transporter = nodemailer.createTransport({
            host: config.HOST,
            service: config.SERVICE,
            port: 587,
            secure: true,
            auth: {
                user: config.USER,
                pass: config.PASS,
            },
        });

        return await transporter.sendMail({
            from: config.USER,
            to: email,
            subject: subject,
            text: `Use this OneTimePassword ${ text } for setting up new Password,and kindly make a note that this OTP is valid for maximum 2 minute only!`,
        });
    } catch (error) {
        error.send("An error occured");
    }
};

module.exports = sendEmail;
