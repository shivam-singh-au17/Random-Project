const Minio = require("minio");
const config = require("../config");

// Instantiate the minio client with the endpoint
// and access keys as shown below.
var minioClient = new Minio.Client(config.MINIO);

exports.generateSignedURL = (path) => {
    return new Promise((resolve, reject) => {
        minioClient.presignedPutObject(config.MINIO.bucketName, path, 3600, function (err, url) {
            if (err)
                reject(err);
            else
                resolve({ success: true, path, url });
        });
    });
};

exports.generateReadSignedURL = (path, headers={}) => {
    return new Promise((resolve, reject) => {
        minioClient.presignedGetObject(config.MINIO.bucketName, path, 3600, headers, function (err, url) {
            if (err)
                reject(err);
            else
                resolve({ success: true, path, url });
        });
    });
};

exports.minioClient = minioClient;
