
const create = (model, serviceMasterModel) => async (req, res) => {
    try {
        const item = await model.create(req.body);
        await serviceMasterModel.findByIdAndUpdate(req.params.id, { $push: { addTemplate: item._id } }, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const get = (model) => async (req, res) => {
    try {
        const item = await model.find().lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const update = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const deleteAddTemplate = async (serviceMasterModel, id, arr) => {
    await serviceMasterModel.findByIdAndUpdate(id, { addTemplate: [] }, { new: true });
    await serviceMasterModel.findByIdAndUpdate(id, { $push: { addTemplate: arr } }, { new: true });
};


const deleteOne = (model, serviceMasterModel) => async (req, res) => {
    try {
        const data = await serviceMasterModel.find().lean().exec();
        data.map((parent) => {
            let temp = [];
            parent.addTemplate.map((child) => {
                if (child.toString() !== req.params.id) {
                    temp.push(child);
                }
            });
            deleteAddTemplate(serviceMasterModel, parent._id, temp);
        });
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).json(item);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = (model, serviceMasterModel) => ({
    create: create(model, serviceMasterModel),
    get: get(model),
    getOne: getOne(model),
    update: update(model),
    deleteOne: deleteOne(model, serviceMasterModel)
});

