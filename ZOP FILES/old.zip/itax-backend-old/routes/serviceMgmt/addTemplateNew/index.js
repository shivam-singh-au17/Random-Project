const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationAddTemplateNew = require("./validation");
const { ServiceMasterNew, AddTemplateNew } = require("../../../models/serviceMasterNew");
const addTemplateNewService = require("./service");


router.post("/addTemplateNew/:id", validateParams(validationAddTemplateNew.create), addTemplateNewService(AddTemplateNew, ServiceMasterNew).create);
router.get("/addTemplateNews/", addTemplateNewService(AddTemplateNew).get);
router.get("/addTemplateNew/:id", addTemplateNewService(AddTemplateNew).getOne);
router.patch("/addTemplateNew/:id", validateParams(validationAddTemplateNew.update), addTemplateNewService(AddTemplateNew).update);
router.delete("/addTemplateNew/:id", addTemplateNewService(AddTemplateNew, ServiceMasterNew).deleteOne);


module.exports = router;

