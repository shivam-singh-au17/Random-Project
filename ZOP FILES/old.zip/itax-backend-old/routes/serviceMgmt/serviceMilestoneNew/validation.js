const Joi = require("joi");

module.exports = {
    create: Joi.object({
        milestoneMasterId: Joi.string().required(),
        period: Joi.string().required(),
        groupHead: Joi.string().required(),
        milestoneStatus: Joi.boolean().required(),
        milestoneFee: Joi.number().required(),
        paymentPercentage: Joi.number().required(),
        amount: Joi.number().required()
    }),

    update: Joi.object({
        milestoneMasterId: Joi.string().required(),
        period: Joi.string().required(),
        groupHead: Joi.string().required(),
        milestoneStatus: Joi.boolean().required(),
        milestoneFee: Joi.number().required(),
        paymentPercentage: Joi.number().required(),
        amount: Joi.number().required()
    }),
};

