const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationMilestoneNew = require("./validation");
const { ServiceMasterNew, ServiceMilestoneNew } = require("../../../models/serviceMasterNew");
const milestoneNewService = require("./service");

router.post("/serviceMilestoneNew/:id", validateParams(validationMilestoneNew.create), milestoneNewService(ServiceMilestoneNew, ServiceMasterNew).create);
router.get("/serviceMilestoneNews/", milestoneNewService(ServiceMilestoneNew).get);
router.get("/serviceMilestoneNew/:id", milestoneNewService(ServiceMilestoneNew).getOne);
router.patch("/serviceMilestoneNew/:id", validateParams(validationMilestoneNew.update), milestoneNewService(ServiceMilestoneNew).update);
router.delete("/serviceMilestoneNew/:id", milestoneNewService(ServiceMilestoneNew, ServiceMasterNew).deleteOne);

module.exports = router;
