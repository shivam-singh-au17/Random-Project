const { MilestoneMaster, Option } = require("../../../models");
const { ServiceMilestoneNew, DocumentRequiredNew, AddTemplateNew, MainServiceCategory } = require("../../../models/serviceMasterNew");
const { ServiceTransactionNew } = require("../../../models/serviceTransactionNew");



const addcategoryArray = async (array, mainServiceCategoryModel, id) => {
    for (let index = 0; index < array.length; index++) {
        const element = array[index];
        await mainServiceCategoryModel.findByIdAndUpdate(element, { $push: { subServiceCategorysId: id } }, { new: true });
    }
};



const create = (model, mainServiceCategoryModel) => async (req, res) => {

    try {
        const item = await model.create(req.body);
        let categoryArray = req.body.serviceCategoryId;
        addcategoryArray(categoryArray, mainServiceCategoryModel, item._id);
        if (item.advanceAmount !== undefined) {
            let masterMilestoneData = await MilestoneMaster.find({ isAdvancePayment: true });
            let milestoneMasterIdData = masterMilestoneData[0]._id;

            let optionData = await Option.find({ label: "Group Head" }).lean().exec();
            let groupHeadData = optionData[0]._id;

            let discountId = item._id;
            let discountData = item.advanceAmount;
            let customerFeeData = item.customerFee;
            let paymentPercentageData = (discountData / customerFeeData) * 100;
            const dataPayLode = {
                milestoneMasterId: milestoneMasterIdData,
                period: "once",
                groupHead: groupHeadData,
                milestoneStatus: true,
                milestoneFee: discountData,
                paymentPercentage: paymentPercentageData,
                amount: 0,
            };
            let resItem = await ServiceMilestoneNew.create(dataPayLode);
            let miletoneNewIdData = resItem._id;
            let ansData = await model.findByIdAndUpdate(discountId, { $push: { serviceMilestone: miletoneNewIdData } }, { new: true });
            return res.status(200).send(ansData);
        } else {
            return res.status(200).send(item);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const createByServiceTransactionId = (model, mainServiceCategoryModel) => async (req, res) => {

    try {
        let trxnData = await ServiceTransactionNew.findById(req.params.id).populate({
            path: "serviceMasterId",
            model: "serviceMasterNew",
            populate: [
                {
                    path: "serviceCategoryId",
                    model: "mainServiceCategory"
                },
                {
                    path: "serviceMilestone",
                    model: "serviceMilestoneNew",
                    populate: {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                },
                {
                    path: "documentRequired",
                    model: "documentRequiredNew",
                },
                {
                    path: "addTemplate",
                    model: "addTemplateNew",
                },
                {
                    path: "relatedServices",
                    model: "serviceMasterNew",
                }
            ]
        }).lean().exec();

        let trxnDataId = trxnData._id;
        let serviceRequestNoData = trxnData.serviceRequestNo;

        const milestoneListData = trxnData.serviceMasterId.serviceMilestone;
        for (let i = 0; i < milestoneListData.length; i++) {
            let oneItem = milestoneListData[i];
            let oneItemId = oneItem._id;
            let oneItemNameData = oneItem.milestoneMasterId.isAdvancePayment;
            if (oneItemNameData === true) {
                await ServiceMilestoneNew.findByIdAndDelete(oneItemId);
            }
        }

        req.body.serviceTransactionId = trxnDataId;
        req.body.serviceTransactionRequestNo = serviceRequestNoData;
        req.body.serviceMilestone = trxnData.serviceMasterId.serviceMilestone;
        req.body.documentRequired = trxnData.serviceMasterId.documentRequired;
        req.body.addTemplate = trxnData.serviceMasterId.addTemplate;

        const item = await model.create(req.body);
        let categoryArray = req.body.serviceCategoryId;

        addcategoryArray(categoryArray, mainServiceCategoryModel, item._id);

        if (item.advanceAmount !== undefined) {
            let masterMilestoneData = await MilestoneMaster.find({ isAdvancePayment: true }).lean().exec();
            let milestoneMasterIdData = masterMilestoneData[0]._id;

            let optionData = await Option.find({ label: "Group Head" }).lean().exec();
            let groupHeadData = optionData[0]._id;

            let discountId = item._id;
            let discountData = item.advanceAmount;
            let customerFeeData = item.customerFee;
            let paymentPercentageData = (discountData / customerFeeData) * 100;
            const dataPayLode = {
                milestoneMasterId: milestoneMasterIdData,
                period: "once",
                groupHead: groupHeadData,
                milestoneStatus: true,
                milestoneFee: discountData,
                paymentPercentage: paymentPercentageData,
                amount: 0,
            };
            let resItem = await ServiceMilestoneNew.create(dataPayLode);
            let miletoneNewIdData = resItem._id;
            let ansData = await model.findByIdAndUpdate(discountId, { $push: { serviceMilestone: miletoneNewIdData } }, { new: true });
            return res.status(200).send(ansData);
        } else {
            return res.status(200).send(item);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const get = (model) => async (req, res) => {
    try {
        const item = await model.find({ "serviceTransactionRequestNo": { $exists: false } }).select("_id serviceName serviceModel customerServiceFee customerFee showOnHomePage status").lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).populate([
            {
                path: "serviceCategoryId",
                model: "mainServiceCategory",
                populate: {
                    path: "subServiceCategorysId",
                    model: "serviceMasterNew"
                },
            },
            {
                path: "bundleServiceArr",
                model: "serviceMasterNew",
                select: "_id serviceName",
            },
            {
                path: "GSTApplicableInter",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableIntra",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableInterUt",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "TDSApplicable",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "serviceMilestone",
                model: "serviceMilestoneNew",
                populate: [
                    {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                    {
                        path: "groupHead",
                        model: "Option"
                    },
                ]
            },
            {
                path: "documentRequired",
                model: "documentRequiredNew",
            },
            {
                path: "addTemplate",
                model: "addTemplateNew",
            },
            {
                path: "relatedServices",
                model: "serviceMasterNew",
            }
        ]).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneByCustmizeTransationId = (model) => async (req, res) => {
    try {
        const item = await model.find({ serviceTransactionId: req.params.id }).populate([
            {
                path: "serviceCategoryId",
                model: "mainServiceCategory",
                populate: {
                    path: "subServiceCategorysId",
                    model: "serviceMasterNew"
                },
            },
            {
                path: "GSTApplicableInter",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableIntra",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableInterUt",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "TDSApplicable",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "serviceMilestone",
                model: "serviceMilestoneNew",
                populate: [
                    {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                    {
                        path: "groupHead",
                        model: "Option"
                    },
                ]
            },
            {
                path: "documentRequired",
                model: "documentRequiredNew",
            },
            {
                path: "addTemplate",
                model: "addTemplateNew",
            },
            {
                path: "relatedServices",
                model: "serviceMasterNew",
            }
        ]).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const findAmountById = (model) => async (req, res) => {
    try {

        const item = await model.findById(req.params.id).populate([
            {
                path: "serviceCategoryId",
                model: "mainServiceCategory",
                populate: {
                    path: "subServiceCategorysId",
                    model: "serviceMasterNew"
                },
            },
            {
                path: "GSTApplicableInter",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableIntra",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "GSTApplicableInterUt",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "TDSApplicable",
                model: "taxGroup",
                populate: {
                    path: "taxGroup",
                    model: "taxMaster"
                },
            },
            {
                path: "serviceMilestone",
                model: "serviceMilestoneNew",
                populate: [
                    {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                    {
                        path: "groupHead",
                        model: "Option"
                    },
                ]
            },
            {
                path: "documentRequired",
                model: "documentRequiredNew",
            },
            {
                path: "addTemplate",
                model: "addTemplateNew",
            },
            {
                path: "relatedServices",
                model: "serviceMasterNew",
            }
        ]).lean().exec();

        let allAmount = 0;
        let milestoneData = item.serviceMilestone;
        let customerServiceFeeData = item.customerFee; //item.customerServiceFee;
        milestoneData.map((oneItem) => {
            if (oneItem.period === "once") {
                allAmount += Number(oneItem.milestoneFee);
            }
            if (oneItem.period === "yearly") {
                allAmount += Number(oneItem.milestoneFee);
            }
            if (oneItem.period === "quarterly") {
                allAmount += Number(oneItem.milestoneFee) * 4;
            }
            if (oneItem.period === "monthly") {
                allAmount += Number(oneItem.milestoneFee) * 12;
            }
        });
        const resAmount = Number(customerServiceFeeData) - Number(allAmount);
        return res.status(200).send({ resultAmount: resAmount });

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const update = (model) => async (req, res) => {
    try {
        const itemData = await model.findById(req.params.id).populate([
            {
                path: "serviceMilestone",
                model: "serviceMilestoneNew",
                populate: [
                    {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                    {
                        path: "groupHead",
                        model: "Option"
                    },
                ]
            },
        ]).lean().exec();

        let discountData = itemData.advanceAmount;

        if (discountData === undefined) {

            if (req.body.advanceAmount !== undefined) {

                let masterMilestoneData = await MilestoneMaster.find({ isAdvancePayment: true }).lean().exec();
                let milestoneMasterIdData = masterMilestoneData[0]._id;

                let optionData = await Option.find({ label: "Group Head" }).lean().exec();
                let groupHeadData = optionData[0]._id;
                let discountData = req.body.advanceAmount === undefined ? 0 : req.body.advanceAmount;
                let customerFeeData = itemData.customerFee === undefined ? 0 : itemData.customerFee;
                let paymentPercentageData = ((discountData / customerFeeData) * 100) === null || Infinity ? 0 : ((discountData / customerFeeData) * 100);
                const dataPayLode = {
                    milestoneMasterId: milestoneMasterIdData,
                    period: "once",
                    groupHead: groupHeadData,
                    milestoneStatus: true,
                    milestoneFee: discountData,
                    paymentPercentage: paymentPercentageData,
                    amount: 0,
                };
                let resItem = await ServiceMilestoneNew.create(dataPayLode);
                let miletoneNewIdData = resItem._id;
                await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
                let ansData = await model.findByIdAndUpdate(req.params.id, { $push: { serviceMilestone: miletoneNewIdData } }, { new: true });
                return res.status(200).send(ansData);

            } else {
                const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
                return res.status(200).send(item);
            }

        } else if (discountData === null) {

            if (req.body.advanceAmount === undefined) {

                const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
                return res.status(200).send(item);

            } else {

                let masterMilestoneData = await MilestoneMaster.find({ isAdvancePayment: true }).lean().exec();
                let milestoneMasterIdData = masterMilestoneData[0]._id;

                let optionData = await Option.find({ label: "Group Head" }).lean().exec();
                let groupHeadData = optionData[0]._id;
                let discountData = req.body.advanceAmount === undefined ? 0 : req.body.advanceAmount;
                let customerFeeData = itemData.customerFee === undefined ? 0 : itemData.customerFee;
                let paymentPercentageData = ((discountData / customerFeeData) * 100) === null || Infinity ? 0 : ((discountData / customerFeeData) * 100);
                const dataPayLode = {
                    milestoneMasterId: milestoneMasterIdData,
                    period: "once",
                    groupHead: groupHeadData,
                    milestoneStatus: true,
                    milestoneFee: discountData,
                    paymentPercentage: paymentPercentageData,
                    amount: 0,
                };
                let resItem = await ServiceMilestoneNew.create(dataPayLode);
                let miletoneNewIdData = resItem._id;
                await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
                let ansData = await model.findByIdAndUpdate(req.params.id, { $push: { serviceMilestone: miletoneNewIdData } }, { new: true });
                return res.status(200).send(ansData);
            }

        } else {

            if (req.body.advanceAmount !== undefined) {

                const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });

                const itemData = await model.findById(req.params.id).populate([
                    {
                        path: "serviceMilestone",
                        model: "serviceMilestoneNew",
                        populate: [
                            {
                                path: "milestoneMasterId",
                                model: "MilestoneMaster"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                        ]
                    },
                ]).lean().exec();

                let discountData = itemData.advanceAmount === undefined ? 0 : itemData.advanceAmount;
                let customerFeeData = itemData.customerFee === undefined ? 0 : itemData.customerFee;
                let paymentPercentageData = ((discountData / customerFeeData) * 100) === null || Infinity ? 0 : ((discountData / customerFeeData) * 100);
                let advAmtData = null;
                let milestoneAdvnsData = itemData.serviceMilestone;

                for (let i = 0; i < milestoneAdvnsData.length; i++) {
                    let itemId = milestoneAdvnsData[i].milestoneMasterId.isAdvancePayment;
                    if (itemId === true) {
                        advAmtData = milestoneAdvnsData[i]._id;
                    }
                }

                await ServiceMilestoneNew.findByIdAndUpdate(advAmtData, {
                    milestoneFee: discountData,
                    paymentPercentage: paymentPercentageData,
                }, { new: true });

                return res.status(200).send(item);

            } else {

                const itemData = await model.findById(req.params.id).populate([
                    {
                        path: "serviceMilestone",
                        model: "serviceMilestoneNew",
                        populate: [
                            {
                                path: "milestoneMasterId",
                                model: "MilestoneMaster"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                        ]
                    },
                ]).lean().exec();

                let milestoneAdvnsData = itemData.serviceMilestone;

                for (let i = 0; i < milestoneAdvnsData.length; i++) {
                    let itemId = milestoneAdvnsData[i].milestoneMasterId.isAdvancePayment;
                    if (itemId === true) {
                        await ServiceMilestoneNew.findByIdAndDelete(milestoneAdvnsData[i]._id);
                        await model.findByIdAndUpdate(req.params.id, { advanceAmount: "" }, { new: true });
                    }
                }

                let itemRes = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
                return res.status(200).send(itemRes);

            }

        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const createRelatedServices = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, {
            relatedServices: req.body.relatedServices,
        }, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};

const updateMainServiceCategory = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { subServiceCategorysId: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { subServiceCategorysId: arr } }, { new: true });
};


const deleteOne = (model) => async (req, res) => {
    try {

        let mgmtData = await model.findById(req.params.id).lean().exec();

        let milestoneData = mgmtData.serviceMilestone;
        for (let i = 0; i < milestoneData.length; i++) {
            let idData = milestoneData[i];
            await ServiceMilestoneNew.findByIdAndDelete(idData);
        }

        let documentData = mgmtData.documentRequired;
        for (let i = 0; i < documentData.length; i++) {
            let idData = documentData[i];
            await DocumentRequiredNew.findByIdAndDelete(idData);
        }

        let templateData = mgmtData.addTemplate;
        for (let i = 0; i < templateData.length; i++) {
            let idData = templateData[i];
            await AddTemplateNew.findByIdAndDelete(idData);
        }

        let categoryData = mgmtData.serviceCategoryId;
        for (let i = 0; i < categoryData.length; i++) {
            let idData = categoryData[i];
            let serviceCategoryData = await MainServiceCategory.findById(idData).lean().exec();
            let subserviceCategoryId = serviceCategoryData._id;
            let subServiceCatData = serviceCategoryData.subServiceCategorysId;
            let myyArrData = [];
            for (let i = 0; i < subServiceCatData.length; i++) {
                let idData = subServiceCatData[i];
                if (idData.toString() !== req.params.id) {
                    myyArrData.push(idData);
                }
            }
            updateMainServiceCategory(MainServiceCategory, subserviceCategoryId, myyArrData);
        }
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).json(item);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = (model, mainServiceCategoryModel) => ({
    create: create(model, mainServiceCategoryModel),
    createByServiceTransactionId: createByServiceTransactionId(model, mainServiceCategoryModel),
    get: get(model),
    getOne: getOne(model),
    getOneByCustmizeTransationId: getOneByCustmizeTransationId(model),
    findAmountById: findAmountById(model),
    update: update(model),
    createRelatedServices: createRelatedServices(model),
    deleteOne: deleteOne(model)
});

