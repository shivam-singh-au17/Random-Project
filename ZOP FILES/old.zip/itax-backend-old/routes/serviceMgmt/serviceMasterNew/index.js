const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationMasterNew = require("./validation");
const { MainServiceCategory, ServiceMasterNew } = require("../../../models/serviceMasterNew");
const serviceMasterNewService = require("./service");

router.post("/serviceMasterNew/", validateParams(validationMasterNew.create), serviceMasterNewService(ServiceMasterNew, MainServiceCategory).create);
router.post("/createByServiceTransactionId/:id", validateParams(validationMasterNew.create), serviceMasterNewService(ServiceMasterNew, MainServiceCategory).createByServiceTransactionId);


router.get("/serviceMasterNews/", serviceMasterNewService(ServiceMasterNew).get);
router.get("/serviceMasterNew/:id", serviceMasterNewService(ServiceMasterNew).getOne);
router.get("/findAmountById/:id", serviceMasterNewService(ServiceMasterNew).findAmountById);
router.get("/getOneByCustmizeTransationId/:id", serviceMasterNewService(ServiceMasterNew).getOneByCustmizeTransationId);


router.patch("/serviceMasterNew/:id", validateParams(validationMasterNew.update), serviceMasterNewService(ServiceMasterNew).update);
router.patch("/createRelatedService/:id", validateParams(validationMasterNew.createRelatedServices), serviceMasterNewService(ServiceMasterNew).createRelatedServices);


router.delete("/serviceMasterNew/:id", serviceMasterNewService(ServiceMasterNew).deleteOne);


module.exports = router;
