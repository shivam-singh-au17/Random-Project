const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationMainServiceCategory = require("./validation");
const { MainServiceCategory } = require("../../../models/serviceMasterNew");
const mainServiceCategoryService = require("./service");


router.post("/mainServiceCategory/", validateParams(validationMainServiceCategory.create), mainServiceCategoryService(MainServiceCategory).create);
router.get("/mainServiceCategorys/", mainServiceCategoryService(MainServiceCategory).get);
router.get("/mainServiceCategory/:id", mainServiceCategoryService(MainServiceCategory).getOne);
router.patch("/mainServiceCategory/:id", validateParams(validationMainServiceCategory.update), mainServiceCategoryService(MainServiceCategory).update);
router.delete("/mainServiceCategory/:id", mainServiceCategoryService(MainServiceCategory).deleteOne);

module.exports = router;

