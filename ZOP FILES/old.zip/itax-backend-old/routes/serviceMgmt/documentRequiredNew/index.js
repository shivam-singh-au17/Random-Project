const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationDocumentRequired = require("./validation");
const { ServiceMasterNew, DocumentRequiredNew } = require("../../../models/serviceMasterNew");
const documentRequiredNewService = require("./service");


router.post("/documentRequiredNew/:id", validateParams(validationDocumentRequired.create), documentRequiredNewService(DocumentRequiredNew, ServiceMasterNew).create);
router.get("/documentRequiredNews/", documentRequiredNewService(DocumentRequiredNew).get);
router.get("/documentRequiredNew/:id", documentRequiredNewService(DocumentRequiredNew).getOne);
router.patch("/documentRequiredNew/:id", validateParams(validationDocumentRequired.update), documentRequiredNewService(DocumentRequiredNew).update);
router.delete("/documentRequiredNew/:id", documentRequiredNewService(DocumentRequiredNew, ServiceMasterNew).deleteOne);

module.exports = router;

