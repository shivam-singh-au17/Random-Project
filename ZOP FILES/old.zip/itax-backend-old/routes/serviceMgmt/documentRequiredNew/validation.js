const Joi = require("joi");

module.exports = {
    create: Joi.object({
        documentType: Joi.string().required(),
        mandatory: Joi.boolean().required(),
        onHomePage: Joi.boolean().required(),
    }),

    update: Joi.object({
        documentType: Joi.string().required(),
        mandatory: Joi.boolean().required(),
        onHomePage: Joi.boolean().required(),
    }),
};

