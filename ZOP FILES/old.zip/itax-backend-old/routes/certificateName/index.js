const express = require("express");
const router = express.Router();
const certificateNameValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const certificateNameService = require("./service");

router.post(
    "/certificateName",
    validateParams(certificateNameValidation.create),
    certificateNameService.create
);

router.get(
    "/certificateNames",
    certificateNameService.get
);


router.get(
    "/certificateName/:id",
    certificateNameService.getbyId
);

router.delete(
    "/certificateName/:id",
    certificateNameService.delete
);

router.patch(
    "/certificateName/:id",
    validateParams(certificateNameValidation.update),
    certificateNameService.update
);

module.exports = router;
