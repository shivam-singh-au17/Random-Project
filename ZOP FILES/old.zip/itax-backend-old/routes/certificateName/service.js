const { CertificateName } = require("../../models");

exports.create = async(req,res) => {
    const certName = new CertificateName({
        certificateName: req.body.certificateName,
    });

    try{
        const a1 =  await certName.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let certName = CertificateName.find();
        if (!isNaN(parseInt(req.query.skip)))
            certName = certName.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            certName = certName.limit(parseInt(req.query.limit));
        let certNames = await certName;
        res.json(certNames);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const certName = await CertificateName.findById(req.params.id);
        res.json(certName);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const certName = await CertificateName.findById(req.params.id);
        const a1 = await certName.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const certName = await CertificateName.findById(req.params.id);
        certName.certificateName = req.body.certificateName;
        const a1 = await certName.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
