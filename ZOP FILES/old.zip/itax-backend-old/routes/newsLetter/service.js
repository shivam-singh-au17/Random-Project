const { NewsLetters } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async(req,res) => {
    const newsletter = new NewsLetters({
        month: req.body.month,
        year: req.body.year,
        letter_heading: req.body.letter_heading,
        sort_description: req.body.sort_description,
        file_upload: req.body.file_upload,
        status: req.body.status,
    });

    try{
        const a1 =  await newsletter.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async (req,res) => {
    try{
        let newsletter = NewsLetters.find();
        if (!isNaN(parseInt(req.query.skip)))
            newsletter = newsletter.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            newsletter = newsletter.limit(parseInt(req.query.limit));
        let newsletters = await newsletter;
        newsletters = await Promise.all(newsletters.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.file_upload);
                } catch {
                    readURL = { url: undefined };
                }
                return { ...i._doc, file_upload: readURL};
            }));
        res.json(newsletters);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const newsletter = await NewsLetters.findById(req.params.id);
        let readURL;
        try {
            readURL = await generateReadSignedURL(newsletter.file_upload);
        } catch {
            readURL = { url: undefined };
        }
        res.json({...newsletter._doc, file_upload: readURL});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const newsletter = await NewsLetters.findById(req.params.id);
        const a1 = await newsletter.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const newsletter = await NewsLetters.findById(req.params.id);
        newsletter.month = req.body.month,
        newsletter.year = req.body.year,
        newsletter.letter_heading = req.body.letter_heading,
        newsletter.sort_description = req.body.sort_description,
        newsletter.file_upload = req.body.file_upload,
        newsletter.status = req.body.status;
        const a1 = await newsletter.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
