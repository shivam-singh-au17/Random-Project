const express = require("express");
const router = express.Router();
const newsLeterValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const newsLetterService = require("./service");

router.post(
    "/newsletter",
    validateParams(newsLeterValidation.create),
    newsLetterService.create
);

router.get(
    "/newsletters",
    newsLetterService.get
);


router.get(
    "/newsletter/:id",
    newsLetterService.getbyId
);

router.delete(
    "/newsletter/:id",
    newsLetterService.delete
);

router.patch(
    "/newsletter/:id",
    validateParams(newsLeterValidation.update),
    newsLetterService.update
);

module.exports = router;
