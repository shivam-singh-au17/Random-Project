const Joi = require("joi");

module.exports = {
    create: Joi.object({
        month: Joi.string().required(),
        year: Joi.string().required(),
        letter_heading: Joi.string().required(),
        sort_description: Joi.string().required(),
        file_upload: Joi.string(),
        status: Joi.boolean().required()
    }),
    update: Joi.object({
        month: Joi.string().required(),
        year: Joi.string().required(),
        letter_heading: Joi.string().required(),
        sort_description: Joi.string().required(),
        file_upload: Joi.string(),
        status: Joi.boolean().required()
    }),
};
