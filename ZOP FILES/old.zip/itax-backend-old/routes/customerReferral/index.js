const express = require("express");
const router = express.Router();
const customerReferralValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const customerReferralService = require("./service");

router.post(
    "/customerReferral",
    validateParams(customerReferralValidation.create),
    customerReferralService.create
);

router.get(
    "/customerReferrals",
    customerReferralService.get
);


router.get(
    "/customerReferral/:id",
    customerReferralService.getbyId
);

router.delete(
    "/customerReferral/:id",
    customerReferralService.delete
);

router.patch(
    "/customerReferral/:id",
    validateParams(customerReferralValidation.update),
    customerReferralService.update
);

module.exports = router;
