const { CustomerReferral } = require("../../models");

exports.create = async(req,res) => {
    const customer = new CustomerReferral({
        referralHeading: req.body.referralHeading,
        validFrom: req.body.validFrom,
        validTo: req.body.validTo,
        status: req.body.status,
        referralIncentive: req.body.referralIncentive,
        referralAmount: req.body.referralAmount,
        customerDiscount: req.body.customerDiscount,
        customerAmount: req.body.customerAmount,
        remarks: req.body.remarks,
    });

    try{
        const a1 =  await customer.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let customer = CustomerReferral.find();
        if (!isNaN(parseInt(req.query.skip)))
            customer = customer.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            customer = customer.limit(parseInt(req.query.limit));
        let customers = await customer;
        res.json(customers);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const customer = await CustomerReferral.findById(req.params.id);
        res.json(customer);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const customer = await CustomerReferral.findById(req.params.id);
        const a1 = await customer.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const customer = await CustomerReferral.findById(req.params.id);
        customer.referralHeading = req.body.referralHeading,
        customer.validFrom = req.body.validFrom,
        customer.validTo = req.body.validTo,
        customer.status = req.body.status,
        customer.referralIncentive = req.body.referralIncentive,
        customer.referralAmount = req.body.referralAmount,
        customer.customerDiscount = req.body.customerDiscount,
        customer.customerAmount = req.body.customerAmount,
        customer.remarks = req.body.remarks;
        const a1 = await customer.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
