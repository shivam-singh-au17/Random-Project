const { ServiceMasterNew } = require("../../models/serviceMasterNew");
const { Calendar, MilestoneMaster, Option } = require("../../models/");
const { ServiceTransactionNew, ServiceTransactionNewCount, ServiceTrxnForTicketCount } = require("../../models/serviceTransactionNew");
const { v4: uuidv4 } = require("uuid");
const moment = require("moment-timezone");



const getCount = async () => {
    let newCount = await ServiceTransactionNewCount.find().lean().exec();
    let res = newCount[newCount.length - 1];
    if (res === undefined) {
        return 1;
    } else {
        let ans = res.serviceTicketNoCount;
        let temp = Number(ans);
        return temp;
    }
};



const getCountForTicket = async () => {
    let newCount = await ServiceTrxnForTicketCount.find().lean().exec();
    let res = newCount[newCount.length - 1];
    if (res === undefined) {
        return 1;
    } else {
        let ans = res.serviceTicketNo;
        let temp = Number(ans);
        return temp;
    }
};



const serviceTicketNo = (countData) => {
    let flag = "ST";
    let newString = String(countData);
    let zeroToGentrate = 6 - newString.length;
    let zeroStr = "";
    for (let i = 0; i < zeroToGentrate; i++) {
        zeroStr += "0";
    }
    return flag + zeroStr + newString;
};



const serviceRequestNo = (countData) => {
    let flag = "SR";
    let newString = String(countData);
    let zeroToGentrate = 6 - newString.length;
    let zeroStr = "";
    for (let i = 0; i < zeroToGentrate; i++) {
        zeroStr += "0";
    }
    return flag + zeroStr + newString;
};



const showMonthName = (month) => {
    let newMonth = String(month);
    switch (newMonth) {
    case "1":
        return "January";
    case "2":
        return "February";
    case "3":
        return "March";
    case "4":
        return "April";
    case "5":
        return "May";
    case "6":
        return "June";
    case "7":
        return "July";
    case "8":
        return "August";
    case "9":
        return "September";
    case "10":
        return "October";
    case "11":
        return "November";
    case "0":
        return "December";
    default:
        return;
    }
};



const showMonthKey = (month) => {
    let newMonth = String(month);
    switch (newMonth) {
    case "1":
        return 10;
    case "2":
        return 11;
    case "3":
        return 12;
    case "4":
        return 1;
    case "5":
        return 2;
    case "6":
        return 3;
    case "7":
        return 4;
    case "8":
        return 5;
    case "9":
        return 6;
    case "10":
        return 7;
    case "11":
        return 8;
    case "0":
        return 9;
    default:
        return 0;
    }
};




const create = (model) => async (req, res) => {
    try {
        const masterDataId = await ServiceMasterNew.findById(req.body.serviceMasterId).lean().exec();
        let typeOfServiceMgmt = masterDataId.serviceModel;

        if (typeOfServiceMgmt.toLowerCase() === "customize") {

            let countData = await getCount();

            req.body.serviceRequestNo = serviceRequestNo(countData);
            req.body.ticketDate = moment().format("DD/MM/YYYY");
            const item = await model.create(req.body);

            await ServiceTransactionNewCount.create({ serviceTicketNoCount: countData + 1 });

            let curntServiceTxnId = item._id;
            let curntUserMonthChoice = item.userMonthChoice;

            const templateData = await model.findById(curntServiceTxnId).populate({
                path: "serviceMasterId",
                model: "serviceMasterNew",
                populate: [
                    {
                        path: "serviceCategoryId",
                        model: "mainServiceCategory"
                    },
                    {
                        path: "addTemplate",
                        model: "addTemplateNew",
                    },
                ]
            }).lean().exec();

            const arrayOfTemplate = templateData.serviceMasterId.addTemplate;
            await model.findByIdAndUpdate(curntServiceTxnId, { addTemplateArr: [] }, { new: true });
            await model.findByIdAndUpdate(curntServiceTxnId, { $push: { addTemplateArr: arrayOfTemplate } }, { new: true });


            const updateMilestoneFun = async (milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month) => {
                await ServiceTransactionNew.findByIdAndUpdate(curntServiceTxnId, {
                    $push: {
                        allMilestoneData: calenderIdData !== false ? {
                            _id: uuidv4(),
                            milestoneId: milestoneIdData,
                            groupHead: groupHeadData,
                            updateDate: moment().format("DD/MM/YYYY"),
                            month: showMonthName(month),
                            billable: billableData,
                            amount: amountData,
                            monthKey: showMonthKey(month),
                            calenderId: calenderIdData,
                            paidAmount: 0,
                            balanceAmount: amountData,
                            GSTAmount: 0,
                            paymentStatus: "Pending",
                        } : {
                            _id: uuidv4(),
                            milestoneId: milestoneIdData,
                            groupHead: groupHeadData,
                            updateDate: moment().format("DD/MM/YYYY"),
                            month: showMonthName(month),
                            billable: billableData,
                            amount: amountData,
                            monthKey: showMonthKey(month),
                            paidAmount: 0,
                            balanceAmount: amountData,
                            GSTAmount: 0,
                            paymentStatus: "Pending",
                        }
                    }
                }, { new: true });

            };


            const genrateMilestone = (periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, curntUserMonthChoice) => {

                if (curntUserMonthChoice === undefined) {

                    if (periodData === "once") {
                        updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                    } else if (periodData === "yearly") {
                        updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                    } else if (periodData === "monthly") {
                        for (let i = 0; i < 12; i++) {
                            let month = (i + 4) % 12;
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                        }
                    } else if (periodData === "quarterly") {
                        for (let i = 0; i < 12; i = i + 3) {
                            let month = (i + 4) % 12;
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                        }
                    }
                } else {

                    if (periodData === "once") {
                        updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                    } else if (periodData === "yearly") {
                        updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                    } else if (periodData === "monthly") {
                        for (let i = 0; i < Number(curntUserMonthChoice); i++) {
                            let month = (i + 4) % 12;
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                        }
                    } else if (periodData === "quarterly") {
                        for (let i = 0; i < Number(curntUserMonthChoice) - 3; i = i + 3) {
                            let month = (i + 4) % 12;
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                        }
                    }
                }


            };


            let miilestoneList = await ServiceMasterNew.find({ _id: req.body.serviceMasterId }).populate({
                path: "serviceMilestone",
                select: "milestoneMasterId period groupHead milestoneStatus milestoneFee paymentPercentage amount",
            }).lean().exec();

            let allMilestone = miilestoneList[0].serviceMilestone;
            allMilestone.map(async (oneItem) => {

                let periodData = oneItem.period;
                let milestoneIdData = oneItem._id;
                let amountData = oneItem.amount;

                let groupHeadTemp = await Option.find({ _id: oneItem.groupHead });
                let groupHeadData = groupHeadTemp[0].label;
                let milestoneMasterIdData = await MilestoneMaster.find({ _id: oneItem.milestoneMasterId });
                let billableData = milestoneMasterIdData[0].billable;

                let calenderData = await Calendar.find({ milestone: oneItem.milestoneMasterId });
                let calenderIdData = calenderData[0] !== undefined ? calenderData[0]._id : false;

                genrateMilestone(periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, curntUserMonthChoice);

            });

            return res.status(200).send(item);
        } else {

            if (req.body.allMilestoneData === undefined) {

                let countData = await getCount();
                let countDataTicket = await getCountForTicket();

                req.body.serviceTicketNo = serviceTicketNo(countDataTicket);
                req.body.serviceRequestNo = serviceRequestNo(countData);
                req.body.ticketDate = moment().format("DD/MM/YYYY");
                const item = await model.create(req.body);

                await ServiceTransactionNewCount.create({ serviceTicketNoCount: countData + 1 });
                await ServiceTrxnForTicketCount.create({ serviceTicketNo: countDataTicket + 1 });

                let curntServiceTxnId = item._id;
                let curntUserMonthChoice = item.userMonthChoice;

                const templateData = await model.findById(curntServiceTxnId).populate({
                    path: "serviceMasterId",
                    model: "serviceMasterNew",
                    populate: [
                        {
                            path: "serviceCategoryId",
                            model: "mainServiceCategory"
                        },
                        {
                            path: "addTemplate",
                            model: "addTemplateNew",
                        },
                    ]
                }).lean().exec();

                const arrayOfTemplate = templateData.serviceMasterId.addTemplate;
                await model.findByIdAndUpdate(curntServiceTxnId, { $push: { addTemplateArr: [] } }, { new: true });
                await model.findByIdAndUpdate(curntServiceTxnId, { $push: { addTemplateArr: arrayOfTemplate } }, { new: true });

                const updateMilestoneFun = async (milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month) => {
                    await ServiceTransactionNew.findByIdAndUpdate(curntServiceTxnId, {
                        $push: {
                            allMilestoneData: calenderIdData !== false ? {
                                _id: uuidv4(),
                                milestoneId: milestoneIdData,
                                groupHead: groupHeadData,
                                updateDate: moment().format("DD/MM/YYYY"),
                                month: showMonthName(month),
                                billable: billableData,
                                amount: amountData,
                                monthKey: showMonthKey(month),
                                calenderId: calenderIdData,
                                paidAmount: 0,
                                balanceAmount: amountData,
                                GSTAmount: 0,
                                paymentStatus: "Pending",
                            } : {
                                _id: uuidv4(),
                                milestoneId: milestoneIdData,
                                groupHead: groupHeadData,
                                updateDate: moment().format("DD/MM/YYYY"),
                                month: showMonthName(month),
                                billable: billableData,
                                amount: amountData,
                                monthKey: showMonthKey(month),
                                paidAmount: 0,
                                balanceAmount: amountData,
                                GSTAmount: 0,
                                paymentStatus: "Pending",
                            }
                        }
                    }, { new: true });

                };

                const genrateMilestone = (periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, curntUserMonthChoice) => {

                    if (curntUserMonthChoice === undefined) {

                        if (periodData === "once") {
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                        } else if (periodData === "yearly") {
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                        } else if (periodData === "monthly") {
                            for (let i = 0; i < 12; i++) {
                                let month = (i + 4) % 12;
                                updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                            }
                        } else if (periodData === "quarterly") {
                            for (let i = 0; i < 12; i = i + 3) {
                                let month = (i + 4) % 12;
                                updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                            }
                        }
                    } else {

                        if (periodData === "once") {
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                        } else if (periodData === "yearly") {
                            updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
                        } else if (periodData === "monthly") {
                            for (let i = 0; i < Number(curntUserMonthChoice); i++) {
                                let month = (i + 4) % 12;
                                updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                            }
                        } else if (periodData === "quarterly") {
                            for (let i = 0; i < Number(curntUserMonthChoice) - 3; i = i + 3) {
                                let month = (i + 4) % 12;
                                updateMilestoneFun(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                            }
                        }
                    }

                };

                let miilestoneList = await ServiceMasterNew.find({ _id: req.body.serviceMasterId }).populate({
                    path: "serviceMilestone",
                    select: "milestoneMasterId period groupHead milestoneStatus milestoneFee paymentPercentage amount",
                }).lean().exec();

                let allMilestone = miilestoneList[0].serviceMilestone;
                allMilestone.map(async (oneItem) => {

                    let periodData = oneItem.period;
                    let milestoneIdData = oneItem._id;
                    let amountData = oneItem.amount;

                    let groupHeadTemp = await Option.find({ _id: oneItem.groupHead });
                    let groupHeadData = groupHeadTemp[0].label;
                    let milestoneMasterIdData = await MilestoneMaster.find({ _id: oneItem.milestoneMasterId });
                    let billableData = milestoneMasterIdData[0].billable;

                    let calenderData = await Calendar.find({ milestone: oneItem.milestoneMasterId });
                    let calenderIdData = calenderData[0] !== undefined ? calenderData[0]._id : false;

                    genrateMilestone(periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, curntUserMonthChoice);

                });

                return res.status(200).send(item);
            } else {

                let countData = await getCount();
                let countDataTicket = await getCountForTicket();

                let arrOfAllMilestoneData = req.body.allMilestoneData;
                arrOfAllMilestoneData.map((item) => {
                    item._id = uuidv4();
                });

                req.body.serviceTicketNo = serviceTicketNo(countDataTicket);
                req.body.serviceRequestNo = serviceRequestNo(countData);
                req.body.ticketDate = moment().format("DD/MM/YYYY");
                req.body.allMilestoneData = arrOfAllMilestoneData;
                const item = await model.create(req.body);

                await ServiceTransactionNewCount.create({ serviceTicketNoCount: countData + 1 });
                await ServiceTrxnForTicketCount.create({ serviceTicketNo: countDataTicket + 1 });

                let curntServiceTxnId = item._id;

                const templateData = await model.findById(curntServiceTxnId).populate({
                    path: "serviceMasterId",
                    model: "serviceMasterNew",
                    populate: [
                        {
                            path: "serviceCategoryId",
                            model: "mainServiceCategory"
                        },
                        {
                            path: "addTemplate",
                            model: "addTemplateNew",
                        },
                    ]
                }).lean().exec();

                const arrayOfTemplate = templateData.serviceMasterId.addTemplate;
                await model.findByIdAndUpdate(curntServiceTxnId, { addTemplateArr: [] }, { new: true });
                await model.findByIdAndUpdate(curntServiceTxnId, { $push: { addTemplateArr: arrayOfTemplate } }, { new: true });

                return res.status(200).send(item);
            }

        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateServicesTrxnByServiseMgmtId = (model) => async (req, res) => {
    try {

        const serviceMgmtData = await ServiceMasterNew.findById(req.params.id).populate({
            path: "serviceMilestone",
            select: "milestoneMasterId period groupHead milestoneStatus milestoneFee paymentPercentage amount",
        }).lean().exec();

        let curntServiceTxnId = serviceMgmtData.serviceTransactionId;

        const updateMilestoneFunction = async (milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month) => {
            await ServiceTransactionNew.findByIdAndUpdate(curntServiceTxnId, { allMilestoneData: [] }, { new: true });
            await ServiceTransactionNew.findByIdAndUpdate(curntServiceTxnId, {
                $push: {
                    allMilestoneData: calenderIdData !== false ? {
                        _id: uuidv4(),
                        milestoneId: milestoneIdData,
                        groupHead: groupHeadData,
                        updateDate: moment().format("DD/MM/YYYY"),
                        month: showMonthName(month),
                        billable: billableData,
                        amount: amountData,
                        monthKey: showMonthKey(month),
                        calenderId: calenderIdData,
                        paidAmount: 0,
                        balanceAmount: amountData,
                        GSTAmount: 0,
                        paymentStatus: "Pending",
                    } : {
                        _id: uuidv4(),
                        milestoneId: milestoneIdData,
                        groupHead: groupHeadData,
                        updateDate: moment().format("DD/MM/YYYY"),
                        month: showMonthName(month),
                        billable: billableData,
                        amount: amountData,
                        monthKey: showMonthKey(month),
                        paidAmount: 0,
                        balanceAmount: amountData,
                        GSTAmount: 0,
                        paymentStatus: "Pending",
                    }
                }
            }, { new: true });

        };

        const genrateMilestoneFunction = (periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId) => {

            if (periodData === "once") {
                updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
            } else if (periodData === "yearly") {
                updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
            } else if (periodData === "monthly") {
                for (let i = 0; i < 12; i++) {
                    let month = (i + 4) % 12;
                    updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                }
            } else if (periodData === "quarterly") {
                for (let i = 0; i < 12; i = i + 3) {
                    let month = (i + 4) % 12;
                    updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId, month);
                }
            }

        };

        let allMilestone = serviceMgmtData.serviceMilestone;

        allMilestone.map(async (oneItem) => {

            let periodData = oneItem.period;
            let milestoneIdData = oneItem._id;
            let amountData = oneItem.amount;

            let groupHeadTemp = await Option.find({ _id: oneItem.groupHead });
            let groupHeadData = groupHeadTemp[0].label;
            let milestoneMasterIdData = await MilestoneMaster.find({ _id: oneItem.milestoneMasterId });
            let billableData = milestoneMasterIdData[0].billable;

            let calenderData = await Calendar.find({ milestone: oneItem.milestoneMasterId });
            let calenderIdData = calenderData[0] !== undefined ? calenderData[0]._id : false;

            setTimeout(() => {
                genrateMilestoneFunction(periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, curntServiceTxnId);
            }, 3000);

        });


        await ServiceTransactionNew.findByIdAndUpdate(curntServiceTxnId, {
            customizeFlag: req.body.customizeFlag,
            serviceMasterId: serviceMgmtData._id,
        }, { new: true });


        const templateData = await model.findById(curntServiceTxnId).populate({
            path: "serviceMasterId",
            model: "serviceMasterNew",
            populate: [
                {
                    path: "serviceCategoryId",
                    model: "mainServiceCategory"
                },
                {
                    path: "addTemplate",
                    model: "addTemplateNew",
                },
            ]
        }).lean().exec();

        const arrayOfTemplate = templateData.serviceMasterId.addTemplate;
        await model.findByIdAndUpdate(curntServiceTxnId, { addTemplateArr: [] }, { new: true });
        await model.findByIdAndUpdate(curntServiceTxnId, { $push: { addTemplateArr: arrayOfTemplate } }, { new: true });

        return res.status(200).send(templateData);

    } catch (err) {
        return res.status(400).send(err.message);
    }

};




const createMilestoneByServiceMgmtId = (model) => async (req, res) => {
    try {

        const updateMilestoneFunction = (milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, month) => {

            let payLodeOne = {
                _id: uuidv4(),
                milestoneId: milestoneIdData,
                groupHead: groupHeadData,
                updateDate: moment().format("DD/MM/YYYY"),
                month: showMonthName(month),
                billable: billableData,
                amount: amountData,
                monthKey: showMonthKey(month),
                calenderId: calenderIdData,
                paidAmount: 0,
                balanceAmount: amountData,
                GSTAmount: 0,
                paymentStatus: "Pending",
            };

            let payLodeTwo = {
                _id: uuidv4(),
                milestoneId: milestoneIdData,
                groupHead: groupHeadData,
                updateDate: moment().format("DD/MM/YYYY"),
                month: showMonthName(month),
                billable: billableData,
                amount: amountData,
                monthKey: showMonthKey(month),
                paidAmount: 0,
                balanceAmount: amountData,
                GSTAmount: 0,
                paymentStatus: "Pending",
            };

            if (calenderIdData !== false) {
                return payLodeOne;
            } else {
                return payLodeTwo;
            }

        };


        const genrateMilestoneByMgmtId = (periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData) => {
            let myAllMileStone = [];
            if (periodData === "once") {
                let data1 = updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData);
                myAllMileStone.push(data1);
            } else if (periodData === "yearly") {
                let data2 = updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData);
                myAllMileStone.push(data2);
            } else if (periodData === "monthly") {
                for (let i = 0; i < 12; i++) {
                    let month = (i + 4) % 12;
                    let data3 = updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, month);
                    myAllMileStone.push(data3);
                }
            } else if (periodData === "quarterly") {
                for (let i = 0; i < 12; i = i + 3) {
                    let month = (i + 4) % 12;
                    let data4 = updateMilestoneFunction(milestoneIdData, groupHeadData, amountData, billableData, calenderIdData, month);
                    myAllMileStone.push(data4);
                }
            }
            return myAllMileStone;
        };



        let milestoneList = await model.findById(req.params.id).populate({
            path: "serviceMilestone",
            model: "serviceMilestoneNew",
            populate: [
                {
                    path: "milestoneMasterId",
                    model: "MilestoneMaster"
                },
                {
                    path: "groupHead",
                    model: "Option"
                },
            ]
        }).lean().exec();


        let allMilestone = milestoneList.serviceMilestone;

        let ansMilestoneData = [];

        for (let i = 0; i < allMilestone.length; i++) {

            let oneItem = allMilestone[i];

            let periodData = oneItem.period;
            let milestoneIdData = oneItem;
            let amountData = oneItem.amount;

            let groupHeadTemp = await Option.find({ _id: oneItem.groupHead });
            let groupHeadData = groupHeadTemp[0].label;
            let milestoneMasterIdData = await MilestoneMaster.find({ _id: oneItem.milestoneMasterId });
            let billableData = milestoneMasterIdData[0].billable;

            let calenderData = await Calendar.find({ milestone: oneItem.milestoneMasterId });
            let calenderIdData = calenderData[0] !== undefined ? calenderData[0] : false;

            let storeData = await genrateMilestoneByMgmtId(periodData, milestoneIdData, groupHeadData, amountData, billableData, calenderIdData);
            for (let i = 0; i < storeData.length; i++) {
                ansMilestoneData.push(storeData[i]);
            }

        }

        return res.status(200).send(ansMilestoneData);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const get = (model) => async (req, res) => {
    try {
        const item = await model.find().select("_id serviceRequestNo serviceTicketNo serviceMasterId typeApproved customerId briefDiscussion ticketDate statusType serviceStatus customerAccepectStatus customizeFlag").populate({
            path: "serviceMasterId",
            select: "_id serviceCategoryId serviceModel serviceName description",
            populate: [
                {
                    path: "serviceCategoryId",
                    model: "mainServiceCategory"
                }
            ]
        }).populate("oneServiseCategory").lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const getByMonthKey = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: [
                        {
                            path: "milestoneMasterId",
                            model: "MilestoneMaster"
                        },
                        {
                            path: "groupHead",
                            model: "Option"
                        },
                    ]
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();
        const filtterData = [];
        item.allMilestoneData.map((oneItem) => {
            if (oneItem.monthKey === Number(req.params.key)) {
                filtterData.push(oneItem);
            }
        });
        return res.status(200).send(filtterData);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateAllMileStone = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { allMilestoneData: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { allMilestoneData: arr } }, { new: true });
};



const updateOneMilestoneById = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: [
                        {
                            path: "milestoneMasterId",
                            model: "MilestoneMaster"
                        },
                        {
                            path: "groupHead",
                            model: "Option"
                        },
                    ]
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();
        let data = [];
        let myChangeDataShow = [];
        item.allMilestoneData.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.amId) {
                let changeData = {
                    milestoneId: oneItem.milestoneId,
                    groupHead: oneItem.groupHead,
                    updateDate: oneItem.updateDate,
                    month: oneItem.month,
                    billable: oneItem.billable,
                    amount: oneItem.amount,
                    calenderId: oneItem.calenderId,
                    monthKey: oneItem.monthKey,
                    paidAmount: oneItem.paidAmount,
                    balanceAmount: oneItem.balanceAmount,
                    GSTAmount: oneItem.GSTAmount,
                    paymentStatus: oneItem.paymentStatus,
                    fillingDueDate: req.body.fillingDueDate,
                    status: req.body.status,
                    date: req.body.date,
                    remark: req.body.remark,
                    _id: oneItem._id
                };
                data.push(changeData);
                myChangeDataShow.push(changeData);
            } else {
                data.push(oneItem);
            }
        });
        updateAllMileStone(model, req.params.stId, data);
        return res.status(200).send(myChangeDataShow[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateMlstnByTrxnIdMlstnId = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { allMilestoneData: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { allMilestoneData: arr } }, { new: true });
};



const updateMilestoneByTrxnIdAndMlstnId = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: [
                        {
                            path: "milestoneMasterId",
                            model: "MilestoneMaster"
                        },
                        {
                            path: "groupHead",
                            model: "Option"
                        },
                    ]
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();
        let data = [];
        let myChangeDataShow = [];
        item.allMilestoneData.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.amId) {
                let changeData = {
                    _id: oneItem._id,
                    milestoneId: oneItem.milestoneId,
                    groupHead: oneItem.groupHead,
                    updateDate: oneItem.updateDate,
                    month: oneItem.month,
                    billable: oneItem.billable,
                    amount: oneItem.amount,
                    calenderId: oneItem.calenderId,
                    monthKey: oneItem.monthKey,
                    fillingDueDate: oneItem.fillingDueDate,
                    status: oneItem.status,
                    date: oneItem.date,
                    remark: oneItem.remark,
                    paidAmount: oneItem.amount,
                    balanceAmount: 0,
                    GSTAmount: req.body.GSTAmount,
                    paymentStatus: "Paid"
                };
                data.push(changeData);
                myChangeDataShow.push(changeData);
            } else {
                data.push(oneItem);
            }
        });
        updateMlstnByTrxnIdMlstnId(model, req.params.stId, data);
        return res.status(200).send(myChangeDataShow[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneMilestoneDataByServiceTrxnId = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: [
                        {
                            path: "milestoneMasterId",
                            model: "MilestoneMaster"
                        },
                        {
                            path: "groupHead",
                            model: "Option"
                        },
                    ]
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();
        let oneMilestonedata = [];
        item.allMilestoneData.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.omId) {
                oneMilestonedata.push(oneItem);
            }
        });
        return res.status(200).send(oneMilestonedata[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const updateaddTemplateArr = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { addTemplateArr: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { addTemplateArr: arr } }, { new: true });
};


const updateOneAddTemplateArrayById = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).lean().exec();
        let data = [];
        let myChangeDataShow = [];
        item.addTemplateArr.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.ataId) {
                let changeData = {
                    templateName: oneItem.templateName,
                    templateFile: oneItem.templateFile,
                    uploadFilledFrom: req.body.uploadFilledFrom,
                    createdAt: oneItem.createdAt,
                    updatedAt: oneItem.updatedAt,
                    _id: oneItem._id
                };
                data.push(changeData);
                myChangeDataShow.push(changeData);
            } else {
                data.push(oneItem);
            }
        });
        updateaddTemplateArr(model, req.params.stId, data);
        return res.status(200).send(myChangeDataShow[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const deleteTemplateArr = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { addTemplateArr: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { addTemplateArr: arr } }, { new: true });
};



const deleteOneAddTemplateArrayById = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).lean().exec();
        let data = [];
        let myChangeDataShow = [];
        item.addTemplateArr.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.ataId) {
                let changeData = {
                    templateName: oneItem.templateName,
                    templateFile: oneItem.templateFile,
                    createdAt: oneItem.createdAt,
                    updatedAt: oneItem.updatedAt,
                    _id: oneItem._id
                };
                data.push(changeData);
                myChangeDataShow.push(changeData);
            } else {
                data.push(oneItem);
            }
        });
        deleteTemplateArr(model, req.params.stId, data);
        return res.status(200).send(myChangeDataShow[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).populate({
            path: "serviceMasterId",
            model: "serviceMasterNew",
            populate: [
                {
                    path: "serviceCategoryId",
                    model: "mainServiceCategory"
                },
                {
                    path: "bundleServiceArr",
                    model: "serviceMasterNew",
                    select: "_id serviceName",
                },
                {
                    path: "GSTApplicableInter",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "GSTApplicableIntra",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "GSTApplicableInterUt",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "TDSApplicable",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "serviceMilestone",
                    model: "serviceMilestoneNew",
                    populate: {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                },
                {
                    path: "documentRequired",
                    model: "documentRequiredNew",
                },
                {
                    path: "addTemplate",
                    model: "addTemplateNew",
                },
                {
                    path: "relatedServices",
                    model: "serviceMasterNew",
                }
            ]
        }).populate("financialYearId").populate("customerId").populate("assignedTo").populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    }
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).populate("oneServiseCategory").lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneByCustomerId = (model) => async (req, res) => {
    try {
        const item = await model.find({ customerId: req.params.id }).select("_id serviceRequestNo serviceTicketNo serviceStatus statusType ticketDate typeApproved typeNew typeReject").populate({
            path: "serviceMasterId",
            select: "serviceName",
        }).lean().exec();
        return res.status(200).send(item.reverse());

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneByAssignedToId = (model) => async (req, res) => {
    try {
        const item = await model.find({ assignedTo: req.params.id }).select("_id serviceRequestNo serviceTicketNo serviceStatus statusType ticketDate typeApproved typeNew typeReject").populate({
            path: "serviceMasterId",
            select: "serviceName",
        }).lean().exec();
        return res.status(200).send(item.reverse());

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneByStatusType = (model) => async (req, res) => {
    try {
        const item = await model.find({ statusType: req.params.id }).populate({
            path: "serviceMasterId",
            model: "serviceMasterNew",
            populate: [
                {
                    path: "serviceCategoryId",
                    model: "mainServiceCategory"
                },
                {
                    path: "GSTApplicableInter",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "GSTApplicableIntra",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "GSTApplicableInterUt",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "TDSApplicable",
                    model: "taxGroup",
                    populate: {
                        path: "taxGroup",
                        model: "taxMaster"
                    },
                },
                {
                    path: "serviceMilestone",
                    model: "serviceMilestoneNew",
                    populate: {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    },
                },
                {
                    path: "documentRequired",
                    model: "documentRequiredNew",
                },
                {
                    path: "addTemplate",
                    model: "addTemplateNew",
                },
                {
                    path: "relatedServices",
                    model: "serviceMasterNew",
                }
            ]
        }).populate("financialYearId").populate("customerId").populate("assignedTo").populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: {
                        path: "milestoneMasterId",
                        model: "MilestoneMaster"
                    }
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();
        return res.status(200).send(item.reverse());

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateStatuoryPayment = (model) => async (req, res) => {
    try {

        const payLoad = {
            challanDetails: req.body.challanDetails,
            challanNo: req.body.challanNo,
            amountPaid: req.body.amountPaid,
            payDate: req.body.payDate,
            natureOfPayment: req.body.natureOfPayment,
            uploadChallan: req.body.uploadChallan,
            status: req.body.status,
            userName: req.body.userName,
        };

        const item = await model.findByIdAndUpdate(req.params.id, {
            $push: {
                statuoryPayments: payLoad
            }
        }, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const update = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, {
            typeNew: req.body.typeNew,
            typeApproved: req.body.typeApproved,
            typeReject: req.body.typeReject,
            statusType: req.body.statusType,
            completedStatus: req.body.completedStatus,
            assignedTo: req.body.assignedTo,
            assignedToComments: req.body.assignedToComments,
            customerAccepectStatus: req.body.customerAccepectStatus,
            customerRejectRegion: req.body.customerRejectRegion,
        }, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateDocuments = (model) => async (req, res) => {
    try {

        let payLoad = {
            documentName: req.body.documentName,
            path: req.body.path,
            otherDocument: req.body.otherDocument,
            deleteType: req.body.deleteType,
            uploadDate: moment().format("DD/MM/YYYY"),
            uploadTime: moment().tz("Asia/Kolkata").format("h:mm:ss A"),
        };
        const item = await model.findByIdAndUpdate(req.params.id, {
            $push: {
                documents: payLoad
            }
        }, { new: true });
        return res.status(200).send(item.documents);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const deleteDocument = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { documents: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { documents: arr } }, { new: true });
};



const deleteUpdateDocuments = (model) => async (req, res) => {
    try {
        const data = await model.findById(req.params.id).lean().exec();
        let temp = [];
        let deleteItem = [];
        data.documents.map((child) => {
            if (child._id.toString() !== req.params.docId) {
                temp.push(child);
            } else {
                deleteItem.push(child);
            }
        });
        deleteDocument(model, req.params.id, temp);
        return res.status(200).json(deleteItem[0]);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const providerUploadDocuments = (model) => async (req, res) => {
    try {

        let payLoad = {
            documentName: req.body.documentName,
            uploadDocument: req.body.uploadDocument,
            uploadDate: moment().format("DD/MM/YYYY"),
        };
        const item = await model.findByIdAndUpdate(req.params.id, {
            $push: {
                providerUploadDocuments: payLoad
            }
        }, { new: true });
        return res.status(200).send(item.providerUploadDocuments);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const deleteProDocument = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { providerUploadDocuments: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { providerUploadDocuments: arr } }, { new: true });
};



const deleteProviderDocuments = (model) => async (req, res) => {
    try {
        const data = await model.findById(req.params.id).lean().exec();
        let temp = [];
        let deleteItem = [];
        data.providerUploadDocuments.map((child) => {
            if (child._id.toString() !== req.params.docId) {
                temp.push(child);
            } else {
                deleteItem.push(child);
            }
        });
        deleteProDocument(model, req.params.id, temp);
        return res.status(200).json(deleteItem[0]);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const providerNotes = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerNotes: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerNotes);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerNotes: {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerNotes);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const updateadProviderNotes = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { providerNotes: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { providerNotes: arr } }, { new: true });
};



const updateProviderNotes = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerNotes.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.pnId) {
                    if (oneItem.customerComment === undefined) {
                        let changeData = {
                            providerComment: req.body.providerComment,
                            providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            providerComment: req.body.providerComment,
                            providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            customerComment: oneItem.customerComment,
                            customerDateTime: oneItem.customerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateadProviderNotes(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerNotes.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.pnId) {
                    let changeData = {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        providerComment: oneItem.providerComment,
                        providerDateTime: oneItem.providerDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateadProviderNotes(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const customerNotes = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    customerNotes: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.customerNotes);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    customerNotes: {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.customerNotes);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const updateadCustomerNotes = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { customerNotes: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { customerNotes: arr } }, { new: true });
};



const updateCustomerNotes = (model) => async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.customerNotes.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.cnId) {
                    let changeData = {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        providerComment: oneItem.providerComment,
                        providerDateTime: oneItem.providerDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateadCustomerNotes(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.customerNotes.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.cnId) {
                    if (oneItem.customerComment === undefined) {
                        let changeData = {
                            providerComment: req.body.providerComment,
                            providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            providerComment: req.body.providerComment,
                            providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            customerComment: oneItem.customerComment,
                            customerDateTime: oneItem.customerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateadCustomerNotes(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const adminCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminComment);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminComment: {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};





const updateAdadminComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { adminComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { adminComment: arr } }, { new: true });
};



const updateAdminCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.acId) {
                    if (oneItem.customerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            customerComment: oneItem.customerComment,
                            customerDateTime: oneItem.customerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateAdadminComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);

        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.acId) {
                    let changeData = {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateAdadminComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const customerCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.customerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    customerComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.customerComment);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    customerComment: {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.customerComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};





const updateCustomerComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { customerComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { customerComment: arr } }, { new: true });
};



const updateCustomerCommentFunc = (model) => async (req, res) => {
    try {

        if (req.body.adminComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.customerComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.ccId) {
                    let changeData = {
                        customerComment: req.body.customerComment,
                        customerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateCustomerComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.customerComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.ccId) {
                    if (oneItem.customerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            customerComment: oneItem.customerComment,
                            customerDateTime: oneItem.customerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateCustomerComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);

        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const adminProviderCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminProviderComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminProviderComment);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminProviderComment: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminProviderComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const updateadminProviderComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { adminProviderComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { adminProviderComment: arr } }, { new: true });
};



const updateAdminProviderCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminProviderComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.apId) {
                    if (oneItem.providerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            providerComment: oneItem.providerComment,
                            providerDateTime: oneItem.providerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateadminProviderComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);

        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminProviderComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.apId) {
                    let changeData = {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateadminProviderComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const providerAdminCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerAdminComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerAdminComment);
        } else {
            const item = await model.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerAdminComment: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerAdminComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const updateProviderAdminComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { providerAdminComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { providerAdminComment: arr } }, { new: true });
};



const updateProviderAdminCommentFunc = (model) => async (req, res) => {
    try {
        if (req.body.adminComment === undefined) {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerAdminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.paId) {
                    let changeData = {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateProviderAdminComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        } else {
            const item = await model.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerAdminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.paId) {
                    if (oneItem.providerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            providerComment: oneItem.providerComment,
                            providerDateTime: oneItem.providerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateProviderAdminComment(model, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const addServiceTicketByServiceTrxnId = (model) => async (req, res) => {
    try {
        const itemData = await model.findById(req.params.id).lean().exec();
        const serviceTicketData = itemData.serviceTicketNo;

        if (serviceTicketData === undefined) {

            let countData = await getCountForTicket();
            await ServiceTrxnForTicketCount.create({ serviceTicketNo: countData + 1 });

            await model.findByIdAndUpdate(req.params.id, { $push: { documents: req.body.documents } }, { new: true });

            const item = await model.findByIdAndUpdate(req.params.id, {
                serviceAmount: req.body.serviceAmount,
                paymentAmount: req.body.paymentAmount,
                serviceTicketNo: serviceTicketNo(countData),
            }, { new: true });

            return res.status(200).send(item);

        } else {

            await model.findByIdAndUpdate(req.params.id, { $push: { documents: req.body.documents } }, { new: true });

            const item = await model.findByIdAndUpdate(req.params.id, {
                serviceAmount: req.body.serviceAmount,
                paymentAmount: req.body.paymentAmount,
            }, { new: true });

            return res.status(200).send(item);

        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getAllMilestoneByTrxnId = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).populate({
            path: "allMilestoneData",
            populate: [
                {
                    path: "milestoneId",
                    model: "serviceMilestoneNew",
                    populate: [
                        {
                            path: "milestoneMasterId",
                            model: "MilestoneMaster"
                        },
                        {
                            path: "groupHead",
                            model: "Option"
                        },
                    ]
                },
                {
                    path: "calenderId",
                    model: "Calendar",
                    populate: {
                        path: "milestone",
                        model: "MilestoneMaster"
                    }
                },
            ]
        }).lean().exec();

        let allMiletoneData = item.allMilestoneData;
        let newData = [];

        for (let i = 0; i < allMiletoneData.length; i++) {
            let oneItem = allMiletoneData[i];
            if (oneItem.milestoneId.milestoneMasterId.milestoneName !== "Advance Payment") {
                newData.push(oneItem);
            }
        }

        return res.status(200).send(newData);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const createBundleService = (model) => async (req, res) => {
    try {
        let countData = await getCount();
        req.body.serviceRequestNo = serviceRequestNo(countData);
        req.body.ticketDate = moment().format("DD/MM/YYYY");
        req.body.isBundleServiceTrxn = true;
        const item = await model.create(req.body);

        await ServiceTransactionNewCount.create({ serviceTicketNoCount: countData + 1 });

        let serviceRequestNoData = item.serviceRequestNo;
        let idData = item._id;

        const serviceMasterNewData = await ServiceMasterNew.create({
            serviceModel: "Customize",
            serviceName: "Bundle Service " + "BS" + countData,
            serviceTransactionId: idData,
            serviceTransactionRequestNo: serviceRequestNoData,
            bundleServiceArr: req.body.bundleServiceArr,
            isBundleServiceMgmt: true,
        });

        let mgmtDataId = serviceMasterNewData._id;

        const newTrxnData = await model.findByIdAndUpdate(idData, { serviceMasterId: mgmtDataId }, { new: true });
        return res.status(200).send(newTrxnData);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};





const updateOneDocumentsId = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { documents: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { documents: arr } }, { new: true });
};


const updateOneDocumentsByTrxnId = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.stId).lean().exec();
        let documentData = item.documents;
        let data = [];
        let myChangeDataShow = [];
        documentData.map((oneItem) => {
            if ((oneItem._id).toString() === req.params.docId) {
                let changeData = {
                    documentName: oneItem.documentName,
                    path: req.body.path,
                    otherDocument: oneItem.otherDocument,
                    deleteType: oneItem.deleteType,
                    uploadDate: moment().format("DD/MM/YYYY"),
                    uploadTime: moment().tz("Asia/Kolkata").format("h:mm:ss A"),
                    _id: oneItem._id
                };
                data.push(changeData);
                myChangeDataShow.push(changeData);
            } else {
                data.push(oneItem);
            }
        });
        updateOneDocumentsId(model, req.params.stId, data);
        return res.status(200).send(myChangeDataShow[0]);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const deleteOne = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



module.exports = (model, MgmtModel) => ({
    create: create(model),
    createBundleService: createBundleService(model),
    createMilestoneByServiceMgmtId: createMilestoneByServiceMgmtId(MgmtModel),
    get: get(model),
    getAllMilestoneByTrxnId: getAllMilestoneByTrxnId(model),
    getOneByStatusType: getOneByStatusType(model),
    getOne: getOne(model),
    getByMonthKey: getByMonthKey(model),
    getOneByCustomerId: getOneByCustomerId(model),
    getOneByAssignedToId: getOneByAssignedToId(model),
    update: update(model),
    updateDocuments: updateDocuments(model),
    deleteUpdateDocuments: deleteUpdateDocuments(model),
    providerUploadDocuments: providerUploadDocuments(model),
    deleteProviderDocuments: deleteProviderDocuments(model),
    providerNotes: providerNotes(model),
    updateProviderNotes: updateProviderNotes(model),
    customerNotes: customerNotes(model),
    updateCustomerNotes: updateCustomerNotes(model),
    adminCommentFunc: adminCommentFunc(model),
    updateAdminCommentFunc: updateAdminCommentFunc(model),
    customerCommentFunc: customerCommentFunc(model),
    updateCustomerCommentFunc: updateCustomerCommentFunc(model),
    updateOneMilestoneById: updateOneMilestoneById(model),
    updateStatuoryPayment: updateStatuoryPayment(model),
    updateOneAddTemplateArrayById: updateOneAddTemplateArrayById(model),
    updateServicesTrxnByServiseMgmtId: updateServicesTrxnByServiseMgmtId(model),
    deleteOneAddTemplateArrayById: deleteOneAddTemplateArrayById(model),
    addServiceTicketByServiceTrxnId: addServiceTicketByServiceTrxnId(model),
    updateMilestoneByTrxnIdAndMlstnId: updateMilestoneByTrxnIdAndMlstnId(model),
    adminProviderCommentFunc: adminProviderCommentFunc(model),
    updateAdminProviderCommentFunc: updateAdminProviderCommentFunc(model),
    providerAdminCommentFunc: providerAdminCommentFunc(model),
    updateProviderAdminCommentFunc: updateProviderAdminCommentFunc(model),
    getOneMilestoneDataByServiceTrxnId: getOneMilestoneDataByServiceTrxnId(model),
    updateOneDocumentsByTrxnId: updateOneDocumentsByTrxnId(model),
    deleteOne: deleteOne(model),
});


