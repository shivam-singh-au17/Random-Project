const Joi = require("joi");

module.exports = {

    create: Joi.object({
        serviceMasterId: Joi.string().required(),
        briefDiscussion: Joi.string(),
        financialYearId: Joi.string().required(),
        customerId: Joi.string().required(),
        typeNew: Joi.boolean(),
        typeApproved: Joi.boolean(),
        typeReject: Joi.boolean(),
        statusType: Joi.string(),
        completedStatus: Joi.string(),
        documents: Joi.array(),
        serviceAmount: Joi.number().required(),
        paymentAmount: Joi.number().required(),
        isCustomized: Joi.boolean().required(),
        assignedTo: Joi.string(),
        assignedToComments: Joi.string(),
        serviceStatus: Joi.boolean().required(),
        userMonthChoice: Joi.number(),
        customerAccepectStatus: Joi.boolean(),
        customerRejectRegion: Joi.string(),
        oneServiseCategory: Joi.string(),
        allMilestoneData: Joi.array(),

    }),

    createBundleService: Joi.object({
        bundleServiceArr: Joi.array(),
        serviceMasterId: Joi.string(),
        briefDiscussion: Joi.string(),
        financialYearId: Joi.string(),
        customerId: Joi.string(),
        typeNew: Joi.boolean(),
        typeApproved: Joi.boolean(),
        typeReject: Joi.boolean(),
        statusType: Joi.string(),
        completedStatus: Joi.string(),
        documents: Joi.array(),
        serviceAmount: Joi.number(),
        paymentAmount: Joi.number(),
        isCustomized: Joi.boolean(),
        assignedTo: Joi.string(),
        assignedToComments: Joi.string(),
        serviceStatus: Joi.boolean(),
        userMonthChoice: Joi.number(),
        customerAccepectStatus: Joi.boolean(),
        customerRejectRegion: Joi.string(),
        oneServiseCategory: Joi.string(),
        allMilestoneData: Joi.array(),

    }),


    update: Joi.object({
        serviceMasterId: Joi.string(),
        briefDiscussion: Joi.string(),
        financialYearId: Joi.string(),
        customerId: Joi.string(),
        typeNew: Joi.boolean(),
        typeApproved: Joi.boolean(),
        typeReject: Joi.boolean(),
        statusType: Joi.string(),
        completedStatus: Joi.string(),
        documents: Joi.array(),
        serviceAmount: Joi.number(),
        paymentAmount: Joi.number(),
        isCustomized: Joi.boolean(),
        assignedTo: Joi.string(),
        assignedToComments: Joi.string(),
        serviceStatus: Joi.boolean(),
        userMonthChoice: Joi.number(),
        customerAccepectStatus: Joi.boolean(),
        customerRejectRegion: Joi.string(),
        oneServiseCategory: Joi.string(),
        allMilestoneData: Joi.array(),
    }),

    updateStatuoryPayment: Joi.object({
        challanDetails: Joi.string().required(),
        challanNo: Joi.string().required(),
        amountPaid: Joi.number().required(),
        payDate: Joi.string().required(),
        natureOfPayment: Joi.string().required(),
        uploadChallan: Joi.string().required(),
        status: Joi.string().required(),
        userName: Joi.string().required(),
    }),

    updateOneMilestoneById: Joi.object({
        milestoneId: Joi.string(),
        groupHead: Joi.string(),
        updateDate: Joi.string(),
        month: Joi.string(),
        billable: Joi.boolean(),
        amount: Joi.number(),
        calenderId: Joi.string(),
        monthKey: Joi.number(),
        fillingDueDate: Joi.string(),
        status: Joi.string(),
        date: Joi.string(),
        remark: Joi.string(),
    }),

    updateOneAddTemplateArrayById: Joi.object({
        uploadFilledFrom: Joi.string(),
    }),

    updateDocuments: Joi.object({
        documentName: Joi.string().required(),
        path: Joi.string().required(),
        otherDocument: Joi.string(),
        deleteType: Joi.boolean(),
    }),

    providerUploadDocuments: Joi.object({
        documentName: Joi.string().required(),
        uploadDocument: Joi.string().required(),
    }),

    providerNotes: Joi.object({
        customerComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    updateProviderNotes: Joi.object({
        customerComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    customerNotes: Joi.object({
        customerComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    updateCustomerNotes: Joi.object({
        customerComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    adminCommentFunc: Joi.object({
        adminComment: Joi.string(),
        customerComment: Joi.string(),
    }),

    updateAdminCommentFunc: Joi.object({
        adminComment: Joi.string(),
        customerComment: Joi.string(),
    }),

    customerCommentFunc: Joi.object({
        customerComment: Joi.string(),
        adminComment: Joi.string(),
    }),

    updateCustomerCommentFunc: Joi.object({
        customerComment: Joi.string(),
        adminComment: Joi.string(),
    }),

    adminProviderCommentFunc: Joi.object({
        adminComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    updateAdminProviderCommentFunc: Joi.object({
        adminComment: Joi.string(),
        providerComment: Joi.string(),
    }),

    providerAdminCommentFunc: Joi.object({
        providerComment: Joi.string(),
        adminComment: Joi.string(),
    }),

    updateProviderAdminCommentFunc: Joi.object({
        providerComment: Joi.string(),
        adminComment: Joi.string(),
    }),

    updateMilestoneByTrxnIdAndMlstnId: Joi.object({
        GSTAmount: Joi.number(),
    }),

    updateOneDocumentsByTrxnId: Joi.object({
        path: Joi.string(),
    }),

};

