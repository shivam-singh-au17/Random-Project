const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationServiceTransactionNew = require("./validation");
const { ServiceTransactionNew } = require("../../models/serviceTransactionNew");
const { ServiceMasterNew } = require("../../models/serviceMasterNew");
const serviceTransactionNewService = require("./service");


router.post("/serviceTransactionNew/", validateParams(validationServiceTransactionNew.create), serviceTransactionNewService(ServiceTransactionNew).create);
router.post("/createBundleService/", validateParams(validationServiceTransactionNew.createBundleService), serviceTransactionNewService(ServiceTransactionNew).createBundleService);


router.get("/serviceTransactionNews/", serviceTransactionNewService(ServiceTransactionNew).get);
router.get("/serviceTransactionNews/:id", serviceTransactionNewService(ServiceTransactionNew).getOneByStatusType);
router.get("/serviceTransactionNew/:id", serviceTransactionNewService(ServiceTransactionNew).getOne);
router.get("/getAllMilestoneByTrxnId/:id", serviceTransactionNewService(ServiceTransactionNew).getAllMilestoneByTrxnId);
router.get("/serviceTransactionNewByMonthKey/:id/:key", serviceTransactionNewService(ServiceTransactionNew).getByMonthKey);
router.get("/serviceTransactionNewByCustomerId/:id", serviceTransactionNewService(ServiceTransactionNew).getOneByCustomerId);
router.get("/serviceTransactionNewByAssignedToId/:id", serviceTransactionNewService(ServiceTransactionNew).getOneByAssignedToId);
router.get("/createMilestoneByServiceMgmtId/:id", serviceTransactionNewService(ServiceTransactionNew, ServiceMasterNew).createMilestoneByServiceMgmtId);
router.get("/getOneMilestoneDataByServiceTrxnId/:stId/:omId", serviceTransactionNewService(ServiceTransactionNew).getOneMilestoneDataByServiceTrxnId);


router.patch("/serviceTransactionNew/:id", validateParams(validationServiceTransactionNew.update), serviceTransactionNewService(ServiceTransactionNew).update);
router.patch("/serviceTrxnUpdateDocuments/:id", validateParams(validationServiceTransactionNew.updateDocuments), serviceTransactionNewService(ServiceTransactionNew).updateDocuments);
router.patch("/serviceTrxnProviderDocuments/:id", validateParams(validationServiceTransactionNew.providerUploadDocuments), serviceTransactionNewService(ServiceTransactionNew).providerUploadDocuments);
router.patch("/serviceTrxnProviderNotes/:id", validateParams(validationServiceTransactionNew.providerNotes), serviceTransactionNewService(ServiceTransactionNew).providerNotes);
router.patch("/serviceTrxnCustomerNotes/:id", validateParams(validationServiceTransactionNew.customerNotes), serviceTransactionNewService(ServiceTransactionNew).customerNotes);
router.patch("/serviceTrxnAdminComment/:id", validateParams(validationServiceTransactionNew.adminCommentFunc), serviceTransactionNewService(ServiceTransactionNew).adminCommentFunc);
router.patch("/serviceTrxnCustomerComment/:id", validateParams(validationServiceTransactionNew.customerCommentFunc), serviceTransactionNewService(ServiceTransactionNew).customerCommentFunc);
router.patch("/updateStatuoryPayment/:id", validateParams(validationServiceTransactionNew.updateStatuoryPayment), serviceTransactionNewService(ServiceTransactionNew).updateStatuoryPayment);
router.patch("/updateOneMilestoneById/:stId/:amId", validateParams(validationServiceTransactionNew.updateOneMilestoneById), serviceTransactionNewService(ServiceTransactionNew).updateOneMilestoneById);
router.patch("/updateMilestoneByTrxnIdAndMlstnId/:stId/:amId", validateParams(validationServiceTransactionNew.updateMilestoneByTrxnIdAndMlstnId), serviceTransactionNewService(ServiceTransactionNew).updateMilestoneByTrxnIdAndMlstnId);
router.patch("/updateOneAddTemplateArrayById/:stId/:ataId", validateParams(validationServiceTransactionNew.updateOneAddTemplateArrayById), serviceTransactionNewService(ServiceTransactionNew).updateOneAddTemplateArrayById);
router.patch("/updateProviderNotes/:stId/:pnId", validateParams(validationServiceTransactionNew.updateProviderNotes), serviceTransactionNewService(ServiceTransactionNew).updateProviderNotes);
router.patch("/updateCustomerNotes/:stId/:cnId", validateParams(validationServiceTransactionNew.updateCustomerNotes), serviceTransactionNewService(ServiceTransactionNew).updateCustomerNotes);
router.patch("/updateAdminComment/:stId/:acId", validateParams(validationServiceTransactionNew.updateAdminCommentFunc), serviceTransactionNewService(ServiceTransactionNew).updateAdminCommentFunc);
router.patch("/updateCustomerComment/:stId/:ccId", validateParams(validationServiceTransactionNew.updateCustomerCommentFunc), serviceTransactionNewService(ServiceTransactionNew).updateCustomerCommentFunc);
router.patch("/updateServicesTrxnByServiseMgmtId/:id", serviceTransactionNewService(ServiceTransactionNew).updateServicesTrxnByServiseMgmtId);
router.patch("/addServiceTicketByServiceTrxnId/:id", serviceTransactionNewService(ServiceTransactionNew).addServiceTicketByServiceTrxnId);
router.patch("/adminProviderCommentFunc/:id", validateParams(validationServiceTransactionNew.adminProviderCommentFunc), serviceTransactionNewService(ServiceTransactionNew).adminProviderCommentFunc);
router.patch("/updateAdminProviderCommentFunc/:stId/:apId", validateParams(validationServiceTransactionNew.updateAdminProviderCommentFunc), serviceTransactionNewService(ServiceTransactionNew).updateAdminProviderCommentFunc);
router.patch("/providerAdminCommentFunc/:id", validateParams(validationServiceTransactionNew.providerAdminCommentFunc), serviceTransactionNewService(ServiceTransactionNew).providerAdminCommentFunc);
router.patch("/updateProviderAdminCommentFunc/:stId/:paId", validateParams(validationServiceTransactionNew.updateProviderAdminCommentFunc), serviceTransactionNewService(ServiceTransactionNew).updateProviderAdminCommentFunc);
router.patch("/updateOneDocumentsByTrxnId/:stId/:docId", validateParams(validationServiceTransactionNew.updateOneDocumentsByTrxnId), serviceTransactionNewService(ServiceTransactionNew).updateOneDocumentsByTrxnId);


router.delete("/serviceTransactionNew/:id", serviceTransactionNewService(ServiceTransactionNew).deleteOne);
router.delete("/deleteUpdateDocuments/:id/:docId", serviceTransactionNewService(ServiceTransactionNew).deleteUpdateDocuments);
router.delete("/deleteProviderDocuments/:id/:docId", serviceTransactionNewService(ServiceTransactionNew).deleteProviderDocuments);
router.delete("/deleteOneAddTemplateArrayById/:stId/:ataId", serviceTransactionNewService(ServiceTransactionNew).deleteOneAddTemplateArrayById);


module.exports = router;

