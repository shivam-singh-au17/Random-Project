const { MilestoneMaster } = require("../../models");


exports.create = async (req, res) => {
    try {
        let advancePaymentData = await MilestoneMaster.find({ isAdvancePayment: true }).lean().exec();
        if (advancePaymentData[0] !== undefined && req.body.isAdvancePayment === true) {
            return res.status(500).json({ error: "Advance payment milestone is already available, you can edit it and if you want to create a new one, first delete it then create a new one" });
        } else {
            const item = await MilestoneMaster.create(req.body);
            return res.status(200).send(item);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


exports.get = async (req, res) => {
    try {
        let milestoneQuery = MilestoneMaster.find();
        if (!isNaN(parseInt(req.query.skip)))
            milestoneQuery = milestoneQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            milestoneQuery = milestoneQuery.limit(parseInt(req.query.limit));
        let milestone = await milestoneQuery;
        res.json(milestone);
    } catch (err) {
        res.send("Error " + err);
    }
};


exports.getbyId = async (req, res) => {
    try {
        const item = await MilestoneMaster.findById(req.params.id).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


exports.delete = async (req, res) => {
    try {
        const item = await MilestoneMaster.findByIdAndDelete(req.params.id);
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }

};


exports.update = async (req, res) => {
    try {

        let advanceData = await MilestoneMaster.find({ isAdvancePayment: true }).lean().exec();
        if (advanceData[0] === undefined || (advanceData[0]._id).toString() === req.params.id || (advanceData[0] !== undefined && req.body.isAdvancePayment === false)) {
            const item = await MilestoneMaster.findByIdAndUpdate(req.params.id, req.body, { new: true });
            return res.status(200).send(item);
        } else {
            return res.status(500).json({ error: "Advance payment milestone is already available, you can edit it and if you want to create a new one, first delete it then create a new one" });
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }

};
