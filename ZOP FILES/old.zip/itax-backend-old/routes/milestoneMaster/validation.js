const Joi = require("joi");

module.exports = {
    create: Joi.object({
        milestoneName: Joi.string().required(),
        milestoneFrequency: Joi.string().required(),
        billable: Joi.boolean(),
        filing: Joi.boolean(),
        status: Joi.boolean(),
        isAdvancePayment: Joi.boolean(),
    }),
    update: Joi.object({
        milestoneName: Joi.string().required(),
        milestoneFrequency: Joi.string().required(),
        billable: Joi.boolean(),
        filing: Joi.boolean(),
        status: Joi.boolean(),
        isAdvancePayment: Joi.boolean(),

    }),
};
