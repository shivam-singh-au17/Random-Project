const express = require("express");
const router = express.Router();
const milestoneMasterValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const milestoneMasterService = require("./service");

router.post(
    "/milestoneMaster",
    validateParams(milestoneMasterValidation.create),
    milestoneMasterService.create
);

router.get(
    "/milestoneMasters",
    milestoneMasterService.get
);


router.get(
    "/milestoneMaster/:id",
    milestoneMasterService.getbyId
);

router.delete(
    "/milestoneMaster/:id",
    milestoneMasterService.delete
);

router.patch(
    "/milestoneMaster/:id",
    validateParams(milestoneMasterValidation.update),
    milestoneMasterService.update
);

module.exports = router;
