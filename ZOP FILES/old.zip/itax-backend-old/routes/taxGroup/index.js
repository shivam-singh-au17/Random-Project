const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationTaxGroup = require("./validation");
const { TaxGroup } = require("../../models/taxGroup");
const taxGroupService = require("./service");

router.post("/taxGroup/", validateParams(validationTaxGroup.create), taxGroupService(TaxGroup).create);
router.get("/taxGroups/", taxGroupService(TaxGroup).get);
router.get("/taxGroup/:id", taxGroupService(TaxGroup).getOne);
router.put("/taxGroup/:id", validateParams(validationTaxGroup.update), taxGroupService(TaxGroup).update);
router.delete("/taxGroup/:id", taxGroupService(TaxGroup, "taxGroup").deleteOne);

module.exports = router;
