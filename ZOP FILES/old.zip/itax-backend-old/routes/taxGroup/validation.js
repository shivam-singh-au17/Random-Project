const Joi = require("joi");

module.exports = {
    create: Joi.object({
        taxGroupName: Joi.string().required(),
        taxGroup: Joi.array().required(),
    }),
    update: Joi.object({
        taxGroupName: Joi.string().required(),
        taxGroup: Joi.array().required(),
    }),
};

