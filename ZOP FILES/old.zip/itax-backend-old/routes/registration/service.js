const { Registeration, authFrontend } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");
const moment = require("moment-timezone");

exports.create = async (req, res) => {
    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    let fullDate = `${day}-${month}-${year}`;
    const registration = new Registeration({
        service_provider_id: req.body.service_provider_id,
        approval_status: req.body.approval_status,
        email_id: req.body.email_id,
        profile_type: req.body.profile_type,
        first_name: req.body.first_name,
        middle_name: req.body.middle_name,
        last_name: req.body.last_name,
        address_1: req.body.address_1,
        address_2: req.body.address_2,
        mobile: req.body.mobile,
        total_year_of_exp: req.body.total_year_of_exp,
        country: req.body.country,
        overseas: req.body.overseas,
        locality: req.body.locality,
        state: req.body.state,
        city: req.body.city,
        working_since: req.body.working_since,
        pin_code: req.body.pin_code,
        facebook_link: req.body.facebook_link,
        twitter_link: req.body.twitter_link,
        linkedin_link: req.body.linkedin_link,
        instagram_link: req.body.instagram_link,
        upload_photo: req.body.upload_photo,
        upload_biodata: req.body.upload_biodata,
        dateRegistration: fullDate,
    });

    try {
        const a1 = await registration.save();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};



exports.get = async (req, res) => {
    try {
        let query;
        if (req.query.approval_status === "true") {
            query = { approval_status: true };
        }
        else if (req.query.approval_status === "false") {
            query = { approval_status: false };
        }
        if (req.query.key)
            query = { ...query, $text: { $search: req.query.key } };
        let registration = Registeration.find(query).populate("service_provider_id");
        if (!isNaN(parseInt(req.query.skip)))
            registration = registration.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            registration = registration.limit(parseInt(req.query.limit));
        let registrations = await registration;
        registrations = await Promise.all(registrations.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.upload_photo);
                } catch {
                    readURL = { url: undefined };
                }
                let imageURL;
                try {
                    imageURL = await generateReadSignedURL(i.upload_biodata);
                } catch {
                    imageURL = { url: undefined };
                }
                let documents = await imageMaping(i);
                return { ...i._doc, upload_photo: readURL, upload_biodata: imageURL, documents: documents.documents, qualification: documents.qualification, bankDetail: documents.bankDetail };
            }));
        res.json(registrations);
    } catch (err) {
        res.send("Error " + err);
    }
};



exports.getbyId = async (req, res) => {
    try {
        const registration = await Registeration.findById(req.params.id);
        const nextCheck = await authFrontend.findById(registration.service_provider_id);
        let readURL;
        try {
            readURL = await generateReadSignedURL(registration.upload_photo);
        } catch {
            readURL = { url: undefined };
        }
        let imageURL;
        try {
            imageURL = await generateReadSignedURL(registration.upload_biodata);
        } catch {
            imageURL = { url: undefined };
        }
        let documents = await imageMaping(registration);
        res.json({ ...registration._doc, service_provider_id: nextCheck, upload_photo: readURL, upload_biodata: imageURL, documents: documents.documents, qualification: documents.qualification, bankDetail: documents.bankDetail });
    } catch (err) {
        res.send("Error " + err);
    }
};
exports.delete = async (req, res) => {
    try {
        const registration = await Registeration.findById(req.params.id);
        const a1 = await registration.remove();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }

};



exports.update = async (req, res) => {
    try {
        const registration = await Registeration.findById(req.params.id);
        registration.service_provider_id = req.body.service_provider_id,
        registration.approval_status = req.body.approval_status,
        registration.email_id = req.body.email_id,
        registration.profile_type = req.body.profile_type,
        registration.first_name = req.body.first_name,
        registration.middle_name = req.body.middle_name,
        registration.last_name = req.body.last_name,
        registration.address_1 = req.body.address_1,
        registration.address_2 = req.body.address_2,
        registration.mobile = req.body.mobile,
        registration.total_year_of_exp = req.body.total_year_of_exp,
        registration.country = req.body.country,
        registration.overseas = req.body.overseas,
        registration.locality = req.body.locality,
        registration.state = req.body.state,
        registration.city = req.body.city,
        registration.working_since = req.body.working_since,
        registration.pin_code = req.body.pin_code,
        registration.facebook_link = req.body.facebook_link,
        registration.twitter_link = req.body.twitter_link,
        registration.linkedin_link = req.body.linkedin_link,
        registration.instagram_link = req.body.instagram_link,
        registration.upload_photo = req.body.upload_photo,
        registration.upload_biodata = req.body.upload_biodata;
        const a1 = await registration.save();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }

};



exports.createQualification = async (req, res) => {
    const qualify = Registeration.findByIdAndUpdate(req.params.id, { $set: { qualification: req.body.qualification } });
    try {
        const a1 = await qualify.exec();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};



exports.createbankDetails = async (req, res) => {
    const bank = Registeration.findByIdAndUpdate(req.params.id, { $set: { bankDetail: req.body.bankDetail } });
    try {
        const a1 = await bank.exec();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};



exports.createDocuments = async (req, res) => {
    const customer = Registeration.findByIdAndUpdate(req.params.id, { $set: { documents: req.body.documents } });
    try {
        const a1 = await customer.exec();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};


let imageMaping = async (customer) => {
    customer = customer.toObject();
    let documents = await Promise.all(customer.documents.map(
        async j => {
            try {
                let pp = await generateReadSignedURL(j.adharCardFileUpload);
                j.adharCardFileUpload = pp;
            } catch {
                j.adharCardFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.panCardFileUpload);
                j.panCardFileUpload = pp;
            } catch {
                j.panCardFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.companyRegistrationFileUpload);
                j.companyRegistrationFileUpload = pp;
            } catch {
                j.companyRegistrationFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.gstRegistrationFileUpload);
                j.gstRegistrationFileUpload = pp;
            } catch {
                j.gstRegistrationFileUpload = { url: undefined };
            }

            return j;
        }
    ));
    let qualification = await Promise.all(customer.qualification.map(
        async j => {
            try {
                let pp = await generateReadSignedURL(j.chooseFile);
                j.chooseFile = pp;
            } catch {
                j.chooseFile = { url: undefined };
            }
            return j;
        }
    ));
    let bankDetail = await Promise.all(customer.bankDetail.map(
        async j => {
            try {
                let pp = await generateReadSignedURL(j.cancelledCheque);
                j.cancelledCheque = pp;
            } catch {
                j.cancelledCheque = { url: undefined };
            }
            return j;
        }
    ));
    customer.bankDetail = bankDetail;
    customer.documents = documents;
    customer.qualification = qualification;
    return customer;
};



exports.approve_comment = async (req, res) => {
    try {
        let date = new Date();
        let day = date.getDate();
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        let fullDate = `${day}-${month}-${year}`;
        const registration = await Registeration.findById(req.params.id);
        registration.approval_status = req.body.approval_status;
        registration.approvedDate = fullDate;
        registration.approvedBy = req.body.approvedBy;
        const a1 = await registration.save();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};



exports.areaOfExpertise = async (req, res) => {
    const service = Registeration.findByIdAndUpdate(req.params.id, { $set: { areaOfExpertise: req.body.areaOfExpertise } });
    try {
        const a1 = await service.exec();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};

exports.createAuthFront = async (req, res) => {
    try {
        let customer = await Registeration.find({ service_provider_id: req.params.id }).populate("service_provider_id");
        customer = await Promise.all(customer.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.upload_photo);
                } catch {
                    readURL = { url: undefined };
                }
                let imageURL;
                try {
                    imageURL = await generateReadSignedURL(i.upload_biodata);
                } catch {
                    imageURL = { url: undefined };
                }
                let documents = await imageMaping(i);
                return { ...i._doc, upload_photo: readURL, upload_biodata: imageURL, documents: documents.documents, qualification: documents.qualification, bankDetail: documents.bankDetail };
            }));
        res.json(customer);
    } catch (err) {
        res.status(400).send("Error " + err);
    }
};




exports.adminProviderCommentFunc = async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await Registeration.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminProviderComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminProviderComment);
        } else {
            const item = await Registeration.findByIdAndUpdate(req.params.id, {
                $push: {
                    adminProviderComment: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.adminProviderComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const updateadminProviderComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { adminProviderComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { adminProviderComment: arr } }, { new: true });
};



exports.updateAdminProviderCommentFunc = async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await Registeration.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminProviderComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.apId) {
                    if (oneItem.providerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            providerComment: oneItem.providerComment,
                            providerDateTime: oneItem.providerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateadminProviderComment(Registeration, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);

        } else {
            const item = await Registeration.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.adminProviderComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.apId) {
                    let changeData = {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateadminProviderComment(Registeration, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



exports.providerAdminCommentFunc = async (req, res) => {
    try {
        if (req.body.providerComment === undefined) {
            const item = await Registeration.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerAdminComment: {
                        adminComment: req.body.adminComment,
                        adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerAdminComment);
        } else {
            const item = await Registeration.findByIdAndUpdate(req.params.id, {
                $push: {
                    providerAdminComment: {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                    }
                }
            }, { new: true });
            return res.status(200).send(item.providerAdminComment);
        }

    } catch (err) {
        return res.status(400).send(err.message);
    }
};




const updateProviderAdminComment = async (model, id, arr) => {
    await model.findByIdAndUpdate(id, { providerAdminComment: [] }, { new: true });
    await model.findByIdAndUpdate(id, { $push: { providerAdminComment: arr } }, { new: true });
};



exports.updateProviderAdminCommentFunc = async (req, res) => {
    try {
        if (req.body.adminComment === undefined) {
            const item = await Registeration.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerAdminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.paId) {
                    let changeData = {
                        providerComment: req.body.providerComment,
                        providerDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                        adminComment: oneItem.adminComment,
                        adminDateTime: oneItem.adminDateTime,
                        _id: oneItem._id
                    };
                    data.push(changeData);
                    myChangeDataShow.push(changeData);
                } else {
                    data.push(oneItem);
                }
            });
            updateProviderAdminComment(Registeration, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        } else {
            const item = await Registeration.findById(req.params.stId).lean().exec();
            let data = [];
            let myChangeDataShow = [];
            item.providerAdminComment.map((oneItem) => {
                if ((oneItem._id).toString() === req.params.paId) {
                    if (oneItem.providerComment === undefined) {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    } else {
                        let changeData = {
                            adminComment: req.body.adminComment,
                            adminDateTime: moment().tz("Asia/Kolkata").format("DD/MM/YYYY - h:mm:ss A"),
                            providerComment: oneItem.providerComment,
                            providerDateTime: oneItem.providerDateTime,
                            _id: oneItem._id
                        };
                        data.push(changeData);
                        myChangeDataShow.push(changeData);
                    }

                } else {
                    data.push(oneItem);
                }
            });
            updateProviderAdminComment(Registeration, req.params.stId, data);
            return res.status(200).send(myChangeDataShow[0]);
        }
    } catch (err) {
        return res.status(400).send(err.message);
    }
};
