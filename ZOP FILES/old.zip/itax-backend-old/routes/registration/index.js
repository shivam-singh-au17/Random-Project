const express = require("express");
const router = express.Router();
const registrationValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const registrationService = require("./service");

router.post(
    "/registration",
    validateParams(registrationValidation.create),
    registrationService.create
);


router.get(
    "/registrations",
    registrationService.get
);


router.get(
    "/registration/:id",
    registrationService.getbyId
);


router.delete(
    "/registration/:id",
    registrationService.delete
);


router.patch(
    "/registration/:id",
    validateParams(registrationValidation.update),
    registrationService.update
);


router.post(
    "/registration/:id/qualification",
    validateParams(registrationValidation.createQualification),
    registrationService.createQualification
);


router.post(
    "/registration/:id/bankDetails",
    validateParams(registrationValidation.createbankDetails),
    registrationService.createbankDetails
);


router.post(
    "/registration/:id/documents",
    validateParams(registrationValidation.createDocuments),
    registrationService.createDocuments
);


router.post(
    "/registration/:id/areaOfExpertise",
    validateParams(registrationValidation.createareaOfExpertise),
    registrationService.areaOfExpertise
);


router.patch(
    "/registration/:id/approve_comment",
    validateParams(registrationValidation.createapprove_comment),
    registrationService.approve_comment
);


router.get(
    "/registration/authFront/:id",
    registrationService.createAuthFront
);


router.patch(
    "/registrationAdminProviderCommentFunc/:id", validateParams(registrationValidation.registrationAdminProviderCommentFunc), registrationService.adminProviderCommentFunc
);


router.patch(
    "/registrationUpdateAdminProviderCommentFunc/:stId/:apId", validateParams(registrationValidation.registrationUpdateAdminProviderCommentFunc), registrationService.updateAdminProviderCommentFunc
);


router.patch(
    "/registrationProviderAdminCommentFunc/:id", validateParams(registrationValidation.registrationProviderAdminCommentFunc), registrationService.providerAdminCommentFunc
);


router.patch(
    "/registrationUpdateProviderAdminCommentFunc/:stId/:paId", validateParams(registrationValidation.registrationUpdateProviderAdminCommentFunc), registrationService.updateProviderAdminCommentFunc
);



module.exports = router;
