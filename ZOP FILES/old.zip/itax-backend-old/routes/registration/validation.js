const Joi = require("joi");

module.exports = {

    create: Joi.object({
        service_provider_id: Joi.string().required(),
        approval_status: Joi.boolean().allow(""),
        email_id: Joi.string().required(),
        dateRegistration: Joi.string().allow(""),
        profile_type: Joi.string().allow(""),
        first_name: Joi.string().required(),
        middle_name: Joi.string().allow(""),
        last_name: Joi.string().required(),
        address_1: Joi.string().required(),
        address_2: Joi.string().allow(""),
        mobile: Joi.number().required(),
        total_year_of_exp: Joi.number().allow(null),
        country: Joi.string().required(),
        overseas: Joi.string().allow(""),
        locality: Joi.string().required(),
        state: Joi.string().required(),
        city: Joi.string().required(),
        working_since: Joi.string().allow(""),
        pin_code: Joi.number().required(),
        facebook_link: Joi.string().allow(""),
        twitter_link: Joi.string().allow(""),
        linkedin_link: Joi.string().allow(""),
        instagram_link: Joi.string().allow(""),
        upload_photo: Joi.string().allow(""),
        upload_biodata: Joi.string().allow(""),
    }),


    update: Joi.object({
        service_provider_id: Joi.string().required(),
        approval_status: Joi.boolean().allow(""),
        email_id: Joi.string().required(),
        profile_type: Joi.string().allow(""),
        first_name: Joi.string().required(),
        middle_name: Joi.string().allow(""),
        last_name: Joi.string().required(),
        address_1: Joi.string().required(),
        address_2: Joi.string().allow(""),
        mobile: Joi.number().required(),
        total_year_of_exp: Joi.number().allow(null),
        country: Joi.string().required(),
        overseas: Joi.string().allow(""),
        locality: Joi.string().required(),
        state: Joi.string().required(),
        city: Joi.string().required(),
        working_since: Joi.string().allow(""),
        pin_code: Joi.number().required(),
        facebook_link: Joi.string().allow(""),
        twitter_link: Joi.string().allow(""),
        linkedin_link: Joi.string().allow(""),
        instagram_link: Joi.string().allow(""),
        upload_photo: Joi.string().allow(""),
        upload_biodata: Joi.string().allow(""),
    }),


    createQualification: Joi.object({
        qualification: Joi.array().items({
            selectQualification: Joi.string().allow(""),
            instituteName: Joi.string().allow(""),
            chooseFile: Joi.string().allow(""),
            otherCertificateName: Joi.string().allow(""),
        }),
    }),


    createbankDetails: Joi.object({
        bankDetail: Joi.array().items({
            accountHolderName: Joi.string().allow(""),
            bankName: Joi.string().allow(""),
            branch: Joi.string().allow(""),
            accountNumber: Joi.string().allow(""),
            ifscCode: Joi.string().allow(""),
            upiNumber: Joi.string().allow(""),
            cancelledCheque: Joi.string().allow(""),
        }),
    }),


    createDocuments: Joi.object({
        documents: Joi.array().items({
            adharCardNo: Joi.string().required(),
            adharCardFileUpload: Joi.string().required(),
            panCardNo: Joi.string().required(),
            panCardFileUpload: Joi.string().required(),
            companyRegistrationNo: Joi.string().allow(""),
            companyRegistrationFileUpload: Joi.string().allow(""),
            gstRegistration: Joi.string().allow(""),
            gstRegistrationFileUpload: Joi.string().allow(""),
            GSTRegistrationtType: Joi.string().allow(""),
        }),
    }),


    createareaOfExpertise: Joi.object({
        areaOfExpertise: Joi.array().items({
            serviceId: Joi.string().required(),
            yearOfExp: Joi.number().allow(null),
        }),
    }),


    createapprove_comment: Joi.object({
        approval_status: Joi.boolean().required(),
        approvedDate: Joi.string().allow(""),
        approvedBy: Joi.string().required(),
    }),


    createservice_provider_id: Joi.object({
        service_provider_id: Joi.string().allow(""),
    }),


    registrationAdminProviderCommentFunc: Joi.object({
        adminComment: Joi.string(),
        providerComment: Joi.string(),
    }),


    registrationUpdateAdminProviderCommentFunc: Joi.object({
        adminComment: Joi.string(),
        providerComment: Joi.string(),
    }),


    registrationProviderAdminCommentFunc: Joi.object({
        providerComment: Joi.string(),
        adminComment: Joi.string(),
    }),


    registrationUpdateProviderAdminCommentFunc: Joi.object({
        providerComment: Joi.string(),
        adminComment: Joi.string(),
    }),

};
