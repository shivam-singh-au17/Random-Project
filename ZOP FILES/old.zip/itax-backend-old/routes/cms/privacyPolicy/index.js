const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationPrivacyPolicy = require("./validation");
const { PrivacyPolicy } = require("../../../models/privacyPolicy");
const privacyPolicyService = require("./service");

router.post("/privacyPolicy/", validateParams(validationPrivacyPolicy.create), privacyPolicyService(PrivacyPolicy).create);
router.get("/privacyPolicys/", privacyPolicyService(PrivacyPolicy).get);
router.get("/privacyPolicy/:id", privacyPolicyService(PrivacyPolicy).getOne);
router.put("/privacyPolicy/:id", validateParams(validationPrivacyPolicy.update), privacyPolicyService(PrivacyPolicy).update);
router.delete("/privacyPolicy/:id", privacyPolicyService(PrivacyPolicy, "about").deleteOne);

module.exports = router;
