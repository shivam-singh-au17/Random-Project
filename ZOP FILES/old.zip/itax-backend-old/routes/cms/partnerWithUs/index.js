const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationPartnerWithUs = require("./validation");
const { PartnerWithUs } = require("../../../models/partnerWithUs");
const partnerWithUsService = require("./service");

router.post("/partnerWithUs/", validateParams(validationPartnerWithUs.create), partnerWithUsService(PartnerWithUs).create);
router.get("/partnerWithUss/", partnerWithUsService(PartnerWithUs).get);
router.get("/partnerWithUs/:id", partnerWithUsService(PartnerWithUs).getOne);
router.put("/partnerWithUs/:id", validateParams(validationPartnerWithUs.update), partnerWithUsService(PartnerWithUs).update);
router.delete("/partnerWithUs/:id", partnerWithUsService(PartnerWithUs, "about").deleteOne);

module.exports = router;
