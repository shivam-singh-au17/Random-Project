const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationOurTeamAndCarrer = require("./validation");
const { OurTeamAndCarrer } = require("../../../models/ourTeamAndCarrer");
const ourTeamAndCarrerService = require("./service");

router.post("/ourTeamAndCarrer/", validateParams(validationOurTeamAndCarrer.create), ourTeamAndCarrerService(OurTeamAndCarrer).create);
router.get("/ourTeamAndCarrers/", ourTeamAndCarrerService(OurTeamAndCarrer).get);
router.get("/ourTeamAndCarrer/:id", ourTeamAndCarrerService(OurTeamAndCarrer).getOne);
router.put("/ourTeamAndCarrer/:id", validateParams(validationOurTeamAndCarrer.update), ourTeamAndCarrerService(OurTeamAndCarrer).update);
router.delete("/ourTeamAndCarrer/:id", ourTeamAndCarrerService(OurTeamAndCarrer, "ourTeamAndCarrer").deleteOne);

module.exports = router;
