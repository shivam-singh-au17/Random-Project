const Joi = require("joi");

module.exports = {
    create: Joi.object({
        teamHeading: Joi.string().required(),
        teamContent: Joi.string().required(),
        careerHeading: Joi.string().required(),
        carrerContent: Joi.string().required(),
        imgFile: Joi.string().required(),
    }),
    update: Joi.object({
        teamHeading: Joi.string().required(),
        teamContent: Joi.string().required(),
        careerHeading: Joi.string().required(),
        carrerContent: Joi.string().required(),
        imgFile: Joi.string().required(),
    }),
};

