const Joi = require("joi");

module.exports = {
    create: Joi.object({
        position: Joi.string().required(),
        location: Joi.string().required(),
        jobDetail: Joi.string().required(),
        status: Joi.boolean().required()
    }),
    update: Joi.object({
        position: Joi.string().required(),
        location: Joi.string().required(),
        jobDetail: Joi.string().required(),
        status: Joi.boolean().required()
    }),
};

