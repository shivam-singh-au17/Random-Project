const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationCareer = require("./validation");
const { Career } = require("../../../models/career");
const careerService = require("./service");

router.post("/cmsCareer/", validateParams(validationCareer.create), careerService(Career).create);
router.get("/cmsCareers/", careerService(Career).get);
router.get("/cmsCareer/:id", careerService(Career).getOne);
router.put("/cmsCareer/:id", validateParams(validationCareer.update), careerService(Career).update);
router.delete("/cmsCareer/:id", careerService(Career, "about").deleteOne);

module.exports = router;
