const Joi = require("joi");

module.exports = {
    create: Joi.object({
        name: Joi.string().required(),
        date: Joi.string().required(),
        status: Joi.boolean().required(),
        shortDescription: Joi.string().required(),
        fullDescription: Joi.string().required(),
        image: Joi.string().required(),
    }),
    update: Joi.object({
        name: Joi.string().required(),
        date: Joi.string().required(),
        status: Joi.boolean().required(),
        shortDescription: Joi.string().required(),
        fullDescription: Joi.string().required(),
        image: Joi.string().required(),
    }),
};
