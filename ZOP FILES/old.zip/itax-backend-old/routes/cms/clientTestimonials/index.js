const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationClientTestimonials = require("./validation");
const { ClientTestimonials } = require("../../../models/clientTestimonials");
const clientTestimonialsService = require("./service");

router.post("/testimonial/", validateParams(validationClientTestimonials.create), clientTestimonialsService(ClientTestimonials).create);
router.get("/testimonials/", clientTestimonialsService(ClientTestimonials).get);
router.get("/testimonial/:id", clientTestimonialsService(ClientTestimonials).getOne);
router.put("/testimonial/:id", validateParams(validationClientTestimonials.update), clientTestimonialsService(ClientTestimonials).update);
router.delete("/testimonial/:id", clientTestimonialsService(ClientTestimonials, "about").deleteOne);

module.exports = router;
