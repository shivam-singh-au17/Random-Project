const Joi = require("joi");

module.exports = {

    create: Joi.object({
        heading: Joi.string().required(),
        image: Joi.string().required(),
        number: Joi.number().required(),
        color: Joi.string().required(),
    }),

    update: Joi.object({
        heading: Joi.string().required(),
        image: Joi.string().required(),
        number: Joi.number().required(),
        color: Joi.string().required(),
    }),

};

