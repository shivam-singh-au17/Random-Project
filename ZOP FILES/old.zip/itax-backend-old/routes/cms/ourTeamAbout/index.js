const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationOurTeamAbout = require("./validation");
const { OurTeamAbout } = require("../../../models/ourTeamAbout");
const ourTeamAboutService = require("./service");

router.post("/ourTeamAbout/", validateParams(validationOurTeamAbout.create), ourTeamAboutService(OurTeamAbout).create);
router.get("/ourTeamAbouts/", ourTeamAboutService(OurTeamAbout).get);
router.get("/ourTeamAbout/:id", ourTeamAboutService(OurTeamAbout).getOne);
router.put("/ourTeamAbout/:id", validateParams(validationOurTeamAbout.update), ourTeamAboutService(OurTeamAbout).update);
router.delete("/ourTeamAbout/:id", ourTeamAboutService(OurTeamAbout, "ourTeamAbout").deleteOne);

module.exports = router;
