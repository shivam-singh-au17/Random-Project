const Joi = require("joi");

module.exports = {
    create: Joi.object({
        Header: Joi.string().required(),
        Descrption: Joi.string().required(),
        File_Input: Joi.string().required(),
        Status: Joi.boolean().required(),
        Sequence_No: Joi.number().required()
    }),
    update: Joi.object({
        Header: Joi.string().required(),
        Descrption: Joi.string().required(),
        File_Input: Joi.string().required(),
        Status: Joi.boolean().required(),
        Sequence_No: Joi.number().required()
    }),
};


