const Joi = require("joi");

module.exports = {
    create: Joi.object({
        Banner: Joi.string().required(),
        Content: Joi.string().required(),
        longContent: Joi.string().required(),
    }),
    update: Joi.object({
        Banner: Joi.string().required(),
        Content: Joi.string().required(),
        longContent: Joi.string().required(),
    }),
};

