const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationAboutUs = require("./validationAboutUs");
const validationAboutSixTab = require("./validationAboutSixTab");
const validationAboutUsTeamTab = require("./validationAboutUsTeamTab");
const { AboutUs, AboutUsSixItemTab, AboutUsTeamTab } = require("../../../models/aboutUs");
const cmsService = require("./service");
const cmsServiceTeam = require("./serviceTeam");


router.post("/aboutus/", validateParams(validationAboutUs.create), cmsService(AboutUs).create);
router.get("/aboutuss/", cmsService(AboutUs).get);
router.get("/aboutus/:id", cmsService(AboutUs).getOne);
router.put("/aboutus/:id", validateParams(validationAboutUs.update), cmsService(AboutUs).update);
router.delete("/aboutus/:id", cmsService(AboutUs, "about").deleteOne);


router.post("/aboutsixtab/", validateParams(validationAboutSixTab.create), cmsService(AboutUsSixItemTab).create);
router.get("/aboutsixtabs/", cmsService(AboutUsSixItemTab).get);
router.get("/aboutsixtab/:id", cmsService(AboutUsSixItemTab).getOne);
router.put("/aboutsixtab/:id", validateParams(validationAboutSixTab.update), cmsService(AboutUsSixItemTab).update);
router.delete("/aboutsixtab/:id", cmsService(AboutUsSixItemTab, "6T").deleteOne);


router.post("/aboutusteamtab/", validateParams(validationAboutUsTeamTab.create), cmsServiceTeam(AboutUsTeamTab).create);
router.get("/aboutusteamtabs/", cmsServiceTeam(AboutUsTeamTab).get);
router.get("/teamTabSearchItem/:id", cmsServiceTeam(AboutUsTeamTab).getSearchItem);
router.get("/aboutusteamtab/:id", cmsServiceTeam(AboutUsTeamTab).getOne);
router.put("/aboutusteamtab/:id", validateParams(validationAboutUsTeamTab.update), cmsServiceTeam(AboutUsTeamTab).update);
router.delete("/aboutusteamtab/:id", cmsServiceTeam(AboutUsTeamTab, "team").deleteOne);

module.exports = router;

