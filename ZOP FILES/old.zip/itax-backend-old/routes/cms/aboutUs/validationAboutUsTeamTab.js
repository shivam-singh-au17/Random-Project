const Joi = require("joi");

module.exports = {
    create: Joi.object({
        categoryId: Joi.string().required(),
        First_Name: Joi.string().required(),
        Last_Name: Joi.string().required(),
        Qualification: Joi.string().required(),
        Banner: Joi.string().required(),
        Status: Joi.boolean().required(),
        Facebook: Joi.string().required(),
        Twitter: Joi.string().required(),
        Instagram: Joi.string().required(),
        Linkedin: Joi.string().required(),
        Decription: Joi.string().required(),
        Photo: Joi.string().required(),
        Sequence_No: Joi.number().required()
    }),
    update: Joi.object({
        categoryId: Joi.string().required(),
        First_Name: Joi.string().required(),
        Last_Name: Joi.string().required(),
        Qualification: Joi.string().required(),
        Banner: Joi.string().required(),
        Status: Joi.boolean().required(),
        Facebook: Joi.string().required(),
        Twitter: Joi.string().required(),
        Instagram: Joi.string().required(),
        Linkedin: Joi.string().required(),
        Decription: Joi.string().required(),
        Photo: Joi.string().required(),
        Sequence_No: Joi.number().required()
    }),
};

