const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationTeamCategory = require("./validation");
const { TeamCategory } = require("../../../models/teamCategory");
const teamCategoryService = require("./service");

router.post("/teamCategory/", validateParams(validationTeamCategory.create), teamCategoryService(TeamCategory).create);
router.get("/teamCategorys/", teamCategoryService(TeamCategory).get);
router.get("/teamCategory/:id", teamCategoryService(TeamCategory).getOne);
router.put("/teamCategory/:id", validateParams(validationTeamCategory.update), teamCategoryService(TeamCategory).update);
router.delete("/teamCategory/:id", teamCategoryService(TeamCategory, "teamCategory").deleteOne);

module.exports = router;
