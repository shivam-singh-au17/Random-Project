const Joi = require("joi");

module.exports = {
    create: Joi.object({
        heading: Joi.string().required(),
        fileInput: Joi.string().required(),
        decription: Joi.string().required(),
        startDate: Joi.string().required(),
        endDate: Joi.string().required(),
        status: Joi.boolean().required(),
        sequenceNo: Joi.number().required(),
    }),
    update: Joi.object({
        heading: Joi.string().required(),
        fileInput: Joi.string().required(),
        decription: Joi.string().required(),
        startDate: Joi.string().required(),
        endDate: Joi.string().required(),
        status: Joi.boolean().required(),
        sequenceNo: Joi.number().required(),
    }),
};

