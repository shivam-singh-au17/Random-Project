const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationBanner = require("./validation");
const { Banner } = require("../../../models/banners");
const bannerService = require("./service");

router.post("/banner/", validateParams(validationBanner.create), bannerService(Banner).create);
router.get("/banners/", bannerService(Banner).get);
router.get("/banner/:id", bannerService(Banner).getOne);
router.put("/banner/:id", validateParams(validationBanner.update), bannerService(Banner).update);
router.delete("/banner/:id", bannerService(Banner, "about").deleteOne);

module.exports = router;
