const Joi = require("joi");

module.exports = {
    create: Joi.object({
        screenName: Joi.string().required(),
        header: Joi.string().required(),
        description: Joi.string().required(),
        image: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
    update: Joi.object({
        screenName: Joi.string().required(),
        header: Joi.string().required(),
        description: Joi.string().required(),
        image: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
};

