const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationPlaceholder = require("./validation");
const { Placeholder } = require("../../../models/placeholder");
const placeholderService = require("./service");

router.post("/placeholder/", validateParams(validationPlaceholder.create), placeholderService(Placeholder).create);
router.get("/placeholders/", placeholderService(Placeholder).get);
router.get("/placeholder/:id", placeholderService(Placeholder).getOne);
router.put("/placeholder/:id", validateParams(validationPlaceholder.update), placeholderService(Placeholder).update);
router.delete("/placeholder/:id", placeholderService(Placeholder, "about").deleteOne);

module.exports = router;
