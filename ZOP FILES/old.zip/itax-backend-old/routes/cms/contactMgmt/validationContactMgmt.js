const Joi = require("joi");

module.exports = {
    create: Joi.object({
        companyName: Joi.string().required(),
        headerPhone: Joi.string().required(),
        headerEmail: Joi.string().required(),
        contactPhone: Joi.string().required(),
        contactEmail: Joi.string().required(),
        companyLogo: Joi.string().required(),
        webSiteURL: Joi.string().required(),
        address: Joi.string().required(),
    }),
    update: Joi.object({
        companyName: Joi.string().required(),
        headerPhone: Joi.string().required(),
        headerEmail: Joi.string().required(),
        contactPhone: Joi.string().required(),
        contactEmail: Joi.string().required(),
        companyLogo: Joi.string().required(),
        webSiteURL: Joi.string().required(),
        address: Joi.string().required(),
    }),
};
