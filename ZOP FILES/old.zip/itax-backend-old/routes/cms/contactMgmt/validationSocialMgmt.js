const Joi = require("joi");

module.exports = {
    create: Joi.object({
        facebook: Joi.string().required(),
        twitter: Joi.string().required(),
        youTube: Joi.string().required(),
        googlePlus: Joi.string().required(),
        linkedin: Joi.string().required(),
        RSS: Joi.string().required(),
    }),
    update: Joi.object({
        facebook: Joi.string().required(),
        twitter: Joi.string().required(),
        youTube: Joi.string().required(),
        googlePlus: Joi.string().required(),
        linkedin: Joi.string().required(),
        RSS: Joi.string().required(),
    }),
};
