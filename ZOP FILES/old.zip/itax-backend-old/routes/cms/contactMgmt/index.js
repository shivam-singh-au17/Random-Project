const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationContactMgmt = require("./validationContactMgmt");
const validationSocialMgmt = require("./validationSocialMgmt");
const { ContactMgmtContact, ContactMgmtSocial } = require("../../../models/contactMgmt");
const contactMgmtService = require("./service");


router.post("/contactMgmt/", validateParams(validationContactMgmt.create), contactMgmtService(ContactMgmtContact).create);
router.get("/contactMgmts/", contactMgmtService(ContactMgmtContact).get);
router.get("/contactMgmt/:id", contactMgmtService(ContactMgmtContact).getOne);
router.put("/contactMgmt/:id", validateParams(validationContactMgmt.update), contactMgmtService(ContactMgmtContact).update);
router.delete("/contactMgmt/:id", contactMgmtService(ContactMgmtContact, "about").deleteOne);


router.post("/socialMgmt/", validateParams(validationSocialMgmt.create), contactMgmtService(ContactMgmtSocial).create);
router.get("/socialMgmts/", contactMgmtService(ContactMgmtSocial).get);
router.get("/socialMgmt/:id", contactMgmtService(ContactMgmtSocial).getOne);
router.put("/socialMgmt/:id", validateParams(validationSocialMgmt.update), contactMgmtService(ContactMgmtSocial).update);
router.delete("/socialMgmt/:id", contactMgmtService(ContactMgmtSocial, "about").deleteOne);

module.exports = router;
