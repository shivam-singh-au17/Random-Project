const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationTermsAndConditions = require("./validation");
const { TermsAndConditions } = require("../../../models/termsAndConditions");
const termsAndConditionsService = require("./service");

router.post("/termsAndCondition/", validateParams(validationTermsAndConditions.create), termsAndConditionsService(TermsAndConditions).create);
router.get("/termsAndConditions/", termsAndConditionsService(TermsAndConditions).get);
router.get("/termsAndCondition/:id", termsAndConditionsService(TermsAndConditions).getOne);
router.put("/termsAndCondition/:id", validateParams(validationTermsAndConditions.update), termsAndConditionsService(TermsAndConditions).update);
router.delete("/termsAndCondition/:id", termsAndConditionsService(TermsAndConditions, "about").deleteOne);

module.exports = router;
