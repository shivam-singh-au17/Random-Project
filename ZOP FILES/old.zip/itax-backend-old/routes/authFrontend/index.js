const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationAuthFrontend = require("./validation");
const authFrontendService = require("./service");
const authenticationFrontend = require("../../middlewares/authenticationFrontend");
const AuthFrontend = require("../../models/authFrontend");


router.post("/registerFrontend/", validateParams(validationAuthFrontend.register), authFrontendService(AuthFrontend).register);
router.post("/loginFrontend/", validateParams(validationAuthFrontend.login), authFrontendService(AuthFrontend).login);

router.get("/frontendAllUsers/", authenticationFrontend, authFrontendService(AuthFrontend).getAllUser);
router.get("/frontendAllUser/:id", authFrontendService(AuthFrontend).getOne);

router.patch("/frontendAllUser/:id", validateParams(validationAuthFrontend.update), authFrontendService(AuthFrontend).update);
router.patch("/updateIsCustomerIsServiceProvider/:id", validateParams(validationAuthFrontend.updateIsCustomerIsServiceProvider), authFrontendService(AuthFrontend).updateIsCustomerIsServiceProvider);

router.delete("/frontendAllUser/:id", authFrontendService(AuthFrontend, "frontendAllUser").deleteOne);

module.exports = router;

