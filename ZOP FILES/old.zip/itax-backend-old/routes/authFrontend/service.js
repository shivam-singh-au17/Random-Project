
const jwt = require("jsonwebtoken");
const config = require("../../config");
const bcrypt = require("bcrypt");


const newToken = (user) => {
    return jwt.sign({ user: user }, config.JWT_SECRET_KEY);
};

const deleteEmpty = (value) => {
    console.log("value:", value);
    if (value == null) {
        return undefined;
    }
    return value;
};


const register = (model) => async (req, res) => {

    try {

        let user = await model.findOne({ email: req.body.email }).lean().exec();

        // if user exists then throw me error
        if (user) {
            return res.status(400).json({ status: "error", message: "User already exists" });
        }

        // otherwise create a user and then hash the password
        req.body.middleName = deleteEmpty(req.body.middleName);
        console.log("req.body.middleName:", req.body.middleName);
        user = await model.create(req.body);

        // create a new token
        let token = newToken(user);

        // return token
        return res.status(200).json({ user, token });

    } catch (err) {
        return res.status(500).json({ status: "failed", message: "Something went wrong" });
    }
};


const login = (model) => async (req, res) => {

    try {

        // check if a user with that email already exists
        let user = await model.findOne({ email: req.body.email }).exec();

        // if not user then throw an error
        if (!user) {

            // check user Account Type
            if (req.body.accountType !== "iTaxDirect Login") {
                user = await model.create({
                    registerAs: " ",
                    firstName: " ",
                    middleName: " ",
                    lastName: " ",
                    email: req.body.email,
                    mobile: " ",
                    password: " ",
                    confirmPassword: " ",
                    accountType: req.body.accountType,
                    secretKey: false,
                });

                // then create the token
                let token = newToken(user);

                // return the token to the frontend
                return res.status(200).json({ user, token });

            }

            return res.status(400).json({ status: "error", message: "You are not registered so register first" });
        }

        // if user then match the password
        const match = await user.checkPassword(req.body.password);

        // if not match then throw an error
        if (!match) {
            return res.status(400).json({
                status: "error", message: "Wrong Password or Email... try again"
            });
        }

        // if match then create the token
        let token = newToken(user);

        // return the token to the frontend
        return res.status(200).json({ user, token });

    } catch (err) {
        return res.status(500).json({ status: "failed", message: "Something went wrong" });
    }

};


const getAllUser = (model) => async (req, res) => {
    try {
        const item = await model.find().lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const update = (model) => async (req, res) => {
    try {
        req.body.password = await bcrypt.hash(req.body.password, 8);
        req.body.confirmPassword = await bcrypt.hash(req.body.confirmPassword, 8);
        const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
        return res.status(200).send(item);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const updateIsCustomerIsServiceProvider = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, {
            isCustomer: req.body.isCustomer,
            isServiceProvider: req.body.isServiceProvider,
        }, { new: true });
        return res.status(200).send(item);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const deleteOne = (model, itemName) => async (req, res) => {
    try {
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).json({ [itemName]: item });

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = (model, itemName) => ({
    register: register(model),
    login: login(model),
    getAllUser: getAllUser(model),
    getOne: getOne(model),
    update: update(model),
    updateIsCustomerIsServiceProvider: updateIsCustomerIsServiceProvider(model),
    deleteOne: deleteOne(model, itemName)
});


