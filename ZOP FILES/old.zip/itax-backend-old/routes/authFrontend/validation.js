const Joi = require("joi");

module.exports = {
    register: Joi.object({
        registerAs: Joi.string().required(),
        firstName: Joi.string().required(),
        middleName: Joi.string().optional().allow(""),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        mobile: Joi.string().required().min(10).max(10),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
    }),

    login: Joi.object({
        email: Joi.string().required(),
        password: Joi.string(),
        accountType: Joi.string().required(),
    }),

    update: Joi.object({
        registerAs: Joi.string().required(),
        firstName: Joi.string().required(),
        middleName: Joi.string().optional().allow(""),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        mobile: Joi.string().required().min(10).max(10),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
    }),

    updateIsCustomerIsServiceProvider: Joi.object({
        isCustomer: Joi.boolean().required(),
        isServiceProvider: Joi.boolean().required(),
    }),

};

