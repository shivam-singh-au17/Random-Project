const express = require("express");
const router = express.Router();
const serviceTransactionValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const serviceTransactionService = require("./service");

router.post(
    "/serviceTransaction",
    validateParams(serviceTransactionValidation.create),
    serviceTransactionService.create
);

router.get(
    "/serviceTransactions",
    serviceTransactionService.get
);

router.get(
    "/serviceTransaction/:id",
    serviceTransactionService.getbyId
);

router.delete(
    "/serviceTransaction/:id",
    serviceTransactionService.delete
);

router.patch(
    "/serviceTransaction/:id",
    validateParams(serviceTransactionValidation.update),
    serviceTransactionService.update
);

// router.post(
//     "/serviceTransaction/:id/documents",
//     validateParams(serviceTransactionValidation.createDocuments),
//     serviceTransactionService.createDocuments
// );

router.post(
    "/serviceTransaction/:id/assignTo",
    validateParams(serviceTransactionValidation.createassignTo),
    serviceTransactionService.createassignTo
);

// router.post(
//     "/serviceTransaction/:id/review",
//     validateParams(serviceTransactionValidation.createreview),
//     serviceTransactionService.createreview
// );

router.get(
    "/serviceTransaction/customerDetails/:id",
    serviceTransactionService.createcustomerDetails
);

module.exports = router;
