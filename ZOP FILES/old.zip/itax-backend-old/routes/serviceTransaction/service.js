const { ServiceTransaction, ServiceMaster, Option, CustomerMgmt, Registeration, MilestoneMaster } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async (req, res) => {
    const b = await ServiceTransaction.find();
    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    let fullDate = `${day}-${month}-${year}`;
    const service = new ServiceTransaction({
        serviceTicketNo: `SO${b.length + 1}`,
        serviceId: req.body.serviceId,
        briedDiscussion: req.body.briedDiscussion,
        financialYearId: req.body.financialYearId,
        customerId: req.body.customerId,
        isApproved: req.body.isApproved,
        serviceAmount: req.body.serviceAmount,
        paymentAmount: req.body.paymentAmount,
        isCustomized: req.body.isCustomized,
        serviceStatus: req.body.serviceStatus,
        ticketDate: fullDate,
        documents: req.body.documents,
    });
    try {
        const a1 = await service.save();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};

exports.get = async (req, res) => {
    try {
        let event = ServiceTransaction.find();
        if (!isNaN(parseInt(req.query.skip)))
            event = event.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            event = event.limit(parseInt(req.query.limit));
        let events = await event;
        events = await Promise.all(events.map(
            async (i) => {
                const serviceCheck = await ServiceMaster.findById(i.serviceId);
                let milestonecheck;
                let templatecheck;
                if (serviceCheck) {
                    milestonecheck = serviceCheck.milestones;
                    templatecheck = serviceCheck.template;
                }
                const optionCheck = await Option.findById(i.financialYearId);
                const customerCheck = await CustomerMgmt.findById(i.customerId);
                const registrationCheck = await Registeration.findById(i.assignedTo);
                let newcheck;
                if (registrationCheck) {
                    newcheck = registrationCheck.areaOfExpertise;
                }
                const k = await Promise.all(i.documents.map(
                    async (j) => {
                        let readURL;
                        try {
                            readURL = await generateReadSignedURL(j.path);
                        } catch {
                            readURL = { url: undefined };
                        }
                        return { ...j._doc, path: readURL };
                    }
                ));
                return { ...i._doc, assignedTo: newcheck, documents: k, milestone: milestonecheck, template: templatecheck, serviceId: serviceCheck, financialYearId: optionCheck, customerId: customerCheck };
            },
        ));
        res.json(events);
    } catch (err) {
        res.send("Error " + err);
    }
};

exports.getbyId = async (req, res) => {
    try {
        // let period;
        let event = await ServiceTransaction.findById(req.params.id);
        const serviceCheck = await ServiceMaster.findById(event.serviceId);
        // const newData = await Promise.all(serviceCheck.milestones.map(
        //     async (i) =>{
        //         period = i.period;
        //         return period;
        //     }));
        const optionCheck = await Option.findById(event.financialYearId);
        const customerCheck = await CustomerMgmt.findById(event.customerId);
        const registrationCheck = await Registeration.findById(event.assignedTo);
        // const customerId = await Registeration.find(event.assignedTo);
        // const customerId = await Registeration.find({assignedTo: req.params.id }).populate("assignedTo");
        let newcheck;
        if (registrationCheck === null) {
            newcheck = [];
        }
        else {
            newcheck = registrationCheck.areaOfExpertise;
        }
        const milestonecheck = serviceCheck.milestones;
        const templatecheck = serviceCheck.template;
        const billableCheck = await MilestoneMaster.find(event.billable);
        const valid = billableCheck.reduce((valid, billable) => {
            if (billable.billable === true) {
                valid.push(billable);
            }
            return valid;
        }, []);

        // let p;
        // if( period === "Yearly"){
        //     p=1;
        // }
        // if( period === "Monthly"){
        //     p=12;
        // }
        // if( period === "Quaterly"){
        //     p=3;
        // }
        // if( period === "Once"){
        //     p=1;
        // }
        // let arr =[];
        // console.log("<<<<", period);
        // console.log("@@@@", p);
        // for(let i = 0 ; i<p; i++)
        // {
        //     console.log("!!!", i);
        //     arr.push(p[i])
        // }
        // console.log("-----", arr);
        // newData.p = arr;
        // console.log("&&",newData.p);

        let template = await Promise.all(event.documents.map(
            async i => {
                let readURL1;
                try {
                    readURL1 = await generateReadSignedURL(i.path);
                } catch {
                    readURL1 = { url: undefined };
                }
                return { ...i._doc, path: readURL1 };
            }));
        res.json({ ...event._doc, registrationCheck, billable: valid, milestone: milestonecheck, template: templatecheck, assignedTo: newcheck, documents: template, serviceId: serviceCheck, financialYearId: optionCheck, customerId: customerCheck });
        // arr,
    } catch (err) {
        res.send("Error " + err);
    }
};

exports.delete = async (req, res) => {
    try {
        const service = await ServiceTransaction.findById(req.params.id);
        const a1 = await service.remove();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }

};

exports.update = async (req, res) => {
    try {
        const service = await ServiceTransaction.findById(req.params.id);
        service.event_date = req.body.event_date,
        service.serviceId = req.body.serviceId,
        service.briedDiscussion = req.body.briedDiscussion,
        service.financialYearId = req.body.financialYearId,
        service.customerId = req.body.customerId,
        service.isApproved = req.body.isApproved,
        service.serviceAmount = req.body.serviceAmount,
        service.paymentAmount = req.body.paymentAmount,
        service.isCustomized = req.body.isCustomized,
        service.serviceStatus = req.body.serviceStatus;
        service.documents = req.body.documents;
        const a1 = await service.save();
        res.json(a1);
    } catch (err) {
        res.send("Error " + err);
    }
};

// exports.createDocuments = async(req,res) => {
//     const service = ServiceTransaction.findByIdAndUpdate(req.params.id, {$set: {documents: req.body.documents}});
//     try{
//         const a1 =  await service.exec();
//         res.json(a1);
//     }catch(err){
//         res.send("Error " + err);
//     }
// };

exports.createassignTo = async (req, res) => {
    try {
        let service = await ServiceTransaction.findByIdAndUpdate(req.params.id, {
            assignedTo: req.body.assignedTo,
            assignedToComments: req.body.assignedToComments,
            typeNew: req.body.typeNew,
            typeApproved: req.body.typeApproved,
            typeReject: req.body.typeReject,
        }, { new: true });
        res.json(service);
    } catch (err) {
        res.send("Error " + err);
    }
};

// exports.createreview = async(req,res) => {
//     try{
//         let service = await ServiceTransaction.findById(req.params.id);
//         // if(service.assignTo === undefined){
//         //     res.send({"Message": "Bad Request/Not assign to anyone"})
//         // }
//         service = {
//             isApproved: req.body.isApproved,
//         };
//         const a1 =  await ServiceTransaction.findOneAndUpdate({_id: req.params.id},service);
//         res.json(a1);
//     }catch(err){
//         res.send("Error " + err);
//     }
// };

exports.createcustomerDetails = async(req,res) => {
    try{
        const customer = await ServiceTransaction.find({customerId: req.params.id })
            .populate("customerId")
            .populate("financialYearId")
            .populate({
                path: "serviceId",
                populate: [
                    {
                        path: "serviceCategory",
                        model: "ServiceCategories "
                    },
                    {
                        path: "relatedServices",
                        model: "ServiceMaster"
                    },
                ]
            });
        res.status(200).json(customer);
    } catch (err) {
        res.status(400).send("Error " + err);
    }
};
