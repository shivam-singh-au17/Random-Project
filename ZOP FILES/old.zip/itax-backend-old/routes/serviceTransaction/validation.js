const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceTicketNo: Joi.string(),
        serviceId: Joi.string().required(),
        briedDiscussion: Joi.string(),
        financialYearId: Joi.string().required(),
        customerId: Joi.string().required(),
        isApproved: Joi.boolean(),
        serviceAmount: Joi.number().required(),
        paymentAmount: Joi.number().required(),
        isCustomized: Joi.boolean().required(),
        serviceStatus: Joi.boolean(),
        ticketDate: Joi.string(),
        documents: Joi.array().items({
            documentName: Joi.string(),
            path: Joi.string(),
        }),
    }),
    update: Joi.object({
        serviceTicketNo: Joi.string(),
        serviceId: Joi.string().required(),
        briedDiscussion: Joi.string(),
        financialYearId: Joi.string().required(),
        customerId: Joi.string().required(),
        isApproved: Joi.boolean(),
        serviceAmount: Joi.number().required(),
        paymentAmount: Joi.number().required(),
        isCustomized: Joi.boolean().required(),
        serviceStatus: Joi.boolean(),
        ticketDate: Joi.string(),
        documents: Joi.array().items({
            documentName: Joi.string(),
            path: Joi.string(),
        }),
    }),
    // createDocuments: Joi.object({
    //     documents: Joi.array().items({
    //         documentName: Joi.string(),
    //         fileUpload: Joi.string(),
    //     }),
    // }),
    createassignTo: Joi.object({
        assignedTo: Joi.string(),
        assignedToComments: Joi.string(),
        typeNew: Joi.boolean(),
        typeApproved: Joi.boolean(),
        typeReject: Joi.boolean(),
    }),
    // createreview: Joi.object({
    //     isApproved: Joi.boolean().required(),
    // }),
};
