const Joi = require("joi");

module.exports = {
    create: Joi.object({
        option: Joi.string().required(),
        label: Joi.string().required(),
        value: Joi.string().required(),
        enabled: Joi.boolean(),
        default: Joi.boolean()
    }),
    update: Joi.object({
        option: Joi.string().required(),
        label: Joi.string().required(),
        value: Joi.string().required(),
        enabled: Joi.boolean(),
        default: Joi.boolean()
    }),
};
