const { Option } = require("../../models");

exports.create = async(req,res) => {
    const options = new Option({
        option: req.body.option,
        label: req.body.label,
        value: req.body.value,
        enabled: req.body.enabled,
        default: req.body.default,
    });

    try{
        const a1 =  await options.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let optionQuery = Option.find();
        if (!isNaN(parseInt(req.query.skip)))
            optionQuery = optionQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            optionQuery = optionQuery.limit(parseInt(req.query.limit));
        let option = await optionQuery;
        res.json(option);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const option = await Option.findById(req.params.id);
        res.json(option);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const option = await Option.findById(req.params.id);
        const a1 = await option.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const options = await Option.findById(req.params.id);
        options.option = req.body.option,
        options.label = req.body.label,
        options.value = req.body.value,
        options.enabled = req.body.enabled,
        options.default = req.body.default;
        const a1 = await options.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
