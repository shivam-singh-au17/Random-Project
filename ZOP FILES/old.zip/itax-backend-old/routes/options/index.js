const express = require("express");
const router = express.Router();
const optionsValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const optionsService = require("./service");

router.post(
    "/option",
    validateParams(optionsValidation.create),
    optionsService.create
);

router.get(
    "/options",
    optionsService.get
);


router.get(
    "/option/:id",
    optionsService.getbyId
);

router.delete(
    "/option/:id",
    optionsService.delete
);

router.patch(
    "/option/:id",
    validateParams(optionsValidation.update),
    optionsService.update
);

module.exports = router;
