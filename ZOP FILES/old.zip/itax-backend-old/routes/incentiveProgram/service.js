let referralCodeGenerator = require("referral-code-generator");

const create = (model) => async (req, res) => {
    try {
        let dataCode = "iTAX-" + referralCodeGenerator.alphaNumeric("uppercase", 2, 3);
        req.body.incentiveCode = dataCode;
        const item = await model.create(req.body);
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const get = (model) => async (req, res) => {
    try {
        const item = await model.find().lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const getOneByServiceProviderId = (model, trxnModel) => async (req, res) => {
    try {
        const myData = await model.findById(req.params.id).lean().exec();
        let providerShereData = myData.providerShere;
        let customerShereData = myData.customerShere;
        let trxnData = await trxnModel.find({ assignedTo: req.params.spId }).lean().exec();
        trxnData.map((oneItem) => {
            oneItem.providerShere = providerShereData;
            oneItem.customerShere = customerShereData;
        });
        await model.findByIdAndUpdate(req.params.id, { providerServices: [] }, { new: true });
        let item = await model.findByIdAndUpdate(req.params.id, { $push: { providerServices: trxnData } }, { new: true });
        res.status(200).send(item);
    } catch (err) {
        return res.status(400).send(err.message);
    }
};



const update = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const deleteOne = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};



module.exports = (model, trxnModel) => ({
    create: create(model),
    get: get(model),
    getOne: getOne(model),
    getOneByServiceProviderId: getOneByServiceProviderId(model, trxnModel),
    update: update(model),
    deleteOne: deleteOne(model)
});


