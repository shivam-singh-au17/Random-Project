const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationIncentiveProgram = require("./validation");
const { IncentiveProgram } = require("../../models/incentiveProgram");
const { ServiceTransactionNew } = require("../../models/serviceTransactionNew");
const incentiveProgramService = require("./service");

router.post("/incentiveProgram/", validateParams(validationIncentiveProgram.create), incentiveProgramService(IncentiveProgram).create);

router.get("/incentivePrograms/", incentiveProgramService(IncentiveProgram).get);
router.get("/incentiveProgram/:id", incentiveProgramService(IncentiveProgram).getOne);
router.get("/incentiveProgramProviderId/:id/:spId", incentiveProgramService(IncentiveProgram, ServiceTransactionNew).getOneByServiceProviderId);

router.patch("/incentiveProgram/:id", validateParams(validationIncentiveProgram.update), incentiveProgramService(IncentiveProgram).update);

router.delete("/incentiveProgram/:id", incentiveProgramService(IncentiveProgram).deleteOne);

module.exports = router;
