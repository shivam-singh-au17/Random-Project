const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceProviderId: Joi.string().required(),
        clientName: Joi.string().required(),
        clientEmail: Joi.string().required(),
        periodFrom: Joi.string().required(),
        periodTo: Joi.string().required(),
        providerShere: Joi.number().required(),
        customerShere: Joi.number().required(),
        incentiveCode: Joi.string().required(),
        providerServices: Joi.array(),
    }),
    update: Joi.object({
        serviceProviderId: Joi.string().required(),
        clientName: Joi.string().required(),
        clientEmail: Joi.string().required(),
        periodFrom: Joi.string().required(),
        periodTo: Joi.string().required(),
        providerShere: Joi.number().required(),
        customerShere: Joi.number().required(),
        incentiveCode: Joi.string().required(),
        providerServices: Joi.array(),
    }),
};

