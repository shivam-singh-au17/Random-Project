const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationModule = require("./validation");
const { Module } = require("../../../models/module");
const moduleService = require("./service");

router.post("/module/", validateParams(validationModule.create), moduleService(Module).create);
router.get("/modules/", moduleService(Module).get);
router.get("/module/:id", moduleService(Module).getOne);
router.put("/module/:id", validateParams(validationModule.update), moduleService(Module).update);
router.delete("/module/:id", moduleService(Module, "module").deleteOne);

module.exports = router;

