const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationCategory = require("./validation");
const { Category } = require("../../../models/category");
const categoryService = require("./service");

router.post("/category/", validateParams(validationCategory.create), categoryService(Category).create);
router.get("/categorys/", categoryService(Category).get);
router.get("/category/:id", categoryService(Category).getOne);
router.put("/category/:id", validateParams(validationCategory.update), categoryService(Category).update);
router.delete("/category/:id", categoryService(Category, "category").deleteOne);

module.exports = router;
