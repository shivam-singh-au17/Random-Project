const Joi = require("joi");

module.exports = {
    create: Joi.object({
        firstName: Joi.string().required(),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        phone: Joi.string().required(),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
        roleId: Joi.string().required(),
        status: Joi.boolean().required(),
        photo: Joi.string().required(),
    }),
    update: Joi.object({
        firstName: Joi.string().required(),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        phone: Joi.string().required(),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
        roleId: Joi.string().required(),
        status: Joi.boolean().required(),
        photo: Joi.string().required(),
    }),
};

