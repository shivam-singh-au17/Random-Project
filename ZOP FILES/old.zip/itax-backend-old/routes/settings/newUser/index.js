const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationNewUser = require("./validation");
const { NewUser } = require("../../../models/newUser");
const newUserService = require("./service");

router.post("/newUser/", validateParams(validationNewUser.create), newUserService(NewUser).create);
router.get("/newUsers/", newUserService(NewUser).get);
router.get("/newUser/:id", newUserService(NewUser).getOne);
router.put("/newUser/:id", validateParams(validationNewUser.update), newUserService(NewUser).update);
router.delete("/newUser/:id", newUserService(NewUser, "newUser").deleteOne);

module.exports = router;
