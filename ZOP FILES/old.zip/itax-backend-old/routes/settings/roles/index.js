const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationRoles = require("./validation");
const { Roles } = require("../../../models/roles");
const roleService = require("./service");

router.post("/role/", validateParams(validationRoles.create), roleService(Roles).create);
router.get("/roles/", roleService(Roles).get);
router.get("/role/:id", roleService(Roles).getOne);
router.put("/role/:id", validateParams(validationRoles.update), roleService(Roles).update);
router.delete("/role/:id", roleService(Roles, "role").deleteOne);

module.exports = router;

