const Joi = require("joi");

module.exports = {
    create: Joi.object({
        roleName: Joi.string().required(),
        permissions: Joi.array().required(),
    }),
    update: Joi.object({
        roleName: Joi.string().required(),
        permissions: Joi.array().required(),
    }),
};
