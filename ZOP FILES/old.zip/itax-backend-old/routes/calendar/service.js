const { Calendar,MilestoneMaster } = require("../../models");

exports.create = async(req,res) => {
    const calendar = new Calendar({
        calender_heading: req.body.calender_heading,
        under_which_law: req.body.under_which_law,
        form_name_no: req.body.form_name_no,
        description: req.body.description,
        schedule_date: req.body.schedule_date,
        milestone: req.body.milestone,
        milestone_filing: req.body.milestone_filing,
        store_year: req.body.store_year,
        status: req.body.status,
    });

    try{
        const a1 =  await calendar.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let calendar = Calendar.find();
        if (!isNaN(parseInt(req.query.skip)))
            calendar = calendar.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            calendar = calendar.limit(parseInt(req.query.limit));
        let calendars = await calendar;
        let d = await Promise.all(calendars.map(
            async (i) => {
                i.milestone = await MilestoneMaster.findById(i.milestone);
                return i;
            }
        ));
        res.json({...calendars._doc,milestone: d});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const calendar = await Calendar.findById(req.params.id);
        const milestoneCheck = await MilestoneMaster.findById(calendar.milestone);
        res.json({...calendar._doc, milestone:milestoneCheck});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const calendar = await Calendar.findById(req.params.id);
        const a1 = await calendar.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const calendar = await Calendar.findById(req.params.id);
        calendar.calender_heading = req.body.calender_heading,
        calendar.under_which_law = req.body.under_which_law,
        calendar.form_name_no = req.body.form_name_no,
        calendar.description = req.body.description,
        calendar.schedule_date = req.body.schedule_date;
        calendar.milestone = req.body.milestone;
        calendar.milestone_filing = req.body.milestone_filing;
        calendar.store_year = req.body.store_year;
        calendar.status = req.body.status;
        const a1 = await calendar.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
