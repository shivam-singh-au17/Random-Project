const express = require("express");
const router = express.Router();
const calendarValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const calendarService = require("./service");

router.post(
    "/calendar",
    validateParams(calendarValidation.create),
    calendarService.create
);

router.get(
    "/calendars",
    calendarService.get
);


router.get(
    "/calendar/:id",
    calendarService.getbyId
);

router.delete(
    "/calendar/:id",
    calendarService.delete
);

router.patch(
    "/calendar/:id",
    validateParams(calendarValidation.update),
    calendarService.update
);

module.exports = router;
