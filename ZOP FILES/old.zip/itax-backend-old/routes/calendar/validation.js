const Joi = require("joi");

module.exports = {
    create: Joi.object({
        calender_heading: Joi.string().required(),
        under_which_law: Joi.string().required(),
        form_name_no: Joi.string().required(),
        description: Joi.string().required(),
        schedule_date: Joi.string().required(),
        milestone: Joi.string(),
        milestone_filing: Joi.string().required(),
        store_year: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
    update: Joi.object({
        calender_heading: Joi.string().required(),
        under_which_law: Joi.string().required(),
        form_name_no: Joi.string().required(),
        description: Joi.string().required(),
        schedule_date: Joi.string().required(),
        milestone: Joi.string(),
        milestone_filing: Joi.string().required(),
        store_year: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
};
