const Joi = require("joi");

module.exports = {
    create: Joi.object({
        registerAs: Joi.string().required(),
        firstName: Joi.string().required(),
        middleName: Joi.string(),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        mobile: Joi.string().required(),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
    }),
    update: Joi.object({
        registerAs: Joi.string().required(),
        firstName: Joi.string().required(),
        middleName: Joi.string(),
        lastName: Joi.string().required(),
        email: Joi.string().required(),
        mobile: Joi.string().required(),
        password: Joi.string().required(),
        confirmPassword: Joi.string().required(),
    }),
};

