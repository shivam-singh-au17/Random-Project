const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationServiceProvider = require("./validation");
const serviceProviderService = require("./service");
const ServiceProvider = require("../../models/serviceProvider");

router.post("/serviceProvider/", validateParams(validationServiceProvider.create), serviceProviderService(ServiceProvider).create);
router.get("/serviceProviders/", serviceProviderService(ServiceProvider).get);
router.get("/serviceProvider/:id", serviceProviderService(ServiceProvider).getOne);
router.put("/serviceProvider/:id", validateParams(validationServiceProvider.update), serviceProviderService(ServiceProvider).update);
router.delete("/serviceProvider/:id", serviceProviderService(ServiceProvider, "serviceProvider").deleteOne);

module.exports = router;

