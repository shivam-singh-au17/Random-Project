const express = require("express");
const router = express.Router();
const BusinessPartnerFeeValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const BusinessPartnerFeeService = require("./service");

router.post(
    "/businessPartnerFee",
    validateParams(BusinessPartnerFeeValidation.create),
    BusinessPartnerFeeService.create
);

router.get(
    "/businessPartnerFees",
    BusinessPartnerFeeService.get
);


router.get(
    "/businessPartnerFee/:id",
    BusinessPartnerFeeService.getbyId
);

router.delete(
    "/businessPartnerFee/:id",
    BusinessPartnerFeeService.delete
);

router.patch(
    "/businessPartnerFee/:id",
    validateParams(BusinessPartnerFeeValidation.update),
    BusinessPartnerFeeService.update
);

module.exports = router;
