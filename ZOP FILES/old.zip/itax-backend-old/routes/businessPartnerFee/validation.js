const Joi = require("joi");

module.exports = {
    create: Joi.object({
        selectBusinessPartner: Joi.string().required(),
        description: Joi.string().required(),
        details: Joi.array().items({
            serviceCategory: Joi.string().required(),
            serviceName: Joi.string().required(),
            serviceFee: Joi.number().required(),
            partnerFeePercentage: Joi.number().required(),
            partnerFee: Joi.number().required(),
            remarks: Joi.string().required(),
            createdBy: Joi.string(),
        }),
    }),
    update: Joi.object({
        selectBusinessPartner: Joi.string().required(),
        description: Joi.string().required(),
        details: Joi.array().items({
            serviceCategory: Joi.string().required(),
            serviceName: Joi.string().required(),
            serviceFee: Joi.number().required(),
            partnerFeePercentage: Joi.number().required(),
            partnerFee: Joi.number().required(),
            remarks: Joi.string().required(),
            updatedBy: Joi.string(),
        }),
    }),
};
