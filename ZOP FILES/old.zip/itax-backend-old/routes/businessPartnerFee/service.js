const { BusinessPartnerFee,ServiceCategories,ServiceMaster,Registeration } = require("../../models");
// Registeration, ServiceCategories, ServiceMaster
exports.create = async(req,res) => {
    const business = new BusinessPartnerFee({
        selectBusinessPartner: req.body.selectBusinessPartner,
        description: req.body.description,
        details: req.body.details,
        createdBy: "Admin",
        updatedBy: "Admin1",
    });

    try{
        const a1 =  await business.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let business = BusinessPartnerFee.find();
        if (!isNaN(parseInt(req.query.skip)))
            business = business.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            business = business.limit(parseInt(req.query.limit));
        let businesss = await business;
        businesss = await Promise.all(businesss.map(
            async (i) => {
                const m = await Registeration.findById(i.selectBusinessPartner);
                const s = await Promise.all(i.details.map(
                    async (j) => {
                        const n = await ServiceMaster.findById(j.serviceName);
                        const o = await ServiceCategories.findById(j.serviceCategory);
                        return  { ...j._doc,serviceName: n, serviceCategory: o};
                    }
                ));
                return { ...i._doc,selectBusinessPartner:m,details:s};
            },
        ));
        res.json(businesss);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const business = await BusinessPartnerFee.findById(req.params.id);
        const nameCheck = await Registeration.findById(business.selectBusinessPartner);
        const serviceNameCheck = await Promise.all(business.details.map(
            async (i) => {
                let serviceName = await ServiceMaster.findById(i.serviceName);
                let m  = await ServiceCategories.findById(i.serviceCategory);
                return { ...i._doc, serviceCategory: m, serviceName };
            }
        ));
        res.json({...business._doc, details: serviceNameCheck, selectBusinessPartner:nameCheck});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const business = await BusinessPartnerFee.findById(req.params.id);
        const a1 = await business.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const business = await BusinessPartnerFee.findById(req.params.id);
        business.selectBusinessPartner = req.body.selectBusinessPartner,
        business.description = req.body.description,
        business.details = req.body.details;
        business.updatedBy = "Admin1";
        const a1 = await business.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
