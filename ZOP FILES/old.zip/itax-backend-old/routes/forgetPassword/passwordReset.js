const AuthFrontend  = require("../../models/authFrontend");
const sendEmail = require("../../utils/sendEmail");
const Joi = require("joi");
const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");

router.post("/", async (req, res) => {
    try {
        const schema = Joi.object({ email: Joi.string().email().required() });
        const { error } = schema.validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        const user = await AuthFrontend.findOne({ email: req.body.email });
        if (!user)
            return res.status(400).send("user with given email doesn't exist");

        let x = Math.floor((Math.random() * 10000000) + 1);
        const otp =  x ;
        let newotp = await AuthFrontend.findOneAndUpdate({email: user.email}, { $set: { otp: otp } });
        if(newotp){
            let pass = await sendEmail(user.email, "Password reset", otp);
            if(pass.accepted.length > 0){
                res.json({ mesage: "password reset link sent to your email account", status: pass });
            }else{
                res.json({ mesage: "Not Delived", status: pass });
            }
        }else{
            res.send("Something Went Wrong");
        }
    } catch (error) {
        res.send("An error occured");
    }
});

router.post("/resetpassword", async (req, res) => {
    try {
        let password;
        let otp;
        const schema = Joi.object({ email: Joi.string().email().required(), otp: Joi.string().required(), password: Joi.string().required()});
        const { error } = schema.validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);
        const data = await AuthFrontend.findOne({ email:req.body.email });
        if(!data){
            res.send("User Does not Exists");
        }
        if(data.otp === req.body.otp){
            password = await bcrypt.hash(req.body.password, 8);
            otp = "";
            let saveData = await AuthFrontend.findOneAndUpdate({email: data.email}, { $set: { otp: otp, password: password } });
            if(saveData){

                res.send("Data Successfully Updated");
            }else{
                res.send("Not Updated");
            }
        }else{
            res.send("Entered Otp does not match");
        }
    } catch (error) {
        res.send("An error occured");
    }
});

module.exports = router;
