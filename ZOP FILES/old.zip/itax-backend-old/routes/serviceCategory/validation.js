const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceCategory: Joi.string().required(),
        description: Joi.string().required(),
        image: Joi.string(),
        showonHomePage: Joi.boolean(),
        status: Joi.boolean()
    }),
    update: Joi.object({
        serviceCategory: Joi.string().required(),
        description: Joi.string().required(),
        image: Joi.string(),
        showonHomePage: Joi.boolean(),
        status: Joi.boolean()
    }),
};
