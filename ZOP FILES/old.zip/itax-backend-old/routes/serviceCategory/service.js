const { ServiceCategories,ServiceMaster } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async(req,res) => {
    const serviceCategories = new ServiceCategories({
        serviceCategory: req.body.serviceCategory,
        description: req.body.description,
        image: req.body.image,
        showonHomePage: req.body.showonHomePage,
        status: req.body.status,
    });

    try{
        const a1 =  await serviceCategories.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async (req,res) => {
    try{
        let serviceCategoryQuery = ServiceCategories.find();
        if (!isNaN(parseInt(req.query.skip)))
            serviceCategoryQuery = serviceCategoryQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            serviceCategoryQuery = serviceCategoryQuery.limit(parseInt(req.query.limit));
        let serviceCategories = await serviceCategoryQuery;
        serviceCategories = await Promise.all(serviceCategories.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.image);
                } catch {
                    readURL = { url: undefined };
                }
                let imageURL;
                try {
                    imageURL = await generateReadSignedURL(i.generatedimage);
                } catch {
                    imageURL = { url: undefined };
                }
                return { ...i._doc, image: readURL, generatedimage: imageURL };
            }));
        res.json(serviceCategories);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const serviceCategories = await ServiceCategories.findById(req.params.id);
        let readURL;
        try {
            readURL = await generateReadSignedURL(serviceCategories.image);
        } catch {
            readURL = { url: undefined };
        }
        let imageURL;
        try {
            imageURL = await generateReadSignedURL(serviceCategories.generatedimage);
        } catch {
            imageURL = { url: undefined };
        }
        let mapped = await ServiceMaster.find({ serviceCategory: req.params.id }).populate({
            path: "serviceCategory",
            select: "serviceCategory description status",
        });
        // .populate({
        //     path: "relatedServices",
        //     select: "serviceCategory serviceModel serviceName description customerServiceFee fullPaymentDiscount businessPartnerFee status tdsApplicable GSTapplicableInter GSTapplicableIntra GSTapplicableInterut milestones documents template relatedServices",
        // });
        let related = mapped.map( i => i.relatedServices).flat();
        let set = [...new Set(related)];
        // set = await ServiceMaster.find({ serviceCategory: req.params.id }).populate({
        //     path: "relatedServices",
        //     select: "serviceCategory serviceModel serviceName description customerServiceFee fullPaymentDiscount businessPartnerFee status tdsApplicable GSTapplicableInter GSTapplicableIntra GSTapplicableInterut milestones documents template relatedServices",
        // });
        res.json({...serviceCategories._doc, image: readURL, generatedimage: imageURL, mappedServices: mapped, relatedServices: set });
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const serviceCategories = await ServiceCategories.findById(req.params.id);
        const a1 = await serviceCategories.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const serviceCategories = await ServiceCategories.findById(req.params.id);
        serviceCategories.serviceCategory = req.body.serviceCategory,
        serviceCategories.description = req.body.description,
        serviceCategories.image = req.body.image,
        serviceCategories.showonHomePage = req.body.showonHomePage,
        serviceCategories.status = req.body.status;
        const a1 = await serviceCategories.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
