const express = require("express");
const router = express.Router();
const serviceCategoriesValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const serviceCategoriesService = require("./service");

router.post(
    "/serviceCategory",
    validateParams(serviceCategoriesValidation.create),
    serviceCategoriesService.create
);

router.get(
    "/serviceCategories",
    serviceCategoriesService.get
);


router.get(
    "/serviceCategory/:id",
    serviceCategoriesService.getbyId
);

router.delete(
    "/serviceCategory/:id",
    serviceCategoriesService.delete
);

router.patch(
    "/serviceCategory/:id",
    validateParams(serviceCategoriesValidation.update),
    serviceCategoriesService.update
);

module.exports = router;
