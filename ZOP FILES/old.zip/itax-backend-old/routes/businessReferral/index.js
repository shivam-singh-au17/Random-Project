const express = require("express");
const router = express.Router();
const businessReferralValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const businessReferralService = require("./service");

router.post(
    "/businessReferral",
    validateParams(businessReferralValidation.create),
    businessReferralService.create
);

router.get(
    "/businessReferrals",
    businessReferralService.get
);


router.get(
    "/businessReferral/:id",
    businessReferralService.getbyId
);

router.delete(
    "/businessReferral/:id",
    businessReferralService.delete
);

router.patch(
    "/businessReferral/:id",
    validateParams(businessReferralValidation.update),
    businessReferralService.update
);

module.exports = router;
