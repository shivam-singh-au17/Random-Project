const { BusinessReferral } = require("../../models");

exports.create = async(req,res) => {
    const business = new BusinessReferral({
        referralHeading: req.body.referralHeading,
        selectBusinessPartner: req.body.selectBusinessPartner,
        validFrom: req.body.validFrom,
        validTo: req.body.validTo,
        status: req.body.status,
        referralIncentive: req.body.referralIncentive,
        referralAmount: req.body.referralAmount,
        customerDiscount: req.body.customerDiscount,
        customerAmount: req.body.customerAmount,
        remarks: req.body.remarks,
    });

    try{
        const a1 =  await business.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let business = BusinessReferral.find();
        if (!isNaN(parseInt(req.query.skip)))
            business = business.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            business = business.limit(parseInt(req.query.limit));
        let businesses = await business;
        res.json(businesses);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const business = await BusinessReferral.findById(req.params.id);
        res.json(business);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const business = await BusinessReferral.findById(req.params.id);
        const a1 = await business.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const business = await BusinessReferral.findById(req.params.id);
        business.referralHeading = req.body.referralHeading,
        business.selectBusinessPartner = req.body.selectBusinessPartner,
        business.validFrom = req.body.validFrom,
        business.validTo = req.body.validTo,
        business.status = req.body.status,
        business.referralIncentive = req.body.referralIncentive,
        business.referralAmount = req.body.referralAmount,
        business.customerDiscount = req.body.customerDiscount,
        business.customerAmount = req.body.customerAmount,
        business.remarks = req.body.remarks;
        const a1 = await business.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
