const Joi = require("joi");

module.exports = {
    create: Joi.object({
        referralHeading: Joi.string().required(),
        selectBusinessPartner: Joi.string().required(),
        validFrom: Joi.string().required(),
        validTo: Joi.string().required(),
        status: Joi.boolean(),
        referralIncentive: Joi.string().required(),
        referralAmount: Joi.string().required(),
        customerDiscount: Joi.string().required(),
        customerAmount: Joi.string().required(),
        remarks: Joi.string().required(),
    }),
    update: Joi.object({
        referralHeading: Joi.string().required(),
        selectBusinessPartner: Joi.string().required(),
        validFrom: Joi.string().required(),
        validTo: Joi.string().required(),
        status: Joi.boolean(),
        referralIncentive: Joi.string().required(),
        referralAmount: Joi.string().required(),
        customerDiscount: Joi.string().required(),
        customerAmount: Joi.string().required(),
        remarks: Joi.string().required(),
    }),
};
