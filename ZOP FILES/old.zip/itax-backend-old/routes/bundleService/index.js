const express = require("express");
const router = express.Router();
const bundleServiceValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const bundleService = require("./service");

router.post(
    "/bundleService",
    validateParams(bundleServiceValidation.create),
    bundleService.create
);

router.get(
    "/bundleServices",
    bundleService.get
);

router.get(
    "/bundleService/:id",
    bundleService.getbyId
);

router.delete(
    "/bundleService/:id",
    bundleService.delete
);

router.patch(
    "/bundleService/:id",
    validateParams(bundleServiceValidation.update),
    bundleService.update
);

module.exports = router;
