const Joi = require("joi");

module.exports = {
    create: Joi.object({
        bundleName: Joi.string().required(),
        serviceGroup: Joi.array().required(),
        createdBy: Joi.array(),
        totalPrice: Joi.number().required(),
        discount_Perce_flat: Joi.string().required(),
        discountValue: Joi.number().required(),
        discountAmount: Joi.number().required(),
    }),
    update: Joi.object({
        bundleName: Joi.string().required(),
        totalPrice: Joi.number().required(),
        serviceGroup: Joi.array().required(),
        createdBy: Joi.array(),
        discount_Perce_flat: Joi.string().required(),
        discountValue: Joi.number().required(),
        discountAmount: Joi.number().required(),
    }),
};
