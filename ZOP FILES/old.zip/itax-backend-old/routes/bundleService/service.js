const { BundleService, ServiceMaster } = require("../../models");

exports.create = async(req,res) => {
    const bundle = new BundleService({
        bundleName: req.body.bundleName,
        totalPrice: req.body.totalPrice,
        discount_Perce_flat: req.body.discount_Perce_flat,
        discountValue: req.body.discountValue,
        discountAmount: req.body.discountAmount,
        serviceGroup: req.body.serviceGroup,
    });

    try{
        const a1 =  await bundle.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let bundle = BundleService.find();
        if (!isNaN(parseInt(req.query.skip)))
            bundle = bundle.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            bundle = bundle.limit(parseInt(req.query.limit));
        let bundles = await bundle;
        await Promise.all(bundles.map(
            async (i) => {
                const s = await Promise.all(i.serviceGroup.map(
                    async (bundles) => {
                        const m = await ServiceMaster.findById(bundles);
                        return m;
                    }
                ));
                return i.serviceGroup = s;
            },
        ));
        res.json(bundles);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const bundle = await BundleService.findById(req.params.id);
        const bundleCheck = await Promise.all(bundle.serviceGroup.map(
            async (bundles) => {
                const m = await ServiceMaster.findById(bundles);
                return { ...bundles._doc, bundles: m};
            }
        ));
        res.json({...bundle._doc, serviceGroup:bundleCheck});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const bundle = await BundleService.findById(req.params.id);
        const a1 = await bundle.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const bundle = await BundleService.findById(req.params.id);
        bundle.bundleName = req.body.bundleName,
        bundle.totalPrice = req.body.totalPrice,
        bundle.discount_Perce_flat = req.body.discount_Perce_flat,
        bundle.discountValue = req.body.discountValue,
        bundle.discountAmount = req.body.discountAmount;
        bundle.serviceGroup = req.body.serviceGroup;
        const a1 = await bundle.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.createrserviceGroup = async(req,res) => {
    const bundle = BundleService.findByIdAndUpdate(req.params.id, {$set: {serviceGroup: req.body.serviceGroup}});
    try{
        const a1 =  await bundle.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};
