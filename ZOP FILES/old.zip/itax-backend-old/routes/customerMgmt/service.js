const { CustomerMgmt,authFrontend } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async(req,res) => {
    const customer = new CustomerMgmt({
        customerId: req.body.customerId,
        emailId: req.body.emailId,
        companyName: req.body.companyName,
        address1: req.body.address1,
        address2: req.body.address2,
        country: req.body.country,
        overseas: req.body.overseas,
        locality: req.body.locality,
        state: req.body.state,
        city: req.body.city,
        profileType: req.body.profileType,
        signInAuthority: req.body.signInAuthority,
        mobile: req.body.mobile,
        pinCode: req.body.pinCode,
        uploadPhoto: req.body.uploadPhoto,
        approvalStatus: req.body.approvalStatus,
    });
    try{
        const a1 =  await customer.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};


exports.delete = async(req,res)=> {
    try{
        const customer = await CustomerMgmt.findById(req.params.id);
        const a1 = await customer.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const customer = await CustomerMgmt.findById(req.params.id);
        customer.customerId = req.body.customerId,
        customer.emailId = req.body.emailId,
        customer.companyName = req.body.companyName,
        customer.address1 = req.body.address1,
        customer.address2 = req.body.address2,
        customer.country = req.body.country,
        customer.overseas = req.body.overseas,
        customer.locality = req.body.locality,
        customer.state = req.body.state,
        customer.city = req.body.city,
        customer.profileType = req.body.profileType,
        customer.signInAuthority = req.body.signInAuthority,
        customer.mobile = req.body.mobile,
        customer.pinCode = req.body.pinCode,
        customer.uploadPhoto = req.body.uploadPhoto,
        customer.approvalStatus = req.body.approvalStatus;
        const a1 = await customer.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.createDocuments = async(req,res) => {
    const customer = CustomerMgmt.findByIdAndUpdate(req.params.id, {$set: {documents: req.body.documents}});
    try{
        const a1 =  await customer.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};


exports.get = async (req,res) => {
    try{
        let CustomerMgmtQuery = CustomerMgmt.find().populate("customerId");
        if (!isNaN(parseInt(req.query.skip)))
            CustomerMgmtQuery = CustomerMgmtQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            CustomerMgmtQuery = CustomerMgmtQuery.limit(parseInt(req.query.limit));
        let customer = await CustomerMgmtQuery;
        customer = await Promise.all(customer.map(
            async i => {
                let readURL1;
                try {
                    readURL1 = await generateReadSignedURL(i.uploadPhoto);
                    // let x = readURL1.path.split(".");
                    // readURL1.fileName = `UploadPhoto.${x[1]}`;
                } catch {
                    readURL1 = { url: undefined };
                }
                let documents = await imageMaping(i);
                return { ...i._doc, uploadPhoto: readURL1,documents };
            }));
        res.json(customer);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const customer = await CustomerMgmt.findById(req.params.id);
        const nextCheck = await authFrontend.findById(customer.customerId);
        let readURL1;
        try {
            readURL1 = await generateReadSignedURL(customer.uploadPhoto);
        } catch {
            readURL1 = { url: undefined };
        }
        let documents = await imageMaping(customer);
        res.json({...customer._doc,customerId:nextCheck, uploadPhoto: readURL1,documents: documents});
    }catch(err){
        res.send("Error " + err);
    }
};

let imageMaping = async  (customer)=>{
    customer = customer.toObject();
    let documents = await Promise.all(customer.documents.map(
        async j => {
            try {
                let pp = await generateReadSignedURL(j.adharCardFileUpload);
                j.adharCardFileUpload = pp;
            } catch {
                j.adharCardFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.panCardFileUpload);
                j.panCardFileUpload = pp;
            } catch {
                j.panCardFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.companyRegistrationFileUpload);
                j.companyRegistrationFileUpload = pp;
            } catch {
                j.companyRegistrationFileUpload = { url: undefined };
            }

            try {
                let pp = await generateReadSignedURL(j.gstRegistrationFileUpload);
                j.gstRegistrationFileUpload = pp;
            } catch {
                j.gstRegistrationFileUpload = { url: undefined };
            }

            return j;
        }
    ));
    return documents;
};

exports.createAuthFront = async(req,res) => {
    try{
        let customer = await CustomerMgmt.find({customerId: req.params.id }).populate("customerId");
        customer = await Promise.all(customer.map(
            async i => {
                let readURL1;
                try {
                    readURL1 = await generateReadSignedURL(i.uploadPhoto);
                } catch {
                    readURL1 = { url: undefined };
                }
                let documents = await imageMaping(i);
                return { ...i._doc, uploadPhoto: readURL1,documents };
            }));
        res.status(200).json(customer);
    }catch(err){
        res.status(400).send("Error " + err);
    }
};
