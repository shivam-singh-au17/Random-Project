const express = require("express");
const router = express.Router();
const customerMgmtValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const customerMgmtService = require("./service");


router.post(
    "/customer",
    validateParams(customerMgmtValidation.create),
    customerMgmtService.create
);

router.get(
    "/customers",
    customerMgmtService.get
);

router.get(
    "/customer/:id",
    customerMgmtService.getbyId
);

router.delete(
    "/customer/:id",
    customerMgmtService.delete
);


router.patch(
    "/customer/:id",
    validateParams(customerMgmtValidation.update),
    customerMgmtService.update
);

router.post(
    "/customer/:id/documents",
    validateParams(customerMgmtValidation.createDocuments),
    customerMgmtService.createDocuments
);

router.get(
    "/customer/authFront/:id",
    customerMgmtService.createAuthFront
);

module.exports = router;
