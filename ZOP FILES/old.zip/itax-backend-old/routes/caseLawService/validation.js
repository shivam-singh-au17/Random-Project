const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceId: Joi.string().required(),
        providerId: Joi.string().required(),
        customerId: Joi.string().required(),
        remarks: Joi.string(),
    }),
    update: Joi.object({
        serviceId: Joi.string().required(),
        providerId: Joi.string().required(),
        customerId: Joi.string().required(),
        remarks: Joi.string(),
    }),
};
