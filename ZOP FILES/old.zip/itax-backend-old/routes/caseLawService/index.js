const express = require("express");
const router = express.Router();
const caseLawServiceValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const caseLawServiceService = require("./service");

router.post(
    "/caseLawService",
    validateParams(caseLawServiceValidation.create),
    caseLawServiceService.create
);

router.get(
    "/caseLawServices",
    caseLawServiceService.get
);

router.get(
    "/caseLawService/:id",
    caseLawServiceService.getbyId
);

router.delete(
    "/caseLawService/:id",
    caseLawServiceService.delete
);

router.patch(
    "/caseLawService/:id",
    validateParams(caseLawServiceValidation.update),
    caseLawServiceService.update
);

module.exports = router;
