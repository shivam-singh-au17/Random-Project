const { CaseLawService } = require("../../models");

exports.create = async(req,res) => {
    const service = new CaseLawService({
        serviceId: req.body.serviceId,
        providerId: req.body.providerId,
        customerId: req.body.customerId,
        remarks: req.body.remarks,
    });

    try{
        const a1 =  await service.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let service = CaseLawService.find().populate("serviceId").populate("providerId").populate("customerId");
        if (!isNaN(parseInt(req.query.skip)))
            service = service.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            service = service.limit(parseInt(req.query.limit));
        let services = await service;
        res.json(services);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const service = await CaseLawService.findById(req.params.id).populate("serviceId").populate("providerId").populate("customerId");
        res.json(service);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const service = await CaseLawService.findById(req.params.id);
        const a1 = await service.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const service = await CaseLawService.findById(req.params.id);
        service.serviceId = req.body.serviceId;
        service.providerId = req.body.providerId;
        service.customerId = req.body.customerId;
        service.remarks = req.body.remarks;
        const a1 = await service.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
