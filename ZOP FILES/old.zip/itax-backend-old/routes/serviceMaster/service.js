const { MilestoneMaster, ServiceMaster } = require("../../models");
// ,ServiceCategories
const { generateReadSignedURL } = require("../../utils/minio");
exports.create = async(req,res) => {
    const service = new ServiceMaster({
        serviceCategory: req.body.serviceCategory,
        serviceModel: req.body.serviceModel,
        imageUpload: req.body.imageUpload,
        serviceName: req.body.serviceName,
        description: req.body.description,
        customerServiceFee: req.body.customerServiceFee,
        fullPaymentDiscount: req.body.fullPaymentDiscount,
        GSTapplicableInter: req.body.GSTapplicableInter,
        GSTapplicableIntra: req.body.GSTapplicableIntra,
        GSTapplicableInterut: req.body.GSTapplicableInterut,
        businessPartnerFee: req.body.businessPartnerFee,
        tdsApplicable: req.body.tdsApplicable,
        showOnHomePage: req.body.showOnHomePage,
        status: req.body.status,

    });

    try{
        const a1 =  await service.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async (req,res) => {
    try{
        let serviceQuery = ServiceMaster.find();
        if (!isNaN(parseInt(req.query.skip)))
            serviceQuery = serviceQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            serviceQuery = serviceQuery.limit(parseInt(req.query.limit));
        let services = await serviceQuery;
        let a1 = services.map( i => ({
            serviceName: i.serviceName,
            serviceModel: i.serviceModel,
            customerServiceFee: i.customerServiceFee,
            showOnHomePage: i.showOnHomePage,
            status: i.status,
            _id: i._id,
        }));
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        let  service = await ServiceMaster.findById(req.params.id).populate({
            path: "relatedServices",
            select: "serviceCategory serviceModel serviceName description customerServiceFee fullPaymentDiscount businessPartnerFee status tdsApplicable GSTapplicableInter GSTapplicableIntra GSTapplicableInterut milestones documents template relatedServices",
        });
        // service = await ServiceCategories.find({customerId: req.params.id }).populate("customerId");
        // .populate({
        //     path: "serviceCategory",
        //     select: "serviceCategory description status",
        // });
        const milestones = await Promise.all(service.milestones.map(
            async (milestone) => {
                const m = await MilestoneMaster.findById(milestone.milestone);
                return { ...milestone._doc, milestone: m};
            }
        ));
        let template = await Promise.all(service.template.map(
            async i => {
                let readURL1;
                try {
                    readURL1 = await generateReadSignedURL(i.fileUpload);
                } catch {
                    readURL1 = { url: undefined };
                }
                return { ...i._doc, fileUpload: readURL1 };
            }));
        let readURL;
        try {
            readURL = await generateReadSignedURL(service.imageUpload);
        } catch {
            readURL = { url: undefined };
        }
        res.json({...service._doc, milestones, template,imageUpload:readURL});
    }catch(err){
        res.send("Error " + err);
    }
};
exports.delete = async(req,res)=> {
    try{
        const service = await ServiceMaster.findById(req.params.id);
        const a1 = await service.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const service = await ServiceMaster.findById(req.params.id);
        service.serviceCategory = req.body.serviceCategory,
        service.serviceModel = req.body.serviceModel,
        service.imageUpload = req.body.imageUpload,
        service.serviceName = req.body.serviceName,
        service.description = req.body.description,
        service.customerServiceFee = req.body.customerServiceFee;
        service.fullPaymentDiscount = req.body.fullPaymentDiscount;
        service.businessPartnerFee = req.body.businessPartnerFee;
        service.GSTapplicableInter = req.body.GSTapplicableInter,
        service.GSTapplicableIntra = req.body.GSTapplicableIntra,
        service.GSTapplicableInterut = req.body.GSTapplicableInterut,
        service.tdsApplicable = req.body.tdsApplicable;
        service.showOnHomePage = req.body.showOnHomePage;
        service.status = req.body.status;
        const a1 = await service.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.createMilestone = async(req,res) => {
    const service = ServiceMaster.findByIdAndUpdate(req.params.id, {$set: {milestones: req.body.milestones}});
    try{
        const a1 =  await service.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.createDocuments = async(req,res) => {
    const service = ServiceMaster.findByIdAndUpdate(req.params.id, {$set: {documents: req.body.documents}});
    try{
        const a1 =  await service.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.createrelatedServices = async(req,res) => {
    // let set = [...new Set(req.body.relatedServices)];{relatedServices: set }
    const service = ServiceMaster.findByIdAndUpdate(req.params.id, {$set: {relatedServices: req.body.relatedServices}});
    try{
        const a1 =  await service.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

// exports.createserviceCategory = async(req,res) => {
//     let set = [...new Set(req.body.serviceCategory)];
//     const service = ServiceMaster.findByIdAndUpdate(req.params.id, {serviceCategory: set });
//     try{
//         const a1 =  await service.exec();
//         res.json(a1);
//     }catch(err){
//         res.send("Error " + err);
//     }
// };

// exports.creategstApplicable = async(req,res) => {
//     const service = ServiceMaster.findByIdAndUpdate(req.params.id, {$set: {gstApplicable: req.body.gstApplicable}});
//     try{
//         const a1 =  await service.exec();
//         res.json(a1);
//     }catch(err){
//         res.send("Error " + err);
//     }
// };

exports.createtemplate = async(req,res) => {
    const service = ServiceMaster.findByIdAndUpdate(req.params.id, {$set: {template: req.body.template}});
    try{
        const a1 =  await service.exec();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};
