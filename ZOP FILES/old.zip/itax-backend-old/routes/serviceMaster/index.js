const express = require("express");
const router = express.Router();
const serviceMasterValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const serviceMasterService = require("./service");

router.post(
    "/service",
    validateParams(serviceMasterValidation.create),
    serviceMasterService.create
);

router.get(
    "/services",
    serviceMasterService.get
);


router.get(
    "/service/:id",
    serviceMasterService.getbyId
);

router.delete(
    "/service/:id",
    serviceMasterService.delete
);

router.patch(
    "/service/:id",
    validateParams(serviceMasterValidation.update),
    serviceMasterService.update
);

router.post(
    "/service/:id/milestones",
    validateParams(serviceMasterValidation.createMilestone),
    serviceMasterService.createMilestone
);

router.post(
    "/service/:id/documents",
    validateParams(serviceMasterValidation.createDocuments),
    serviceMasterService.createDocuments
);

router.post(
    "/service/:id/relatedServices",
    serviceMasterService.createrelatedServices
);

// router.post(
//     "/service/:id/serviceCategory",
//     serviceMasterService.createserviceCategory
// );

// router.post(
//     "/service/:id/gstApplicable",
//     validateParams(serviceMasterValidation.createGstApplicable),
//     serviceMasterService.creategstApplicable
// );

router.post(
    "/service/:id/template",
    validateParams(serviceMasterValidation.createtemplate),
    serviceMasterService.createtemplate
);


module.exports = router;
