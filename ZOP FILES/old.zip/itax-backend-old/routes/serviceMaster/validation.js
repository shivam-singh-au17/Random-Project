const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceCategory: Joi.array().required(),
        serviceModel: Joi.string().required(),
        imageUpload: Joi.string(),
        serviceName: Joi.string().required(),
        description: Joi.string().required(),
        customerServiceFee: Joi.number().required(),
        fullPaymentDiscount: Joi.number().required(),
        businessPartnerFee: Joi.number().required(),
        GSTapplicableInter: Joi.string().required(),
        GSTapplicableIntra: Joi.string().required(),
        GSTapplicableInterut: Joi.string().required(),
        tdsApplicable: Joi.string().required(),
        showOnHomePage: Joi.boolean(),
        status: Joi.boolean()
    }),
    update: Joi.object({
        serviceCategory: Joi.array().required(),
        serviceModel: Joi.string().required(),
        imageUpload: Joi.string(),
        serviceName: Joi.string().required(),
        description: Joi.string().required(),
        customerServiceFee: Joi.number().required(),
        fullPaymentDiscount: Joi.number().required(),
        businessPartnerFee: Joi.number().required(),
        GSTapplicableInter: Joi.string().required(),
        GSTapplicableIntra: Joi.string().required(),
        GSTapplicableInterut: Joi.string().required(),
        tdsApplicable: Joi.string().required(),
        showOnHomePage: Joi.boolean(),
        status: Joi.boolean()
    }),
    createMilestone: Joi.object({
        milestones: Joi.array().items({
            milestone: Joi.string().required(),
            period: Joi.string().required(),
            groupHead: Joi.string().required(),
            paymentMilestoneStatus: Joi.boolean().required(),
            milestoneFees: Joi.number().required(),
            paymentPercentage: Joi.number().required(),
            amount: Joi.number().required(),
        })
    }),
    createDocuments: Joi.object({
        documents: Joi.array().items({
            document: Joi.string().required(),
            mandatory: Joi.boolean().required(),
            showOnHomePage: Joi.boolean(),
        }),
    }),
    // createGstApplicable: Joi.object({
    //     gstApplicable: Joi.array().items({
    //         GSTapplicableInter: Joi.string().required(),
    //         GSTapplicableIntra: Joi.string().required(),
    //         GSTapplicableInterut: Joi.string().required(),
    //     }),
    // }),
    createtemplate: Joi.object({
        template: Joi.array().items({
            templateName: Joi.string().required(),
            fileUpload: Joi.string().required(),
        }),
    }),
};
