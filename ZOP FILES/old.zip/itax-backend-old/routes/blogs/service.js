const { Blogs } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async(req,res) => {
    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth()+1;
    let year = date.getFullYear();
    let fullDate = `${day}-${month}-${year}`;
    const blogs = new Blogs({
        blog_category: req.body.blog_category,
        blog_heading: req.body.blog_heading,
        blog_owner: req.body.blog_owner,
        short_description: req.body.short_description,
        full_description: req.body.full_description,
        image: req.body.image,
        created_on: fullDate,
    });

    try{
        const a1 =  await blogs.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async (req,res) => {
    try{
        let blog = Blogs.find();
        if (!isNaN(parseInt(req.query.skip)))
            blog = blog.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            blog = blog.limit(parseInt(req.query.limit));
        let blogs = await blog;
        blogs = await Promise.all(blogs.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.image);
                } catch {
                    readURL = { url: undefined };
                }
                return { ...i._doc, image: readURL};
            }));
        res.json(blogs);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const blog = await Blogs.findById(req.params.id);
        let readURL;
        try {
            readURL = await generateReadSignedURL(blog.image);
        } catch {
            readURL = { url: undefined };
        }
        res.json({...blog._doc, image: readURL});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const blog = await Blogs.findById(req.params.id);
        const a1 = await blog.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const blog = await Blogs.findById(req.params.id);
        blog.blog_category = req.body.blog_category,
        blog.blog_heading = req.body.blog_heading,
        blog.blog_owner = req.body.blog_owner,
        blog.short_description = req.body.short_description,
        blog.full_description = req.body.full_description,
        blog.image = req.body.image;
        const a1 = await blog.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.approve = async(req,res) => {
    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth()+1;
    let year = date.getFullYear();
    let fullDate = `${day}-${month}-${year}`;
    try{
        let blog = await Blogs.findById(req.params.id);
        blog.remark = req.body.remark;
        blog.approved_by = req.body.approved_by;
        blog.approved_on = fullDate;
        if(req.body.approved){
            blog.approval_status = "Approved";
        } else{
            blog.approval_status = "Rejected";
        }
        const a1 =  await blog.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.check = async(req,res) => {
    try{
        let blog = await Blogs.findById(req.params.id);
        blog.published_date = req.body.published_date;
        blog.approvar_remark = req.body.approvar_remark;
        const a1 =  await blog.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};
