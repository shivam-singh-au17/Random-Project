const Joi = require("joi");

module.exports = {
    create: Joi.object({
        blog_category: Joi.string().required(),
        blog_heading: Joi.string().required(),
        blog_owner: Joi.string().required(),
        short_description: Joi.string().required(),
        full_description: Joi.string().required(),
        image: Joi.string(),
    }),
    update: Joi.object({
        blog_category: Joi.string().required(),
        blog_heading: Joi.string().required(),
        blog_owner: Joi.string().required(),
        short_description: Joi.string().required(),
        full_description: Joi.string().required(),
        image: Joi.string(),
    }),
    approve: Joi.object({
        remark: Joi.string().required(),
        approved_by: Joi.string().optional(),
        approved_on: Joi.string().optional(),
        approved: Joi.boolean().required()
    }),
    check: Joi.object({
        published_date: Joi.string().required(),
        approvar_remark: Joi.string().required(),
    }),
};
