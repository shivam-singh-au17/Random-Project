const express = require("express");
const router = express.Router();
const blogsValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const blogsService = require("./service");


router.post(
    "/blog",
    validateParams(blogsValidation.create),
    blogsService.create
);

router.get(
    "/blogs",
    blogsService.get
);

router.get(
    "/blog/:id",
    blogsService.getbyId
);

router.delete(
    "/blog/:id",
    blogsService.delete
);

router.patch(
    "/blog/:id",
    validateParams(blogsValidation.update),
    blogsService.update
);

router.post(
    "/blog/:id/approve",
    validateParams(blogsValidation.approve),
    blogsService.approve
);

router.post(
    "/blog/:id/check",
    validateParams(blogsValidation.check),
    blogsService.check
);

module.exports = router;
