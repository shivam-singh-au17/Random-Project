const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationCalendarEvent = require("./validation");
const { CalendarEvents } = require("../../models/calendarEvents");
const calendarEventService = require("./service");

router.post("/calendarEvent/", validateParams(validationCalendarEvent.create), calendarEventService(CalendarEvents).create);
router.get("/calendarEvents/", calendarEventService(CalendarEvents).get);
router.get("/calendarEvent/:id", calendarEventService(CalendarEvents).getOne);
router.patch("/calendarEvent/:id", validateParams(validationCalendarEvent.update), calendarEventService(CalendarEvents).update);
router.delete("/calendarEvent/:id", calendarEventService(CalendarEvents, "calendarEvent").deleteOne);

module.exports = router;
