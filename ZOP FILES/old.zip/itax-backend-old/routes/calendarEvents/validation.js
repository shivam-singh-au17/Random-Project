const Joi = require("joi");

module.exports = {
    create: Joi.object({
        type: Joi.string(),
        typeId: Joi.string(),
        eventTitle: Joi.string(),
        eventDescription: Joi.string(),
        initiatedBy: Joi.string(),
        initiatedFor: Joi.string(),
        isCompleted: Joi.boolean()
    }),

    update: Joi.object({
        type: Joi.string(),
        typeId: Joi.string(),
        eventTitle: Joi.string(),
        eventDescription: Joi.string(),
        initiatedBy: Joi.string(),
        initiatedFor: Joi.string(),
        isCompleted: Joi.boolean()
    }),
};
