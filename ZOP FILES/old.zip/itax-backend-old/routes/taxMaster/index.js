const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationTaxMaster = require("./validation");
const { TaxMaster } = require("../../models/taxMaster");
const taxMasterService = require("./service");

router.post("/taxMaster/", validateParams(validationTaxMaster.create), taxMasterService(TaxMaster).create);
router.get("/taxMasters/", taxMasterService(TaxMaster).get);
router.get("/taxMaster/:id", taxMasterService(TaxMaster).getOne);
router.put("/taxMaster/:id", validateParams(validationTaxMaster.update), taxMasterService(TaxMaster).update);
router.delete("/taxMaster/:id", taxMasterService(TaxMaster, "taxMaster").deleteOne);

module.exports = router;
