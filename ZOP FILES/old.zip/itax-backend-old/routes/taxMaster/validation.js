const Joi = require("joi");

module.exports = {
    create: Joi.object({
        taxName: Joi.string().required(),
        taxPerc: Joi.number().required(),
    }),
    update: Joi.object({
        taxName: Joi.string().required(),
        taxPerc: Joi.number().required(),
    }),
};


