const hbs = require("nodemailer-express-handlebars");
const nodemailer = require("nodemailer");
const path = require("path");
const config = require("../../../sample.config");

var mainAdmin = nodemailer.createTransport(config.MAIL.TRANSPORT);
var mainUser = nodemailer.createTransport(config.MAIL.TRANSPORT);

const sentEmailTemplateAdmin = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./adminViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./adminViews"),
};

const sentEmailTemplateUser = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./userViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./userViews"),
};

mainAdmin.use("compile", hbs(sentEmailTemplateAdmin));
mainUser.use("compile", hbs(sentEmailTemplateUser));


const create = (model) => async (req, res) => {
    try {
        const sendMailAdmin = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${config.MAIL.ADMINEMAIL}`,
            subject: req.body.subject,
            template: "adminTemplate",
            context: {
                name: req.body.name,
                email: req.body.email,
                mobile: req.body.mobile,
                subject: req.body.subject,
                message: req.body.message,
            }
        };

        const sendMailUser = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${req.body.email}`,
            subject: req.body.subject,
            template: "userTemplate",
            context: {
                message: "Thank You For Connecting!",
            }
        };

        mainAdmin.sendMail(sendMailAdmin, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to ADMIN: " + info.response);
        });

        mainUser.sendMail(sendMailUser, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to USER: " + info.response);
        });

        const item = await model.create(req.body);
        return res.status(200).send({ user: item, status: "Message sent successfully" });

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const get = (model) => async (req, res) => {
    try {
        const item = await model.find().lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const getOne = (model) => async (req, res) => {
    try {
        const item = await model.findById(req.params.id).lean().exec();
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const update = (model) => async (req, res) => {
    try {
        const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true });
        return res.status(200).send(item);

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


const deleteOne = (model, itemName) => async (req, res) => {
    try {
        const item = await model.findByIdAndDelete(req.params.id);
        return res.status(200).json({ [itemName]: item });

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = (model, itemName) => ({
    create: create(model),
    get: get(model),
    getOne: getOne(model),
    update: update(model),
    deleteOne: deleteOne(model, itemName)
});



