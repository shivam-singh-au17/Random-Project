const express = require("express");
const router = express.Router();
const contactValidation = require("./validation");
const { validateParams } = require("../../../middlewares");
const { Contact } = require("../../../models/contact");
const contactService = require("./service");

router.post("/contact/", validateParams(contactValidation.create), contactService(Contact).create);
router.get("/contacts/", contactService(Contact).get);
router.get("/contact/:id", contactService(Contact).getOne);
router.put("/contact/:id", validateParams(contactValidation.update), contactService(Contact).update);
router.delete("/contact/:id", contactService(Contact, "contact").deleteOne);

module.exports = router;

