const express = require("express");
const router = express.Router();
const subscribeValidation = require("./validation");
const { validateParams } = require("../../../middlewares");
const { Subscribe } = require("../../../models/subscribe");
const subscribeService = require("./service");

router.post("/subscribe/", validateParams(subscribeValidation.create), subscribeService(Subscribe).create);
router.get("/subscribes/", subscribeService(Subscribe).get);
router.get("/subscribe/:id", subscribeService(Subscribe).getOne);
router.put("/subscribe/:id", validateParams(subscribeValidation.update), subscribeService(Subscribe).update);
router.delete("/subscribe/:id", subscribeService(Subscribe, "subscribe").deleteOne);

module.exports = router;

