const Joi = require("joi");

module.exports = {
    post: Joi.object({
        serviceType: Joi.string().required(),
        name: Joi.string().required(),
        email: Joi.string().required(),
        mobile: Joi.string().required(),
        message: Joi.string().required()
    }),
};


