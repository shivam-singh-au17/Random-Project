const hbs = require("nodemailer-express-handlebars");
const nodemailer = require("nodemailer");
const path = require("path");
const config = require("../../../sample.config");

var mainAdmin = nodemailer.createTransport(config.MAIL.TRANSPORT);
var mainUser = nodemailer.createTransport(config.MAIL.TRANSPORT);

const sentEmailTemplateAdmin = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./adminViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./adminViews"),
};

const sentEmailTemplateUser = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./userViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./userViews"),
};

mainAdmin.use("compile", hbs(sentEmailTemplateAdmin));
mainUser.use("compile", hbs(sentEmailTemplateUser));


const post = () => async (req, res) => {
    try {
        const sendMailAdmin = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${config.MAIL.ADMINEMAIL}`,
            subject: "Subject For Service",
            template: "adminTemplate",
            context: {
                serviceType: req.body.serviceType,
                name: req.body.name,
                email: req.body.email,
                mobile: req.body.mobile,
                message: req.body.message,
            }
        };

        const sendMailUser = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${req.body.email}`,
            subject: "Subject For Service",
            template: "userTemplate",
            context: {
                message: "Thank You For Connecting!",
            }
        };

        mainAdmin.sendMail(sendMailAdmin, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to ADMIN: " + info.response);
        });

        mainUser.sendMail(sendMailUser, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to USER: " + info.response);
        });

        return res.status(200).send("Message sent successfully");

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = () => ({
    post: post()
});


