const express = require("express");
const router = express.Router();
const serviceValidation = require("./validation");
const { validateParams } = require("../../../middlewares");
const serviceService = require("./service");

router.post("/serviceForm/", validateParams(serviceValidation.post), serviceService().post);

module.exports = router;
