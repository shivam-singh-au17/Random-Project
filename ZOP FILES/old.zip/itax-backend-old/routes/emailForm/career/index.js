const express = require("express");
const router = express.Router();
const careerValidation = require("./validation");
const { validateParams } = require("../../../middlewares");
const careerService = require("./service");
const uplode = require("../../../middlewares/file-uplode");
const { CareerEmail } = require("../../../models/careerEmail");


router.post("/career/", uplode.single("userCV"), validateParams(careerValidation.create), careerService(CareerEmail).create);
router.get("/careers/", careerService(CareerEmail).get);
router.get("/career/:id", careerService(CareerEmail).getOne);
router.put("/career/:id", validateParams(careerValidation.update), careerService(CareerEmail).update);
router.delete("/career/:id", careerService(CareerEmail, "career").deleteOne);

module.exports = router;

