const hbs = require("nodemailer-express-handlebars");
const nodemailer = require("nodemailer");
const path = require("path");
const config = require("../../../sample.config");

var mainAdmin = nodemailer.createTransport(config.MAIL.TRANSPORT);
var mainUser = nodemailer.createTransport(config.MAIL.TRANSPORT);

const sentEmailTemplateAdmin = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./adminViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./adminViews"),
};

const sentEmailTemplateUser = {
    viewEngine: {
        partialsDir: path.join(__dirname, "./userViews"),
        defaultLayout: false,
    },
    viewPath: path.join(__dirname, "./userViews"),
};

mainAdmin.use("compile", hbs(sentEmailTemplateAdmin));
mainUser.use("compile", hbs(sentEmailTemplateUser));


const post = () => async (req, res) => {
    try {
        const sendMailAdmin = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${config.MAIL.ADMINEMAIL}`,
            subject: "Subject For Partner",
            template: "adminTemplate",
            context: {
                workingType: req.body.workingType,
                email: req.body.email,
                firstName: req.body.firstName,
                middleName: req.body.middleName,
                lastName: req.body.lastName,
                mobile: req.body.mobile,
                expertise: req.body.expertise,
            }
        };

        const sendMailUser = {
            from: `${config.MAIL.SENDERADDRESS} <${config.MAIL.TRANSPORT.auth.user}>`,
            to: `${req.body.email}`,
            subject: "Subject For Partner",
            template: "userTemplate",
            context: {
                message: "Thank you for expressing your interest to be our partner!",
            }
        };

        mainAdmin.sendMail(sendMailAdmin, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to ADMIN: " + info.response);
        });

        mainUser.sendMail(sendMailUser, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log("Message sent to USER: " + info.response);
        });

        return res.status(200).send("Message sent successfully");

    } catch (err) {
        return res.status(400).send(err.message);
    }
};


module.exports = () => ({
    post: post()
});


