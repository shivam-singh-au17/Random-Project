const Joi = require("joi");

module.exports = {
    create: Joi.object({
        videoHeading: Joi.string().required(),
        videoURL: Joi.string().required(),
        decription: Joi.string().required(),
        isFeatured: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
    update: Joi.object({
        videoHeading: Joi.string().required(),
        videoURL: Joi.string().required(),
        decription: Joi.string().required(),
        isFeatured: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
};

