const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationFeaturedVideos = require("./validation");
const { FeaturedVideos } = require("../../../models/featuredVideos");
const featuredVideosService = require("./service");

router.post("/featuredVideo/", validateParams(validationFeaturedVideos.create), featuredVideosService(FeaturedVideos).create);
router.get("/featuredVideos/", featuredVideosService(FeaturedVideos).get);
router.get("/featuredVideo/:id", featuredVideosService(FeaturedVideos).getOne);
router.put("/featuredVideo/:id", validateParams(validationFeaturedVideos.update), featuredVideosService(FeaturedVideos).update);
router.delete("/featuredVideo/:id", featuredVideosService(FeaturedVideos, "featuredVideos").deleteOne);

module.exports = router;
