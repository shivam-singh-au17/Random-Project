const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationFAQ = require("./validation");
const { FAQ } = require("../../../models/FAQ");
const FAQService = require("./service");

router.post("/FAQ/", validateParams(validationFAQ.create), FAQService(FAQ).create);
router.get("/FAQS/", FAQService(FAQ).get);
router.get("/FAQ/:id", FAQService(FAQ).getOne);
router.put("/FAQ/:id", validateParams(validationFAQ.update), FAQService(FAQ).update);
router.delete("/FAQ/:id", FAQService(FAQ, "FAQ").deleteOne);

module.exports = router;
