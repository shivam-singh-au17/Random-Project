const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceCategory: Joi.string().required(),
        serviceName: Joi.string().required(),
        questioon: Joi.string().required(),
        answer: Joi.string().required(),
    }),
    update: Joi.object({
        serviceCategory: Joi.string().required(),
        serviceName: Joi.string().required(),
        questioon: Joi.string().required(),
        answer: Joi.string().required(),
    }),
};

