const Joi = require("joi");

module.exports = {
    create: Joi.object({
        serviceCategory: Joi.string().required(),
        formName: Joi.string().required(),
        status: Joi.boolean().required(),
        decription: Joi.string().required(),
        docDocument: Joi.string().required(),
        pdfDocument: Joi.string().required(),
        excelDocument: Joi.string().required(),
    }),
    update: Joi.object({
        serviceCategory: Joi.string().required(),
        formName: Joi.string().required(),
        status: Joi.boolean().required(),
        decription: Joi.string().required(),
        docDocument: Joi.string().required(),
        pdfDocument: Joi.string().required(),
        excelDocument: Joi.string().required(),
    }),
};

