const express = require("express");
const router = express.Router();
const { validateParams } = require("../../../middlewares");
const validationDownloadForms = require("./validation");
const { DownloadForms } = require("../../../models/downloadForms");
const downloadFormsService = require("./service");


router.post("/downloadForm/", validateParams(validationDownloadForms.create), downloadFormsService(DownloadForms).create);
router.get("/downloadForms/", downloadFormsService(DownloadForms).get);
router.get("/getByServiceCategory/:id", downloadFormsService(DownloadForms).getByServiceCategory);
router.get("/getByFormName/:id", downloadFormsService(DownloadForms).getByFormName);
router.get("/downloadForm/:id", downloadFormsService(DownloadForms).getOne);
router.put("/downloadForm/:id", validateParams(validationDownloadForms.update), downloadFormsService(DownloadForms).update);
router.delete("/downloadForm/:id", downloadFormsService(DownloadForms, "downloadForm").deleteOne);


module.exports = router;

