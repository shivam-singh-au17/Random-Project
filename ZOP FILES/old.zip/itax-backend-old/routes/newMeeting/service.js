const { NewMeeting } = require("../../models");

exports.create = async(req,res) => {
    const newMeeting = new NewMeeting({
        dateOfMeeting: req.body.dateOfMeeting,
        selectTime: req.body.selectTime,
        duration: req.body.duration,
        meetingWith: req.body.meetingWith,
        nameOfUser: req.body.nameOfUser,
        serviceTicketNo: req.body.serviceTicketNo,
        meetingStatus: req.body.meetingStatus,
        nameOfService: req.body.nameOfService,
        serviceName: req.body.serviceName,
        agendaOfMeeting: req.body.agendaOfMeeting,
        meeting_link: req.body.meeting_link,
    });

    try{
        const a1 =  await newMeeting.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let newMeeting = NewMeeting.find({status: false}).populate("serviceTicketNo");
        if (!isNaN(parseInt(req.query.skip)))
            newMeeting = newMeeting.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            newMeeting = newMeeting.limit(parseInt(req.query.limit));
        let newMeetings = await newMeeting;
        res.json(newMeetings);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const newMeeting = await NewMeeting.findById(req.params.id).populate("serviceTicketNo");
        res.json(newMeeting);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const newMeeting = await NewMeeting.findById(req.params.id);
        const a1 = await newMeeting.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const newMeeting = await NewMeeting.findById(req.params.id);
        newMeeting.ateOfMeeting = req.body.dateOfMeeting,
        newMeeting.selectTime = req.body.selectTime,
        newMeeting.duration = req.body.duration,
        newMeeting.meetingWith = req.body.meetingWith,
        newMeeting.nameOfUser = req.body.nameOfUser,
        newMeeting.serviceTicketNo = req.body.serviceTicketNo,
        newMeeting.meetingStatus = req.body.meetingStatus,
        newMeeting.nameOfService = req.body.nameOfService,
        newMeeting.serviceName = req.body.serviceName,
        newMeeting.agendaOfMeeting = req.body.agendaOfMeeting,
        newMeeting.meeting_link = req.body.meeting_link,
        newMeeting.meetTime = req.body.meetTime,
        newMeeting.comments = req.body.comments,
        newMeeting.status = req.body.status;
        const a1 = await newMeeting.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.createserviceDetails = async(req,res) => {
    try{
        const newMeeting = await NewMeeting.find({serviceTicketNo: req.params.id }).populate("serviceTicketNo")
            .populate({
                path: "serviceTicketNo",
                populate: [
                    {
                        path: "serviceMasterId",
                        model: "serviceMasterNew"
                    },
                    {
                        path: "financialYearId",
                        model: "Option"
                    },
                    {
                        path: "customerId",
                        model: "authFrontend"
                    },
                    {
                        path: "assignedTo",
                        model: "Registeration"
                    },
                    {
                        path: "allMilestoneData",
                        populate: [
                            {
                                path: "milestoneId",
                                model: "serviceMilestoneNew"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                            {
                                path: "calenderId",
                                model: "Calendar"
                            },
                        ]
                    },
                ]
            });
        res.status(200).json(newMeeting);
    }catch(err){
        res.status(400).send("Error " + err);
    }
};

exports.previousMeeting = async(req,res) => {
    try{
        const newMeeting = await NewMeeting.find({status: true});
        res.json(newMeeting);
    }catch(err){
        res.send("Error " + err);
    }
};
