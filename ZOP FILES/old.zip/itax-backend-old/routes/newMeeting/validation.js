const Joi = require("joi");

module.exports = {
    create: Joi.object({
        dateOfMeeting: Joi.string().required(),
        selectTime: Joi.string().required(),
        duration: Joi.string().allow(""),
        meetingWith: Joi.string().required(),
        nameOfUser: Joi.string().required(),
        serviceTicketNo: Joi.string().required(),
        meetingStatus: Joi.string().required(),
        nameOfService: Joi.string().required(),
        serviceName: Joi.string().required(),
        agendaOfMeeting: Joi.string().allow(""),
        meeting_link: Joi.string().required(),
    }),
    update: Joi.object({
        dateOfMeeting: Joi.string().required(),
        selectTime: Joi.string().required(),
        duration: Joi.string().allow(""),
        meetingWith: Joi.string().required(),
        nameOfUser: Joi.string().required(),
        serviceTicketNo: Joi.string().required(),
        meetingStatus: Joi.string().required(),
        nameOfService: Joi.string().required(),
        serviceName: Joi.string().required(),
        agendaOfMeeting: Joi.string().allow(""),
        meeting_link: Joi.string().required(),
        meetTime: Joi.string().allow(""),
        comments: Joi.string().allow(""),
        status: Joi.boolean(),
    }),
};
