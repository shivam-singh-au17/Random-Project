const express = require("express");
const router = express.Router();
const newMeetingValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const newMeetingService = require("./service");

router.post(
    "/newMeeting",
    validateParams(newMeetingValidation.create),
    newMeetingService.create
);

router.get(
    "/newMeetings",
    newMeetingService.get
);


router.get(
    "/newMeeting/:id",
    newMeetingService.getbyId
);

router.delete(
    "/newMeeting/:id",
    newMeetingService.delete
);

router.patch(
    "/newMeeting/:id",
    validateParams(newMeetingValidation.update),
    newMeetingService.update
);

router.get(
    "/newMeeting/serviceTransaction/:id",
    newMeetingService.createserviceDetails
);

router.get(
    "/newMeetingpreviousMeeting",
    newMeetingService.previousMeeting
);

module.exports = router;
