const Joi = require("joi");

module.exports = {
    create: Joi.object({
        couponHeading: Joi.string().required(),
        couponCode: Joi.string().required(),
        selectCustomer: Joi.string().required(),
        selectService: Joi.string().required(),
        validFrom: Joi.string().required(),
        validTo: Joi.string().required(),
        couponDiscount: Joi.number().required(),
        amount: Joi.number().required(),
        remarks: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
    update: Joi.object({
        couponHeading: Joi.string().required(),
        couponCode: Joi.string().required(),
        selectCustomer: Joi.string().required(),
        selectService: Joi.string().required(),
        validFrom: Joi.string().required(),
        validTo: Joi.string().required(),
        couponDiscount: Joi.number().required(),
        amount: Joi.number().required(),
        remarks: Joi.string().required(),
        status: Joi.boolean().required(),
    }),
};
