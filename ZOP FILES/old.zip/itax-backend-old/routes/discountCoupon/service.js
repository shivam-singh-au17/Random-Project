const { DiscountCoupon,ServiceCategories,CustomerMgmt } = require("../../models");

exports.create = async(req,res) => {
    const discount = new DiscountCoupon({
        couponHeading: req.body.couponHeading,
        couponCode: req.body.couponCode,
        selectCustomer: req.body.selectCustomer,
        selectService: req.body.selectService,
        validFrom: req.body.validFrom,
        validTo: req.body.validTo,
        couponDiscount: req.body.couponDiscount,
        amount: req.body.amount,
        remarks: req.body.remarks,
        status: req.body.status,
    });

    try{
        const a1 =  await discount.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let discount = DiscountCoupon.find();
        if (!isNaN(parseInt(req.query.skip)))
            discount = discount.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            discount = discount.limit(parseInt(req.query.limit));
        let discounts = await discount;
        discounts = await Promise.all(discounts.map(
            async (i) => {
                const m = await ServiceCategories.findById(i.selectService);
                const n = await CustomerMgmt.findById(i.selectCustomer);
                return { ...i._doc,selectService:m,selectCustomer:n };
            },
        ));
        res.json(discounts);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const discount = await DiscountCoupon.findById(req.params.id);
        const serviceCheck = await ServiceCategories.findById(discount.selectService);
        const customerCheck = await CustomerMgmt.findById(discount.selectCustomer);
        res.json({...discount._doc, selectService:serviceCheck, selectCustomer:customerCheck});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const discount = await DiscountCoupon.findById(req.params.id);
        const a1 = await discount.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const discount = await DiscountCoupon.findById(req.params.id);
        discount.couponHeading = req.body.couponHeading,
        discount.couponCode = req.body.couponCode,
        discount.selectCustomer = req.body.selectCustomer,
        discount.selectService = req.body.selectService,
        discount.validFrom = req.body.validFrom,
        discount.validTo = req.body.validTo,
        discount.couponDiscount = req.body.couponDiscount,
        discount.amount = req.body.amount,
        discount.remarks = req.body.remarks,
        discount.status = req.body.status;
        const a1 = await discount.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
