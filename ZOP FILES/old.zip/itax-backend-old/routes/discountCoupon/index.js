const express = require("express");
const router = express.Router();
const discountCouponValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const discountCouponService = require("./service");

router.post(
    "/discountCoupon",
    validateParams(discountCouponValidation.create),
    discountCouponService.create
);

router.get(
    "/discountCoupons",
    discountCouponService.get
);


router.get(
    "/discountCoupon/:id",
    discountCouponService.getbyId
);

router.delete(
    "/discountCoupon/:id",
    discountCouponService.delete
);

router.patch(
    "/discountCoupon/:id",
    validateParams(discountCouponValidation.update),
    discountCouponService.update
);

module.exports = router;
