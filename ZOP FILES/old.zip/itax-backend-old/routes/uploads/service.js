const { generateSignedURL } = require("../../utils/minio");
const { v1 } = require("uuid");
exports.upload = (path) => async (req, res, next) => {
    const filename = `${v1()}/${path}.${req.params.filetype}`;
    try {
        res.json(await generateSignedURL(filename));
    } catch (error) {
        res.status(500).json({ error });
    }
};
