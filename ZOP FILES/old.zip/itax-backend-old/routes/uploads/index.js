const express = require("express");
const router = express.Router();
const service = require("./service");


router.post(
    "/upload/caselaw/decisionFile/:filetype",
    service.upload("caselaw/decisionFile")
);

router.post(
    "/upload/serviceCategory/banner/:filetype",
    service.upload("serviceCategory/banner")
);
router.post(
    "/upload/newsLetters/fileUpload/:filetype",
    service.upload("newsLetter/fileupload")
);

router.post(
    "/upload/events/event_image_banner/:filetype",
    service.upload("events/event_image_banner")
);

router.post(
    "/upload/customerMgmt/imageupload/:filetype",
    service.upload("customerMgmt/imageupload")
);

router.post(
    "/upload/customerMgmt/adharCard/:filetype",
    service.upload("customerMgmt/adharCard")
);

router.post(
    "/upload/customerMgmt/panCard/:filetype",
    service.upload("customerMgmt/panCard")
);

router.post(
    "/upload/customerMgmt/companyRegistration/:filetype",
    service.upload("customerMgmt/companyRegistration")
);

router.post(
    "/upload/customerMgmt/gstRegistration/:filetype",
    service.upload("customerMgmt/gstRegistration")
);

router.post(
    "/upload/blogs/banner/:filetype",
    service.upload("blogs/banner")
);

router.post(
    "/upload/serviceMaster/template/fileUpload/:filetype",
    service.upload("serviceMaster/fileUpload")
);

router.post(
    "/upload/serviceMaster/imageUpload/:filetype",
    service.upload("serviceMaster/imageUpload")
);

router.post(
    "/upload/registration/upload_photo/:filetype",
    service.upload("registration/upload_photo")
);

router.post(
    "/upload/registration/upload_biodata/:filetype",
    service.upload("registration/upload_biodata")
);

router.post(
    "/upload/registration/qualification/chooseFile/:filetype",
    service.upload("registration/qualification")
);

router.post(
    "/upload/registration/bankDetails/cancelledCheque/:filetype",
    service.upload("registration/cancelledCheque")
);

router.post(
    "/upload/registration/document/adharCard/:filetype",
    service.upload("registration/adharCard")
);

router.post(
    "/upload/registration/document/panCard/:filetype",
    service.upload("registration/panCard")
);

router.post(
    "/upload/registration/document/companyRegistration/:filetype",
    service.upload("registration/companyRegistration")
);

router.post(
    "/upload/registration/document/gstRegistration/:filetype",
    service.upload("registration/gstRegistration")
);

router.post(
    "/upload/serviceTransaction/documents/:filetype",
    service.upload("serviceTransaction/fileUpload")
);

router.post(
    "/upload/invoiceUpload/uploadInvoice/:filetype",
    service.upload("invoiceUpload/fileUpload")
);

router.post(
    "/upload/invoiceUpload/reinDocument/:filetype",
    service.upload("invoiceUpload/fileUpload")
);

module.exports = router;
