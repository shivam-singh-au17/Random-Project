const Joi = require("joi");

module.exports = {
    create: Joi.object({
        stateName: Joi.string().required(),
        stateCode: Joi.string().required(),
    }),
    update: Joi.object({
        stateName: Joi.string().required(),
        stateCode: Joi.string().required(),
    }),
};

