const express = require("express");
const router = express.Router();
const { validateParams } = require("../../middlewares");
const validationStateMaster = require("./validation");
const { StateMaster } = require("../../models/stateMaster");
const stateMasterService = require("./service");

router.post("/stateMaster/", validateParams(validationStateMaster.create), stateMasterService(StateMaster).create);
router.get("/stateMasters/", stateMasterService(StateMaster).get);
router.get("/stateMaster/:id", stateMasterService(StateMaster).getOne);
router.put("/stateMaster/:id", validateParams(validationStateMaster.update), stateMasterService(StateMaster).update);
router.delete("/stateMaster/:id", stateMasterService(StateMaster, "stateMaster").deleteOne);

module.exports = router;
