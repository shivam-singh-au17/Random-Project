const Joi = require("joi");

module.exports = {
    register: Joi.object({
        email: Joi.string().required(),
        password: Joi.string().required(),
        roles: Joi.array().required(),
    }),
    login: Joi.object({
        email: Joi.string().required(),
        password: Joi.string().required(),
    }),
};

