const express = require("express");
const router = express.Router();
const caselawValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const caselawService = require("./service");


router.post(
    "/caselaw",
    validateParams(caselawValidation.create),
    caselawService.create
);

router.get(
    "/caselaws",
    caselawService.get
);

router.get(
    "/caselaw/:id",
    caselawService.getbyId
);

router.delete(
    "/caselaw/:id",
    caselawService.delete
);


router.patch(
    "/caselaw/:id",
    validateParams(caselawValidation.update),
    caselawService.update
);

module.exports = router;
