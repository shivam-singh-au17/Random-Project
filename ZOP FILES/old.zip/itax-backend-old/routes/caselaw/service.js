const { CaseLaw, Option } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");
let ejs = require("ejs");
let path = require("path");
let pdf = require("html-pdf");
// let fs = require("fs");
let { v1 } = require("uuid");
let { minioClient } = require("../../utils/minio");
let config = require("../../config");

exports.create = async(req,res) => {
    let dtOfOrder =req.body.dateOfOrder;
    if(dtOfOrder.length<10)
    {
        dtOfOrder =  await convertDate(req.body.dateOfOrder);
    }
    var dateParts = dtOfOrder.split("/");
    // month is 0-based, that's why we need dataParts[1] - 1
    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    const year = dateObject.getFullYear();
    const creation = year;
    const count = await CaseLaw.find({ yearOfCreation: creation});
    const courtName = await Option.findOne({ value: req.body.courtName});
    // let dtOfOrder =req.body.dateOfOrder;
    // if(dtOfOrder.length<10)
    // {
    //     dtOfOrder =  await convertDate(req.body.dateOfOrder);
    // }
    let convert = dtOfOrder.split("/");
    let converted =  convert[2];
    const check = converted - 1900;
    const ejsdata = {
        yearOfCreation: creation,
        citation: `( ${converted}) ${check} iTaxDirect.com ${ count.length + 1 } [${req.body.courtName}]`,
        courtName: courtName.label,
        caseName: req.body.caseName,
        caseNumber: req.body.caseNumber,
        judgeName: req.body.judgeName,
        dateOfOrder: dtOfOrder,
        keyword: req.body.keyword,
        sub_caseName: req.body.sub_caseName,
        headNote: req.body.headNote,
        inFavourOf: req.body.inFavourOf,
        appearedForPetitioner: req.body.appearedForPetitioner,
        appearedForRespondent: req.body.appearedForRespondent,
        otherCitation: req.body.otherCitation,
        decisionJudgement: req.body.decisionJudgement
    };
    let filename = ejsdata.citation
        .replace(/[^A-Za-z0-9]+/g, "_")
        .replace(/^_*|_*$/, "");
    filename = `caselaw/generatedPdf/${v1()}/${filename}.pdf`;
    let data = new Promise((resolve, reject) => {
        ejs.renderFile(path.join(__dirname, "views", "caselaw.ejs"),ejsdata,{}, function(err, ejsdata){
            if(err) reject(err);
            else resolve(ejsdata);
        });
    });

    let sett= {
        "format": "Letter",
        "border": {
            "top": "0.25in",
            "right": "0.5in",
            "bottom": "0.5in"
        },
        paginationOffset: 1,
        "footer": {
            "height": "5mm",
            "contents": {
                default: `<hr style="height:2px; border:none;color:#333;background-color:#333;" />
                    <table style="width: 100%"><tr>
                    <td style=" text-align: center"><span>(Page No.{{page}}</span>/<span>{{pages}}</span>)</td>
                    <td style=" text-align: right"><label>${ejsdata.citation}</label></td></tr></table>`,
            }
        },
    };

    let html = await data;
    pdf.create(html,sett).toStream(function(err, stream){
        minioClient.putObject(config.MINIO.bucketName, filename, stream);
        // stream.pipe(fs.createWriteStream(path.join(__dirname, "views", "file.pdf")));
    });


    const caselaw = new CaseLaw({
        act: req.body.act,
        caseNumber: req.body.caseNumber,
        section: req.body.section,
        dateOfOrder: req.body.dateOfOrder,
        yearOfCreation: creation,
        caseName: req.body.caseName,
        sub_caseName: req.body.sub_caseName,
        inFavourOf: req.body.inFavourOf,
        appealFilingDate: req.body.appealFilingDate,
        keyword: req.body.keyword,
        courtName: req.body.courtName,
        citation: `(${converted}) ${check} iTaxDirect.com ${ count.length + 1 }  [${courtName.value}]`,
        headNote: req.body.headNote,
        decisionJudgement: req.body.decisionJudgement,
        status: req.body.status,
        uploadDecisionFile : req.body.uploadDecisionFile,
        otherCitation: req.body.otherCitation,
        judgeName: req.body.judgeName,
        appearedForPetitioner: req.body.appearedForPetitioner,
        appearedForRespondent: req.body.appearedForRespondent,
        generatedPdf: filename,
    });

    try{
        const valid = await isAlreadyExist(caselaw.caseName, caselaw.sub_caseName);
        if(valid){ return res.send({ message : "CaseName/Sub-CaseName already exist" });}
        const a1 =  await caselaw.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

function regex(string){
    string = string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`.*${string}.*`, "i");
}
exports.get = async (req,res) => {
    try{
        let deleted = (req.query.deleted === "true");
        let query = {isDeleted: deleted};
        if(req.query.key)
            query = { ...query, $text : { $search : req.query.key }};
        if (req.query.act)
            query = { ...query, act : { $regex : regex(req.query.act) }};
        if (req.query.section)
            query = { ...query, section : { $regex : regex(req.query.section) }};
        if (req.query.caseName)
            query = { ...query, caseName : { $regex : regex(req.query.caseName) }};
        if (req.query.caseNumber)
            query = { ...query, caseNumber : { $regex : regex(req.query.caseNumber) }};
        if (req.query.dateOfOrder)
            query = { ...query, dateOfOrder : { $regex : regex(req.query.dateOfOrder) }};
        if (req.query.inFavourOf)
            query = { ...query, inFavourOf : { $regex : regex(req.query.inFavourOf) }};
        if (req.query.citation)
            query = { ...query, citation : { $regex : regex(req.query.citation) }};
        if (req.query.judgeName)
            query = { ...query, judgeName : { $regex : regex(req.query.judgeName) }};
        if (req.query.courtName)
            query = { ...query, courtName : { $regex : regex(req.query.courtName) }};
        let caselawQuery = CaseLaw.find(query);
        if (!isNaN(parseInt(req.query.skip)))
            caselawQuery = caselawQuery.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            caselawQuery = caselawQuery.limit(parseInt(req.query.limit));
        let caselaw = await caselawQuery;
        let a1 = caselaw.map( i => ({
            act: i.act,
            section: i.section,
            caseName: i.caseName,
            caseNumber: i.caseNumber,
            dateOfOrder: i.dateOfOrder,
            inFavourOf: i.inFavourOf,
            status: i.status,
            keyword: i.keyword,
            citation: i.citation,
            judgeName:i.judgeName,
            courtName: i.courtName,
            _id: i._id,
            isDeleted: i.isDeleted,
        }));
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const caselaw = await CaseLaw.findById(req.params.id);
        let check = await Option.findOne({ value: caselaw.courtName, option: "court"});
        let readURL;
        try {
            readURL = await generateReadSignedURL(caselaw.uploadDecisionFile);
        } catch {
            readURL = { url: undefined };
        }
        let pdfURL;
        try {
            pdfURL = await generateReadSignedURL(caselaw.generatedPdf);
        } catch {
            pdfURL = { url: undefined };
        }

        const related = (await CaseLaw.find({ $text: { $search: caselaw.keyword.replace(",", "") }, isDeleted: false }))
            .slice(0, 10)
            .filter(i => i._id !== caselaw._id)
            .map(i => ({
                _id: i._id,
                caseName: i.caseName,
                section: i.section,
                judgeName: i.judgeName,
                keyword: i.keyword,
                dateOfOrder: i.dateOfOrder,
            }));
        res.json({...caselaw._doc, uploadDecisionFile: readURL, generatedPdf: pdfURL, court: check, related});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const caselaw = await CaseLaw.findByIdAndUpdate(req.params.id, { $set: { isDeleted: true } });
        res.json(caselaw);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    const year = new Date().getFullYear();
    const creation = year;
    // const count = await CaseLaw.find({ yearOfCreation: creation});
    const courtName = await Option.findOne({ value: req.body.courtName});
    try{
        const caselaw = await CaseLaw.findById(req.params.id);
        const caseCitation = caselaw.citation;
        const valid = await isAlreadyExistForUpdate(req.body.caseName,req.body.sub_caseName,req.params.id );
        if(valid){ return res.send({ message : "CaseName/Sub-CaseName already exist" });}

        const dtOfOrder = await convertDate(req.body.dateOfOrder);
        const ejsdata = {
            yearOfCreation: creation,
            citation: caseCitation,
            courtName: courtName.label,
            caseName: req.body.caseName,
            caseNumber: req.body.caseNumber,
            judgeName: req.body.judgeName,
            dateOfOrder: dtOfOrder,
            keyword: req.body.keyword,
            sub_caseName: req.body.sub_caseName,
            headNote: req.body.headNote,
            inFavourOf: req.body.inFavourOf,
            appearedForPetitioner: req.body.appearedForPetitioner,
            appearedForRespondent: req.body.appearedForRespondent,
            otherCitation: req.body.otherCitation,
            decisionJudgement: req.body.decisionJudgement
        };
        let filename = caseCitation
            .replace(/[^A-Za-z0-9]+/g, "_")
            .replace(/^_*|_*$/, "");
        filename = `caselaw/generatedPdf/${v1()}/${filename}.pdf`;
        let data = new Promise((resolve, reject) => {
            ejs.renderFile(path.join(__dirname, "views", "caselaw.ejs"),ejsdata,{}, function(err, ejsdata){
                if(err) reject(err);
                else resolve(ejsdata);
            });
        });

        let sett= {
            "format": "Letter",
            "border": {
                "top": "0.25in",
                "right": "0.5in",
                "bottom": "0.5in"
            },
            paginationOffset: 1,
            "footer": {
                "height": "5mm",
                "contents": {
                    default: `<hr style="height:2px; border:none;color:#333;background-color:#333;" />
                        <table style="width: 100%"><tr>
                        <td style=" text-align: center"><span>(Page No.{{page}}</span>/<span>{{pages}}</span>)</td>
                        <td style=" text-align: right"><label>${ejsdata.citation}</label></td></tr></table>`,
                }
            },
        };

        let html = await data;
        pdf.create(html,sett).toStream(function(err, stream){
            minioClient.putObject(config.MINIO.bucketName, filename, stream);
            // stream.pipe(fs.createWriteStream(path.join(__dirname, "views", "file.pdf")));
        });

        caselaw.act = req.body.act,
        caselaw.caseNumber = req.body.caseNumber,
        caselaw.section = req.body.section,
        caselaw.dateOfOrder = req.body.dateOfOrder,
        caselaw.caseName = req.body.caseName,
        caselaw.sub_caseName = req.body.sub_caseName,
        caselaw.inFavourOf = req.body.inFavourOf,
        caselaw.appealFilingDate = req.body.appealFilingDate,
        caselaw.keyword = req.body.keyword,
        caselaw.courtName = req.body.courtName,
        caselaw.citation = caseCitation;//`(${year}) ${check} iTaxDirect.com ${ count.length + 1 } [${req.body.courtName}]`,
        caselaw.headNote = req.body.headNote,
        caselaw.decisionJudgement = req.body.decisionJudgement,
        caselaw.status = req.body.status,
        caselaw.uploadDecisionFile = req.body.uploadDecisionFile,
        caselaw.otherCitation = req.body.otherCitation,
        caselaw.judgeName = req.body.judgeName,
        caselaw.appearedForPetitioner = req.body.appearedForPetitioner,
        caselaw.appearedForRespondent = req.body.appearedForRespondent;
        caselaw.generatedPdf= filename;
        const a1 = await caselaw.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

const isAlreadyExist = async(name, subCaseName)=>{
    try {
        const data = await CaseLaw.findOne({ $and: [
            { $or: [
                { caseName: name },
                { sub_caseName: subCaseName }
            ],
            isDeleted: false
            },
        ]});
        if(data) return true ;
        else return false ;

    } catch (err) {
        return { err: err.message };
    }
};
const convertDate = async(inputFormat)=>{
    function pad(s) { return (s < 10) ? "0" + s : s; }
    var d = new Date(inputFormat);
    return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join("/");
};

const isAlreadyExistForUpdate = async(name,subCaseName,id)=>{
    const data = await CaseLaw.findOne({ $and: [
        { $or: [
            { caseName: name },
            { sub_caseName: subCaseName }
        ],
        isDeleted: false,
        _id :{$ne : id}
        },
    ]});
    if(data) return true ;
    return false;
};
