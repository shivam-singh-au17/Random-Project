const Joi = require("joi");

module.exports = {
    create: Joi.object({
        act: Joi.string().required(),
        caseNumber: Joi.string().required(),
        section: Joi.string().required(),
        dateOfOrder: Joi.string().required(),
        caseName: Joi.string().required(),
        sub_caseName: Joi.string().required(),
        inFavourOf: Joi.string().required(),
        appealFilingDate: Joi.string(),
        keyword: Joi.string().required(),
        courtName: Joi.string().required(),
        headNote: Joi.string().required(),
        decisionJudgement: Joi.string().required(),
        status: Joi.boolean(),
        uploadDecisionFile: Joi.string(),
        otherCitation: Joi.string(),
        judgeName: Joi.string().required(),
        appearedForPetitioner: Joi.string().required(),
        appearedForRespondent: Joi.string().required()
    }),
    update: Joi.object({
        act: Joi.string().required(),
        caseNumber: Joi.string().required(),
        section: Joi.string().required(),
        dateOfOrder: Joi.string().required(),
        caseName: Joi.string().required(),
        sub_caseName: Joi.string().required(),
        inFavourOf: Joi.string().required(),
        appealFilingDate: Joi.string(),
        keyword: Joi.string().required(),
        courtName: Joi.string().required(),
        headNote: Joi.string().required(),
        decisionJudgement: Joi.string().required(),
        status: Joi.boolean(),
        uploadDecisionFile: Joi.string(),
        otherCitation: Joi.string(),
        judgeName: Joi.string().required(),
        appearedForPetitioner: Joi.string().required(),
        appearedForRespondent: Joi.string().required()
    }),
};
