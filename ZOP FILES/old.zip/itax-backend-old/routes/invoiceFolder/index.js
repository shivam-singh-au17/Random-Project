const express = require("express");
const router = express.Router();
const invoiceUploadValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const invoiceUploadService = require("./service");

router.post(
    "/invoiceUpload",
    validateParams(invoiceUploadValidation.create),
    invoiceUploadService.create
);

router.get(
    "/invoiceUploads",
    invoiceUploadService.get
);

router.get(
    "/invoiceUpload/:id",
    invoiceUploadService.getbyId
);

router.delete(
    "/invoiceUpload/:id",
    invoiceUploadService.delete
);

router.patch(
    "/invoiceUpload/:id",
    validateParams(invoiceUploadValidation.update),
    invoiceUploadService.update
);

router.get(
    "/invoiceUpload/serviceDetails/:id",
    invoiceUploadService.createserviceDetails
);

// router.get(
//     "/invoiceUpload/invoiceCheck/:id",
//     invoiceUploadService.createinvoiceCheck
// );

module.exports = router;
