const { InvoiceUpload } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");
exports.create = async(req,res) => {
    const invoice = new InvoiceUpload({
        serviceRequestNo: req.body.serviceRequestNo,
        ticketNo: req.body.ticketNo,
        ticketDate: req.body.ticketDate,
        ticketstatus: req.body.ticketstatus,
        typeInvoice: req.body.typeInvoice,
        serviceFee: req.body.serviceFee,
        invoiceNumber: req.body.invoiceNumber,
        invoiceDate: req.body.invoiceDate,
        invoiceStatus: req.body.invoiceStatus,
        alreadyInvoice: req.body.alreadyInvoice,
        professionalFee: req.body.professionalFee,
        gstAmount: req.body.gstAmount,
        reimExp: req.body.reimExp,
        uploadInvoice: req.body.uploadInvoice,
        reinDocument: req.body.reinDocument,
        totalAmount: req.body.totalAmount,
        balanceAmount: req.body.balanceAmount,
        remarks: req.body.remarks,
        serviceId: req.body.serviceId,
    });

    try{
        const a1 =  await invoice.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async(req,res) => {
    try{
        let invoice = InvoiceUpload.find().populate("serviceId")
            .populate({
                path: "serviceId",
                populate: [
                    {
                        path: "serviceMasterId",
                        model: "serviceMasterNew"
                    },
                    {
                        path: "financialYearId",
                        model: "Option"
                    },
                    {
                        path: "customerId",
                        model: "authFrontend"
                    },
                    {
                        path: "assignedTo",
                        model: "Registeration"
                    },
                    {
                        path: "allMilestoneData",
                        populate: [
                            {
                                path: "milestoneId",
                                model: "serviceMilestoneNew"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                            {
                                path: "calenderId",
                                model: "Calendar"
                            },
                        ]
                    },
                ]
            });
        if (!isNaN(parseInt(req.query.skip)))
            invoice = invoice.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            invoice = invoice.limit(parseInt(req.query.limit));
        let invoices = await invoice;
        invoices = await Promise.all(invoices.map(
            async i => {
                i = i.toObject();
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.uploadInvoice);
                } catch {
                    readURL = { url: undefined };
                }
                let imageURL;
                try {
                    imageURL = await generateReadSignedURL(i.reinDocument);
                } catch {
                    imageURL = { url: undefined };
                }
                return { ...i, uploadInvoice: readURL, reinDocument: imageURL };
            }));
        res.json(invoices);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const invoice = await InvoiceUpload.findById(req.params.id).populate("serviceId")
            .populate({
                path: "serviceId",
                populate: [
                    {
                        path: "serviceMasterId",
                        model: "serviceMasterNew"
                    },
                    {
                        path: "financialYearId",
                        model: "Option"
                    },
                    {
                        path: "customerId",
                        model: "authFrontend"
                    },
                    {
                        path: "assignedTo",
                        model: "Registeration"
                    },
                    {
                        path: "allMilestoneData",
                        populate: [
                            {
                                path: "milestoneId",
                                model: "serviceMilestoneNew"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                            {
                                path: "calenderId",
                                model: "Calendar"
                            },
                        ]
                    },
                ]
            });
        let readURL;
        try {
            readURL = await generateReadSignedURL(invoice.uploadInvoice);
        } catch {
            readURL = { url: undefined };
        }
        let pdfURL;
        try {
            pdfURL = await generateReadSignedURL(invoice.reinDocument);
        } catch {
            pdfURL = { url: undefined };
        }
        res.json({...invoice._doc, uploadInvoice: readURL, reinDocument: pdfURL});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const invoice = await InvoiceUpload.findById(req.params.id);
        const a1 = await invoice.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const invoice = await InvoiceUpload.findById(req.params.id);
        invoice.serviceRequestNo = req.body.serviceRequestNo,
        invoice.ticketNo = req.body.ticketNo,
        invoice.ticketDate = req.body.ticketDate,
        invoice.ticketstatus = req.body.ticketstatus,
        invoice.typeInvoice = req.body.typeInvoice,
        invoice.serviceFee = req.body.serviceFee,
        invoice.invoiceNumber = req.body.invoiceNumber,
        invoice.invoiceDate = req.body.invoiceDate,
        invoice.invoiceStatus = req.body.invoiceStatus,
        invoice.alreadyInvoice = req.body.alreadyInvoice,
        invoice.professionalFee = req.body.professionalFee,
        invoice.gstAmount = req.body.gstAmount,
        invoice.reimExp = req.body.reimExp,
        invoice.uploadInvoice = req.body.uploadInvoice,
        invoice.reinDocument = req.body.reinDocument,
        invoice.totalAmount = req.body.totalAmount,
        invoice.balanceAmount = req.body.balanceAmount,
        invoice.remarks = req.body.remarks,
        invoice.serviceId = req.body.serviceId;
        const a1 = await invoice.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.createserviceDetails = async(req,res) => {
    try{
        const invoice = await InvoiceUpload.find({serviceId: req.params.id }).populate("serviceId")
            .populate({
                path: "serviceId",
                populate: [
                    {
                        path: "serviceMasterId",
                        model: "serviceMasterNew"
                    },
                    {
                        path: "financialYearId",
                        model: "Option"
                    },
                    {
                        path: "customerId",
                        model: "authFrontend"
                    },
                    {
                        path: "assignedTo",
                        model: "Registeration"
                    },
                    {
                        path: "allMilestoneData",
                        populate: [
                            {
                                path: "milestoneId",
                                model: "serviceMilestoneNew"
                            },
                            {
                                path: "groupHead",
                                model: "Option"
                            },
                            {
                                path: "calenderId",
                                model: "Calendar"
                            },
                        ]
                    },
                ]
            });
        res.status(200).json(invoice);
    }catch(err){
        res.status(400).send("Error " + err);
    }
};

// exports.createinvoiceCheck = async(req,res) => {
//     try{
//         const invoice = await InvoiceUpload.findById(req.params.id);
//         const templatecheck = invoice.alreadyInvoice;
//         console.log("^^^", templatecheck);
//         // const invoices = await InvoiceUpload.findById(req.params.id);
//         // const templatechecks = invoices.alreadyInvoice;
//         // console.log("^^^", templatechecks);
//         // const add = templatecheck + templatechecks;
//         // res.status(200).json(add);
//         res.status(200).json(templatecheck);
//     }catch(err){
//         res.status(400).send("Error " + err);
//     }
// };
