const express = require("express");
const router = express.Router();
const eventsValidation = require("./validation");
const { validateParams } = require("../../middlewares");
const eventsService = require("./service");

router.post(
    "/event",
    validateParams(eventsValidation.create),
    eventsService.create
);

router.get(
    "/events",
    eventsService.get
);


router.get(
    "/event/:id",
    eventsService.getbyId
);

router.delete(
    "/event/:id",
    eventsService.delete
);

router.patch(
    "/event/:id",
    validateParams(eventsValidation.update),
    eventsService.update
);

module.exports = router;
