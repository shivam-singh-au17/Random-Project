const { Events,ServiceCategories } = require("../../models");
const { generateReadSignedURL } = require("../../utils/minio");

exports.create = async(req,res) => {
    const event = new Events({
        event_date: req.body.event_date,
        event_heading: req.body.event_heading,
        event_description: req.body.event_description,
        service_category: req.body.service_category,
        event_image_banner: req.body.event_image_banner,
        show_on_homepage: req.body.show_on_homepage,
        status: req.body.status,
    });

    try{
        const a1 =  await event.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.get = async (req,res) => {
    try{
        let event = Events.find();
        if (!isNaN(parseInt(req.query.skip)))
            event = event.skip(parseInt(req.query.skip));
        if (!isNaN(parseInt(req.query.limit)))
            event = event.limit(parseInt(req.query.limit));
        let events = await event;
        events = await Promise.all(events.map(
            async i => {
                let readURL;
                try {
                    readURL = await generateReadSignedURL(i.event_image_banner);
                } catch {
                    readURL = { url: undefined };
                }
                return { ...i._doc, event_image_banner: readURL};
            }));
        res.json(events);
    }catch(err){
        res.send("Error " + err);
    }
};

exports.getbyId = async(req,res) => {
    try{
        const event = await Events.findById(req.params.id);
        const serviceCheck = await ServiceCategories.findById(event.service_category);
        let readURL;
        try {
            readURL = await generateReadSignedURL(event.event_image_banner);
        } catch {
            readURL = { url: undefined };
        }
        res.json({...event._doc, event_image_banner: readURL, service_category:serviceCheck});
    }catch(err){
        res.send("Error " + err);
    }
};

exports.delete = async(req,res)=> {
    try{
        const event = await Events.findById(req.params.id);
        const a1 = await event.remove();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};

exports.update = async(req,res)=> {
    try{
        const event = await Events.findById(req.params.id);
        event.event_date = req.body.event_date,
        event.event_heading = req.body.event_heading,
        event.event_description = req.body.event_description,
        event.service_category = req.body.service_category,
        event.event_image_banner = req.body.event_image_banner,
        event.show_on_homepage = req.body.show_on_homepage,
        event.status = req.body.status;
        const a1 = await event.save();
        res.json(a1);
    }catch(err){
        res.send("Error " + err);
    }

};
