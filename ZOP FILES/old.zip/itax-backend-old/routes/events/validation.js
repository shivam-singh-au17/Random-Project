const Joi = require("joi");

module.exports = {
    create: Joi.object({
        event_date: Joi.string().required(),
        event_heading: Joi.string().required(),
        event_description: Joi.string().required(),
        service_category: Joi.string().required(),
        event_image_banner: Joi.string(),
        show_on_homepage: Joi.boolean().required(),
        status: Joi.boolean()
    }),
    update: Joi.object({
        event_date: Joi.string().required(),
        event_heading: Joi.string().required(),
        event_description: Joi.string().required(),
        service_category: Joi.string().required(),
        event_image_banner: Joi.string(),
        show_on_homepage: Joi.boolean().required(),
        status: Joi.boolean()
    }),
};
