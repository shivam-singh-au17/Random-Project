module.exports = {
    MONGODB_URL: "mongodb://127.0.0.1:27017/itax",
    PORT: 3000,
    MINIO: {
        endPoint: "localhost",
        port: 9000,
        useSSL: false,
        accessKey: "minioadmin",
        secretKey: "minioadmin",
        bucketName: "itax",
    },
    JWT_SECRET_KEY: "authLayerauthLayerauthLayerauthLayer",
    GOOGLE_CLIENT_ID: "319991899435-dahdsfavggh5mbtu40qdpt3o3bgmgnsm.apps.googleusercontent.com",
    GOOGLE_CLIENT_SECRET: "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",
    GOOGLE_CALLBACK_URL: "http://localhost:3333/auth/google/callback",
};
