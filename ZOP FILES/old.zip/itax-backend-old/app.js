var express = require("express");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
const mongoose = require("mongoose");
const swaggerUi = require("swagger-ui-express");
const YAML = require("yamljs");
const cors = require("cors");
const config = require("./config");

var routers = require("./routes/");

var app = express();
app.set("etag", false);
mongoose.connect(
    config.MONGODB_URL,
    { useNewUrlParser: true, useUnifiedTopology: true }
);
const con = mongoose.connection;

con.on("open", () => {
    console.log("connected...");
});


app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());

app.use(
    "/docs",
    swaggerUi.serve,
    swaggerUi.setup(YAML.load(__dirname + "/api-docs.yml"))
);
app.use("/", routers.caselaw);
app.use("/", routers.options);
app.use("/", routers.uploads);
app.use("/", routers.milestoneMaster);
app.use("/", routers.serviceCategory);
app.use("/", routers.serviceMaster);
app.use("/", routers.contact);
app.use("/", routers.subscribe);
app.use("/", routers.partner);
app.use("/", routers.career);
app.use("/", routers.service);
app.use("/", routers.aboutUs);
app.use("/", routers.banners);
app.use("/", routers.cmsCareer);
app.use("/", routers.clientTestimonials);
app.use("/", routers.contactMgmt);
app.use("/", routers.partnerWithUs);
app.use("/", routers.placeholder);
app.use("/", routers.privacyPolicy);
app.use("/", routers.termsAndConditions);
app.use("/", routers.newsLetter);
app.use("/", routers.authLayer);
app.use("/", routers.events);
app.use("/", routers.downloadForms);
app.use("/", routers.FAQ);
app.use("/", routers.featuredVideos);
app.use("/", routers.blogs);
app.use("/", routers.calendar);
app.use("/", routers.newUser);
app.use("/", routers.category);
app.use("/", routers.module);
app.use("/", routers.roles);
app.use("/", routers.businessReferral);
app.use("/", routers.customerMgmt);
app.use("/", routers.customerReferral);
app.use("/", routers.discountCoupon);
app.use("/", routers.stateMaster);
app.use("/", routers.taxMaster);
app.use("/", routers.taxGroup);
app.use("/", routers.authFrontend);
app.use("/", routers.serviceProvider);
app.use("/", routers.ourTeamAndCarrer);
app.use("/", routers.ourTeamAbout);
app.use("/", routers.teamCategory);
app.use("/", routers.bundleService);
app.use("/", routers.registration);
app.use("/", routers.serviceTransaction);
app.use("/", routers.businessPartnerFee);
app.use("/", routers.serviceMasterNew);
app.use("/", routers.serviceMilestoneNew);
app.use("/", routers.documentRequiredNew);
app.use("/", routers.addTemplateNew);
app.use("/", routers.mainServiceCategory);
app.use("/", routers.serviceTransactionNew);
app.use("/", routers.invoiceUpload);
app.use("/api/password-reset", routers.passwordReset);
app.use("/", routers.certificateName);
app.use("/", routers.caseLawService);
app.use("/", routers.newMeeting);
app.use("/", routers.incentiveProgram);
app.use("/", routers.calendarEvents);

module.exports = app;
