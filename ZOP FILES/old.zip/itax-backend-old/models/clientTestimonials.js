const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let clientTestimonialsSchema = new Schema(
    {
        name: { type: String, required: true },
        date: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        shortDescription: { type: String, required: true },
        fullDescription: { type: String, required: true },
        image: { type: String, required: true }
    },
    { timestamps: true }
);


let ClientTestimonials = mongoose.model("clientTestimonials", clientTestimonialsSchema);

module.exports = { ClientTestimonials };
