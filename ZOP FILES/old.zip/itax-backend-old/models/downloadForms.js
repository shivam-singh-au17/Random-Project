const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let downloadFormsSchema = new Schema(
    {
        serviceCategory: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceCategories", required: true },
        formName: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        decription: { type: String, required: true },
        docDocument: { type: String, required: true },
        pdfDocument: { type: String, required: true },
        excelDocument: { type: String, required: true },
    },
    { timestamps: true }
);


let DownloadForms = mongoose.model("downloadForms", downloadFormsSchema);

module.exports = { DownloadForms };
