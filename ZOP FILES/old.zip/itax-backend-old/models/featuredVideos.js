const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let featuredVideosSchema = new Schema(
    {
        videoHeading: { type: String, required: true },
        videoURL: { type: String, required: true },
        decription: { type: String, required: true },
        isFeatured: { type: String, required: true, default: "Yes" },
        status: { type: Boolean, required: true, default: true },
    },
    { timestamps: true }
);


let FeaturedVideos = mongoose.model("featuredVideos", featuredVideosSchema);

module.exports = { FeaturedVideos };
