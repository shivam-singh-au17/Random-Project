
const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let teamCategorySchema = new Schema(
    {
        category: { type: String, required: true },
    },
    { timestamps: true }
);


let TeamCategory = mongoose.model("teamCategory", teamCategorySchema);

module.exports = { TeamCategory };
