const mongoose = require("mongoose");
const moment = require("moment-timezone");
let Schema = mongoose.Schema;




let serviceTransactionNewSchema = new Schema(
    {
        serviceTicketNo: { type: String },
        serviceRequestNo: { type: String },
        serviceMasterId: { type: mongoose.Schema.Types.ObjectId, ref: "serviceMasterNew" },
        briefDiscussion: { type: String },
        financialYearId: { type: mongoose.Schema.Types.ObjectId, ref: "Option" },
        customerId: { type: mongoose.Schema.Types.ObjectId, ref: "authFrontend" },
        typeNew: { type: Boolean, default: true },
        typeApproved: { type: Boolean, default: false },
        typeReject: { type: Boolean, default: false },
        statusType: { type: String },
        completedStatus: { type: String },
        documents: [{
            documentName: { type: String },
            path: { type: String },
            otherDocument: { type: String },
            deleteType: { type: Boolean },
            uploadDate: { type: String, default: moment().format("DD/MM/YYYY") },
            uploadTime: { type: String, default: moment().tz("Asia/Kolkata").format("h:mm:ss A") },
        }],
        allMilestoneData: [],
        serviceAmount: { type: Number },
        paymentAmount: { type: Number },
        isCustomized: { type: Boolean, default: false },
        assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "Registeration" },
        assignedToComments: { type: String },
        serviceStatus: { type: Boolean, default: false },
        ticketDate: { type: String },
        statuoryPayments: [],
        addTemplateArr: [],
        providerUploadDocuments: [
            {
                documentName: { type: String },
                uploadDocument: { type: String },
                uploadDate: { type: String },
            }
        ],
        providerNotes: [{
            customerComment: { type: String },
            providerComment: { type: String },
            customerDateTime: { type: String },
            providerDateTime: { type: String },
        }],
        customerNotes: [{
            customerComment: { type: String },
            providerComment: { type: String },
            customerDateTime: { type: String },
            providerDateTime: { type: String },
        }],
        adminComment: [{
            adminComment: { type: String },
            customerComment: { type: String },
            adminDateTime: { type: String },
            customerDateTime: { type: String },
        }],
        customerComment: [{
            customerComment: { type: String },
            adminComment: { type: String },
            customerDateTime: { type: String },
            adminDateTime: { type: String },
        }],
        adminProviderComment: [{
            adminComment: { type: String },
            providerComment: { type: String },
            adminDateTime: { type: String },
            providerDateTime: { type: String },
        }],
        providerAdminComment: [{
            providerComment: { type: String },
            adminComment: { type: String },
            providerDateTime: { type: String },
            adminDateTime: { type: String },
        }],
        userMonthChoice: { type: Number },
        customerAccepectStatus: { type: Boolean },
        customerRejectRegion: { type: String },
        oneServiseCategory: { type: mongoose.Schema.Types.ObjectId, ref: "mainServiceCategory" },
        customizeFlag: { type: Boolean },
        isBundleServiceTrxn: { type: Boolean, default: false },
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let serviceTransactionNewCountSchema = new Schema(
    {
        serviceTicketNoCount: { type: String, required: true }
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let serviceTrxnForTicketCountSchema = new Schema(
    {
        serviceTicketNo: { type: String, required: true }
    },
    {
        timestamps: true,
        versionKey: false
    }
);



let ServiceTransactionNew = mongoose.model("serviceTransactionNew", serviceTransactionNewSchema);
let ServiceTransactionNewCount = mongoose.model("serviceTransactionNewCount", serviceTransactionNewCountSchema);
let ServiceTrxnForTicketCount = mongoose.model("serviceTrxnForTicketCountSchema", serviceTrxnForTicketCountSchema);


module.exports = { ServiceTransactionNew, ServiceTransactionNewCount, ServiceTrxnForTicketCount };


