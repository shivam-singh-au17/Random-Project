const mongoose = require("mongoose");

const CustomerMgmt = new mongoose.Schema({
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: "authFrontend", required: true },
    emailId: {
        type: String,
        required: true,
    },
    companyName: {
        type: String,
    },
    address1: {
        type: String,
        required: true,
    },
    address2: {
        type: String,
    },
    country: {
        type: String,
        required: true,
    },
    overseas: {
        type: String,
    },
    locality: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true,
    },
    city: {
        type: String,
        required: true,
    },
    approvalStatus: {
        type: Boolean,
        default: false,
    },
    profileType: {
        type: String,
    },
    signInAuthority: {
        type: String,
    },
    mobile: {
        type: String,
        required: true,
    },
    pinCode: {
        type: String,
        required: true,
    },
    uploadPhoto: {
        type: String,
    },
    documents: [{
        adharCardNo: { type: String },
        adharCardFileUpload: { type: String },
        panCardNo: { type: String },
        panCardFileUpload: { type: String },
        companyRegistrationNo: { type: String },
        companyRegistrationFileUpload: { type: String },
        gstRegistration : { type: String },
        gstRegistrationFileUpload: { type: String },
        GSTRegistrationtType: { type: String },
    }],
});

module.exports = mongoose.model("CustomerMgmt", CustomerMgmt);
