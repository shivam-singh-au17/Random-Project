const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let taxMasterSchema = new Schema(
    {
        taxName: { type: String, required: true },
        taxPerc: { type: Number, required: true },
    },
    { timestamps: true }
);

let TaxMaster = mongoose.model("taxMaster", taxMasterSchema);

module.exports = { TaxMaster };
