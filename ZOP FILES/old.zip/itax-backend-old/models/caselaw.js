const mongoose = require("mongoose");


const CaseLaws = new mongoose.Schema({

    act: {
        type: String,
        required: true
    },
    caseNumber: {
        type: String,
        required: true
    },
    section: {
        type: String,
        required: true,
    },
    dateOfOrder: {
        type: String,
        required: true
    },
    caseName: {
        type: String,
        required: true
    },
    yearOfCreation: {
        type: String,
    },
    sub_caseName: {
        type: String,
        required: true
    },
    inFavourOf: {
        type: String,
        required: true
    },
    appealFilingDate: {
        type: String
    },
    keyword: {
        type: String,
        required: true
    },
    citation: {
        type: String
    },
    courtName: {
        type: String,
        required: true
    },
    headNote: {
        type: String,
        required: true
    },
    decisionJudgement: {
        type: String,
        required: true
    },
    status: {
        type: Boolean,
        required: true,
        default: false
    },
    otherCitation: {
        type: String
    },
    judgeName: {
        type: String,
        required: true
    },
    appearedForPetitioner: {
        type: String,
        required: true
    },
    appearedForRespondent: {
        type: String,
        required: true
    },
    uploadDecisionFile: {
        type: String
    },
    generatedPdf: {
        type: String,
    },
    isDeleted:{
        type: Boolean,
        default: false
    }

});

CaseLaws.index({
    act: "text", caseNumber: "text", section: "text", dateOfOrder: "text",
    yearOfCreation: "text",caseName: "text",sub_caseName: "text",status: "text",headNote: "text",
    inFavourOf: "text",appealFilingDate: "text",keyword: "text",judgeName: "text",decisionJudgement: "text",
    courtName: "text",citation: "text",otherCitation: "text",appearedForPetitioner: "text",appearedForRespondent: "text"
},{ name: "all_text"});


module.exports = mongoose.model("CaseLaws",CaseLaws);
