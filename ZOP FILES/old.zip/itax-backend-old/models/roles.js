const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let rolesSchema = new Schema(
    {
        roleName: { type: String, required: true },
        permissions: [{
            moduleId: { type: mongoose.Schema.Types.ObjectId, ref: "module", required: true },
            list: { type: Boolean, required: true, default: false },
            create: { type: Boolean, required: true, default: false },
            view: { type: Boolean, required: true, default: false },
            edit: { type: Boolean, required: true, default: false },
            delete: { type: Boolean, required: true, default: false },
            status: { type: Boolean, required: true, default: false },
        }],
    },
    { timestamps: true }
);


let Roles = mongoose.model("roles", rolesSchema);

module.exports = { Roles };

