const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let taxGroupSchema = new Schema(
    {
        taxGroupName: { type: String, required: true },
        taxGroup: [{ type: mongoose.Schema.Types.ObjectId, ref: "taxMaster", required: true }],
    },
    { timestamps: true }
);


let TaxGroup = mongoose.model("taxGroup", taxGroupSchema);

module.exports = { TaxGroup };
