const mongoose = require("mongoose");


const BundleService = new mongoose.Schema({

    bundleName: {
        type: String,
        required: true
    },
    serviceGroup: [{ type: mongoose.Schema.Types.ObjectId, ref: "ServiceMaster" }],
    totalPrice: {
        type: Number,
        required: true,
    },
    discount_Perce_flat: {
        type: String,
        required: true,
    },
    discountValue: {
        type: Number,
        required: true,
    },
    discountAmount: {
        type: Number,
        required: true,
    },
    createdBy: {
        type: String,
        default: "Admin",
        required: true,
    },
});

module.exports = mongoose.model("BundleService",BundleService);
