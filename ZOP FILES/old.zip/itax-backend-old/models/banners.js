const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let bannerSchema = new Schema(
    {
        heading: { type: String, required: true },
        fileInput: { type: String, required: true },
        decription: { type: String, required: true },
        startDate: { type: String, required: true },
        endDate: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        sequenceNo: { type: Number, required: true },
    },
    { timestamps: true }
);


let Banner = mongoose.model("banner", bannerSchema);

module.exports = { Banner };
