const mongoose = require("mongoose");

const BusinessReferral = new mongoose.Schema({
    referralHeading: {
        type: String,
        required: true,
    },
    selectBusinessPartner: {
        type: String,
        required: true,
    },
    validFrom: {
        type: String,
        required: true,
    },
    validTo: {
        type: String,
        required: true,
    },
    status: {
        type: Boolean,
        required: true,
    },
    referralIncentive: {
        type: String,
        required: true,
    },
    referralAmount: {
        type: String,
        required: true,
    },
    customerDiscount: {
        type: String,
        required: true,
    },
    customerAmount: {
        type: String,
        required: true,
    },
    remarks: {
        type: String,
        required: true,
    },
});

module.exports = mongoose.model("BusinessReferral", BusinessReferral);
