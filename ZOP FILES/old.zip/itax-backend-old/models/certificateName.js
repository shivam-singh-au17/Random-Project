const mongoose = require("mongoose");


const CertificateName = new mongoose.Schema({

    certificateName: {
        type: String,
        required: true,
    }
});

module.exports = mongoose.model("CertificateName",CertificateName);
