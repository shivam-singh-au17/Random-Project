const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let contactMgmtContactSchema = new Schema(
    {
        companyName: { type: String, required: true },
        headerPhone: { type: String, required: true },
        headerEmail: { type: String, required: true },
        contactPhone: { type: String, required: true },
        contactEmail: { type: String, required: true },
        companyLogo: { type: String, required: true },
        webSiteURL: { type: String, required: true },
        address: { type: String, required: true },
    },
    { timestamps: true }
);

let contactMgmtSocialSchema = new Schema(
    {
        facebook: { type: String, required: true },
        twitter: { type: String, required: true },
        youTube: { type: String, required: true },
        googlePlus: { type: String, required: true },
        linkedin: { type: String, required: true },
        RSS: { type: String, required: true },
    },
    { timestamps: true }
);


let ContactMgmtContact = mongoose.model("contactMgmtContact", contactMgmtContactSchema);
let ContactMgmtSocial = mongoose.model("contactMgmtSocial", contactMgmtSocialSchema);

module.exports = { ContactMgmtContact, ContactMgmtSocial };



