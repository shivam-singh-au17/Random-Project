const mongoose = require("mongoose");
let Schema = mongoose.Schema;

const mainServiceCategorySchema = new Schema(
    {
        serviceCategory: { type: String, required: true, },
        description: { type: String, required: true, },
        image: { type: String },
        showonHomePage: { type: Boolean, required: true, default: false, },
        status: { type: Boolean, required: true, default: false, },
        subServiceCategorysId: [{ type: mongoose.Schema.Types.ObjectId, ref: "serviceMasterNew" }]
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let serviceMasterNewSchema = new Schema(
    {
        serviceCategoryId: [{ type: mongoose.Schema.Types.ObjectId, ref: "mainServiceCategory" }],
        serviceModel: { type: String },
        serviceName: { type: String },
        fullPaymentDiscount: { type: Number },
        businessPartnerFee: { type: Number },
        customerServiceFee: { type: Number },
        customerFee: { type: Number },
        GSTApplicableInter: { type: mongoose.Schema.Types.ObjectId, ref: "taxGroup" },
        GSTApplicableIntra: { type: mongoose.Schema.Types.ObjectId, ref: "taxGroup" },
        GSTApplicableInterUt: { type: mongoose.Schema.Types.ObjectId, ref: "taxGroup" },
        TDSApplicable: { type: mongoose.Schema.Types.ObjectId, ref: "taxGroup" },
        showOnHomePage: { type: Boolean },
        status: { type: Boolean },
        description: { type: String },
        image: { type: String },
        advanceAmount: { type: Number },
        serviceMilestone: [{ type: mongoose.Schema.Types.ObjectId, ref: "serviceMilestoneNew" }],
        documentRequired: [{ type: mongoose.Schema.Types.ObjectId, ref: "documentRequiredNew" }],
        addTemplate: [{ type: mongoose.Schema.Types.ObjectId, ref: "addTemplateNew" }],
        relatedServices: [{ type: mongoose.Schema.Types.ObjectId, ref: "serviceMasterNew" }],
        serviceTransactionId: { type: mongoose.Schema.Types.ObjectId, ref: "serviceTransactionNew" },
        serviceTransactionRequestNo: { type: String },
        bundleServiceArr: { type: Array },
        isBundleServiceMgmt: { type: Boolean, default: false },

    },
    {
        timestamps: true,
        versionKey: false
    }
);


let serviceMilestoneNewSchema = new Schema(
    {
        milestoneMasterId: { type: mongoose.Schema.Types.ObjectId, ref: "MilestoneMaster", required: true },
        period: { type: String, required: true },
        groupHead: { type: mongoose.Schema.Types.ObjectId, ref: "Option" },
        milestoneStatus: { type: Boolean, required: true },
        milestoneFee: { type: Number, required: true },
        paymentPercentage: { type: Number, required: true },
        amount: { type: Number, required: true },
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let documentRequiredSchema = new Schema(
    {
        documentType: { type: String, required: true },
        mandatory: { type: Boolean, required: true },
        onHomePage: { type: Boolean, required: true },
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let addTemplateSchema = new Schema(
    {
        templateName: { type: String, required: true },
        templateFile: { type: String, required: true },
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let MainServiceCategory = mongoose.model("mainServiceCategory", mainServiceCategorySchema);


let ServiceMasterNew = mongoose.model("serviceMasterNew", serviceMasterNewSchema);
let ServiceMilestoneNew = mongoose.model("serviceMilestoneNew", serviceMilestoneNewSchema);
let DocumentRequiredNew = mongoose.model("documentRequiredNew", documentRequiredSchema);
let AddTemplateNew = mongoose.model("addTemplateNew", addTemplateSchema);

module.exports = { MainServiceCategory, ServiceMasterNew, ServiceMilestoneNew, DocumentRequiredNew, AddTemplateNew };
