const mongoose = require("mongoose");


const InvoiceUpload = new mongoose.Schema({

    serviceRequestNo: {
        type: String,
        required: true,
    },
    ticketNo: {
        type: String,
        required: true,
    },
    ticketDate: {
        type: String,
        required: true,
    },
    ticketstatus: {
        type: Boolean,
        default: true,
        required: true,
    },
    typeInvoice: {
        type: String,
        required: true,
    },
    serviceFee: {
        type: Number,
        required: true,
    },
    invoiceNumber: {
        type: String,
        required: true,
    },
    invoiceDate: {
        type: String,
        required: true,
    },
    invoiceStatus: {
        type: String,
        required: true,
    },
    alreadyInvoice: {
        type: Number,
        required: true,
    },
    professionalFee: {
        type: Number,
        required: true,
    },
    gstAmount: {
        type: Number,
        required: true,
    },
    reimExp: {
        type: Number,
        required: true,
    },
    uploadInvoice: {
        type: String,
        required: true,
    },
    reinDocument: {
        type: String,
        required: true,
    },
    totalAmount: {
        type: Number,
        required: true,
    },
    balanceAmount: {
        type: Number,
        required: true,
    },
    remarks: {
        type: String,
    },
    serviceId: { type: mongoose.Schema.Types.ObjectId, ref: "serviceTransactionNew",required: true, },
});

module.exports = mongoose.model("InvoiceUpload",InvoiceUpload);
