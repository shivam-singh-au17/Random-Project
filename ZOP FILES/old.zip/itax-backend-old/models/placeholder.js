const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let placeholderSchema = new Schema(
    {
        screenName: { type: String, required: true },
        header: { type: String, required: true },
        description: { type: String, required: true },
        image: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
    },
    { timestamps: true }
);


let Placeholder = mongoose.model("placeholder", placeholderSchema);

module.exports = { Placeholder };

