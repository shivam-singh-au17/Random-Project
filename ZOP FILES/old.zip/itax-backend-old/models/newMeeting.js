const mongoose = require("mongoose");

const NewMeeting = new mongoose.Schema({

    dateOfMeeting: {
        type: String,
        required: true
    },
    selectTime: {
        type: String,
        required: true
    },
    duration: {
        type: String,
    },
    meetingWith: {
        type: String,
        required: true,
    },
    nameOfUser: {
        type: String,
        required: true
    },
    serviceTicketNo: { type: mongoose.Schema.Types.ObjectId, ref: "serviceTransactionNew", require: true },
    meetingStatus: {
        type: String,
        required: true
    },
    nameOfService: {
        type: String,
        required: true
    },
    serviceName: {
        type: String,
        required: true
    },
    agendaOfMeeting: {
        type: String,
    },
    meeting_link:{
        type: String,
        required: true
    },
    meetTime:{
        type: String,
    },
    comments:{
        type: String,
    },
    status:{
        type: Boolean,
        default: false
    },
});

module.exports = mongoose.model("NewMeeting",NewMeeting);
