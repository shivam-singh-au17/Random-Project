const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let privacyPolicySchema = new Schema(
    {
        memo: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        content: { type: String, required: true },
    },
    { timestamps: true }
);


let PrivacyPolicy = mongoose.model("privacyPolicy", privacyPolicySchema);

module.exports = { PrivacyPolicy };

