const mongoose = require("mongoose");


const Calendar = new mongoose.Schema({

    calender_heading: {
        type: String,
        required: true
    },
    under_which_law: {
        type: String,
        required: true,
    },
    form_name_no: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true
    },
    schedule_date: {
        type: String,
        required: true
    },
    status: {
        type: Boolean,
        required: true,
        default: false
    },
    milestone: { type: mongoose.Schema.Types.ObjectId, ref: "MilestoneMaster" },
    milestone_filing: {
        type: String,
        required: true
    },
    store_year: {
        type: String,
        required: true
    },

});

module.exports = mongoose.model("Calendar",Calendar);
