const mongoose = require("mongoose");

const MilestoneMaster = new mongoose.Schema({
    milestoneName: {
        type: String,
        required: true,
    },
    milestoneFrequency: {
        type: String,
        required: true,
    },
    billable: {
        type: Boolean,
        required: true,
        default: false,
    },
    filing: {
        type: Boolean,
        required: true,
        default: false,
    },
    status: {
        type: Boolean,
        required: true,
        default: false,
    },
    isAdvancePayment: {
        type: Boolean,
        required: true,
        default: false,
    }
});

module.exports = mongoose.model("MilestoneMaster", MilestoneMaster);
