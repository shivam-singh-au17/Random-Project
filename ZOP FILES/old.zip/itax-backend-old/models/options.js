const mongoose = require("mongoose");

const Option = new mongoose.Schema({
    option: {
        type: String,
        required: true,
    },
    label: {
        type: String,
        required: true,
    },
    value: {
        type: String,
        required: true,
    },
    enabled: {
        type: Boolean,
        required: true,
    },
    default: {
        type: Boolean,
        required: true,
        default: false,
    }
});

module.exports = mongoose.model("Option", Option);
