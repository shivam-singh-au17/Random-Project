const mongoose = require("mongoose");


const CaseLawService = new mongoose.Schema({

    serviceId: { type: mongoose.Schema.Types.ObjectId, ref: "CaseLaws" },
    providerId: { type: mongoose.Schema.Types.ObjectId, ref: "Registeration" },
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: "CustomerMgmt" },
    remarks: {
        type: String,
    }
});

module.exports = mongoose.model("CaseLawService",CaseLawService);
