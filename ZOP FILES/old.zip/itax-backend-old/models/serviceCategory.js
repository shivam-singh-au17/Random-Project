const mongoose = require("mongoose");

const ServiceCategories = new mongoose.Schema({
    serviceCategory: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    image: {
        type: String
    },
    showonHomePage: {
        type: Boolean,
        required: true,
        default: false,
    },
    status: {
        type: Boolean,
        required: true,
        default: false,
    }
});

module.exports = mongoose.model("ServiceCategories ", ServiceCategories);
