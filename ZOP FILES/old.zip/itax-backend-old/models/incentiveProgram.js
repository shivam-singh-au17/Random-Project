const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let incentiveProgramSchema = new Schema(
    {
        serviceProviderId: { type: mongoose.Schema.Types.ObjectId, ref: "Registeration", required: true },
        clientName: { type: String, required: true },
        clientEmail: { type: String, required: true },
        periodFrom: { type: String, required: true },
        periodTo: { type: String, required: true },
        providerShere: { type: Number, required: true },
        customerShere: { type: Number, required: true },
        incentiveCode: { type: String, required: true },
        providerServices: [],
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let IncentiveProgram = mongoose.model("incentiveProgram", incentiveProgramSchema);

module.exports = { IncentiveProgram };
