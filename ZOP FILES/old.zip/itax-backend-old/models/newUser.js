const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let newUserSchema = new Schema(
    {
        firstName: { type: String, required: true },
        lastName: { type: String, required: true },
        email: { type: String, required: true },
        phone: { type: String, required: true },
        password: { type: String, required: true },
        confirmPassword: { type: String, required: true },
        roleId: { type: mongoose.Schema.Types.ObjectId, ref: "roles", required: true  },
        status: { type: Boolean, required: true, default: true },
        photo: { type: String, required: true },
    },
    { timestamps: true }
);


let NewUser = mongoose.model("newUser", newUserSchema);

module.exports = { NewUser };
