const mongoose = require("mongoose");

const ServiceMaster = new mongoose.Schema({
    serviceCategory: [{ type: mongoose.Schema.Types.ObjectId, ref: "ServiceCategories " }],
    serviceModel: {
        type: String,
        required: true,
    },
    imageUpload: {
        type: String,
    },
    serviceName: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    customerServiceFee: {
        type: Number,
        required: true,
    },
    fullPaymentDiscount: {
        type: Number,
        required: true,
    },
    businessPartnerFee: {
        type: Number,
        required: true,
    },
    showOnHomePage: {
        type: Boolean,
        required: true,
        default: false,
    },
    status: {
        type: Boolean,
        required: true,
        default: false,
    },
    tdsApplicable: { type: String },
    GSTapplicableInter: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup" },
    GSTapplicableIntra: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup" },
    GSTapplicableInterut: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup" },
    // gstApplicable: [{
    //     GSTapplicableInter: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup"},
    //     GSTapplicableIntra: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup"},
    //     GSTapplicableInterut: { type: mongoose.Schema.Types.ObjectId, ref: "TaxGroup"},
    // }],
    milestones: [{
        milestone: { type: mongoose.Schema.Types.ObjectId, ref: "MilestoneMaster"},
        period: { type: String },
        groupHead: { type: String },
        paymentMilestoneStatus: { type: Boolean },
        milestoneFees : { type: Number },
        paymentPercentage : { type: Number },
        amount : { type: Number }
    }],
    documents: [{
        document: { type: String },
        mandatory: { type: Boolean },
        showOnHomePage : { type: Boolean }
    }],
    relatedServices: [{ type: mongoose.Schema.Types.ObjectId,ref: "ServiceMaster" }],
    template: [{
        templateName: { type: String },
        fileUpload: { type: String },
    }],
});

module.exports = mongoose.model("ServiceMaster", ServiceMaster);
