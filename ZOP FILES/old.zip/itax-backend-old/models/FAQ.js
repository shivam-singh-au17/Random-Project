const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let FAQSchema = new Schema(
    {
        serviceCategory: { type: String, required: true },
        serviceName: { type: String, required: true },
        questioon: { type: String, required: true },
        answer: { type: String, required: true },
    },
    { timestamps: true }
);


let FAQ = mongoose.model("FAQ", FAQSchema);

module.exports = { FAQ };
