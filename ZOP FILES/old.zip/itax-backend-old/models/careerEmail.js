const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let careerEmailSchema = new Schema(
    {
        position: { type: String, required: true },
        name: { type: String, required: true },
        email: { type: String, required: true },
        mobile: { type: String, required: true },
        qualification: { type: String, required: true },
        location: { type: String, required: true },
        experience: { type: String, required: true },
        userCv: { type: String, required: true },
    },
    { timestamps: true }
);


let CareerEmail = mongoose.model("careerEmail", careerEmailSchema);

module.exports = { CareerEmail };
