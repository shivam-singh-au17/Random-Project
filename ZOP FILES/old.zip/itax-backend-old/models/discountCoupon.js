const mongoose = require("mongoose");

const DiscountCoupon = new mongoose.Schema({
    couponHeading: {
        type: String,
        required: true,
    },
    couponCode: {
        type: String,
        required: true,
    },
    selectCustomer: { type: mongoose.Schema.Types.ObjectId, ref: "CustomerMgmt "},
    selectService: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceCategories"},
    validFrom: {
        type: String,
        required: true,
    },
    validTo: {
        type: String,
        required: true,
    },
    couponDiscount: {
        type: Number,
        required: true,
    },
    amount: {
        type: Number,
        required: true,
    },
    remarks: {
        type: String,
        required: true,
    },
    status: {
        type: Boolean,
        required: true,
    },
});

module.exports = mongoose.model("DiscountCoupon", DiscountCoupon);
