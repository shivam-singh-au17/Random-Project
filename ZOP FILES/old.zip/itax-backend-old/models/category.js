

const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let categorySchema = new Schema(
    {
        category: { type: String, required: true }
    },
    { timestamps: true }
);


let Category = mongoose.model("category", categorySchema);

module.exports = { Category };
