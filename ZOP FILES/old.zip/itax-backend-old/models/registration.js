const mongoose = require("mongoose");

const Registeration = new mongoose.Schema({

    service_provider_id: { type: mongoose.Schema.Types.ObjectId, ref: "authFrontend", required: true },
    approval_status: {
        type: String,
        default: "Submitted",
    },
    email_id: {
        type: String,
        required: true
    },
    profile_type: {
        type: String,
    },
    first_name: {
        type: String,
        required: true
    },
    middle_name: {
        type: String,
    },
    last_name: {
        type: String,
        required: true,
    },
    address_1: {
        type: String,
        required: true
    },
    address_2: {
        type: String,
    },
    mobile: {
        type: Number,
        required: true
    },
    total_year_of_exp: {
        type: Number,
    },
    country: {
        type: String,
        required: true
    },
    overseas: {
        type: String,
    },
    locality: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    working_since: {
        type: String,
    },
    pin_code: {
        type: Number,
        required: true
    },
    facebook_link: {
        type: String,
    },
    twitter_link: {
        type: String,
    },
    linkedin_link: {
        type: String,
    },
    instagram_link: {
        type: String,
    },
    upload_photo: {
        type: String,
    },
    upload_biodata: {
        type: String,
    },
    qualification: [{
        selectQualification: { type: String },
        instituteName : { type: String },
        chooseFile : { type: String },
        otherCertificateName: { type: String },
    }],
    bankDetail: [{
        accountHolderName: { type: String },
        bankName : { type: String },
        branch : { type: String },
        accountNumber : { type: String },
        ifscCode : { type: String },
        upiNumber : { type: String },
        cancelledCheque : { type: String }
    }],
    documents: [{
        adharCardNo: { type: String,required: true },
        adharCardFileUpload: { type: String,required: true },
        panCardNo: { type: String,required: true },
        panCardFileUpload: { type: String,required: true },
        companyRegistrationNo: { type: String },
        companyRegistrationFileUpload: { type: String },
        gstRegistration : { type: String },
        gstRegistrationFileUpload: { type: String },
        GSTRegistrationtType: { type: String },
    }],
    dateRegistration: {
        type: String,
    },
    approvedDate: {
        type: String,
    },
    approvedBy: {
        type: String,
    },
    areaOfExpertise: [{
        serviceId: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceMaster", required: true, },
        yearOfExp: { type: Number },
    }],
    adminProviderComment: [{
        adminComment: { type: String },
        providerComment: { type: String },
        adminDateTime: { type: String },
        providerDateTime: { type: String },
    }],
    providerAdminComment: [{
        providerComment: { type: String },
        adminComment: { type: String },
        providerDateTime: { type: String },
        adminDateTime: { type: String },
    }],
});

Registeration.index({
    service_provider_id: "text", approval_status: "text", email_id: "text", profile_type: "text",
    first_name: "text",middle_name: "text",last_name: "text",address_1: "text",address_2: "text",
    mobile: "text",total_year_of_exp: "text",country: "text",state: "text",city: "text",
    working_since: "text",pin_code: "text",facebook_link: "text",twitter_link: "text",linkedin_link: "text",
    instagram_link: "text"
},{ name: "all_text"});

module.exports = mongoose.model("Registeration",Registeration);
