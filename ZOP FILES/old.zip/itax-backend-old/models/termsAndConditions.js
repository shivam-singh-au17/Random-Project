const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let termsAndConditionsSchema = new Schema(
    {
        memo: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        content: { type: String, required: true },
    },
    { timestamps: true }
);


let TermsAndConditions = mongoose.model("termsAndConditions", termsAndConditionsSchema);

module.exports = { TermsAndConditions };

