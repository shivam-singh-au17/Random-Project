const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let careerSchema = new Schema(
    {
        position: { type: String, required: true },
        location: { type: String, required: true },
        jobDetail: { type: String, required: true },
        status: { type: Boolean, required: true, default: true }
    },
    { timestamps: true }
);


let Career = mongoose.model("career", careerSchema);

module.exports = { Career };
