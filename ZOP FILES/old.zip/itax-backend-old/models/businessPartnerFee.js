const mongoose = require("mongoose");


const BusinessPartnerFee = new mongoose.Schema({

    selectBusinessPartner: { type: mongoose.Schema.Types.ObjectId, ref: "Registeration" },
    description: {
        type: String,
        required: true
    },
    details:[{
        serviceCategory: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceCategories" },
        serviceName: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceMaster" },
        serviceFee: { type: Number,required: true},
        partnerFeePercentage: {type: Number,required: true},
        partnerFee: {type: Number,required: true},
        remarks: {type: String,required: true},
    }],
    createdBy: {type: String},
    updatedBy: {type: String},
}, {timestamps: true });

module.exports = mongoose.model("BusinessPartnerFee",BusinessPartnerFee);
