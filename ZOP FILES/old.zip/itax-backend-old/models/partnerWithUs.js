const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let partnerWithUsSchema = new Schema(
    {
        heading: { type: String, required: true },
        status: { type: Boolean, required: true, default: true },
        content: { type: String, required: true },
    },
    { timestamps: true }
);


let PartnerWithUs = mongoose.model("partnerWithUs", partnerWithUsSchema);

module.exports = { PartnerWithUs };

