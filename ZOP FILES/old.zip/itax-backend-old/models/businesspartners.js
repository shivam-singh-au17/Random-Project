const mongoose = require("mongoose");


const BusinessPartnerFee = new mongoose.Schema({

    select_business_partner: {
        type: String,
        required: true
    }, // select field
    description: {
        type: String,
        required: true,
    },
    service_category: {
        type: String,
        required: true
    },
    service_name: {
        type: String,
        required: true,
    },
    service_fee: {
        type: String,
        required: true
    },
    partner_fee_percentage: {
        type: String,
        required: true,
    },
    partner_fee: {
        type: String,
        required: true,
    },
    remarks: {
        type: String,
        required: true
    }, //id
    created_date: {
        type: Date,
        required: true
    }, //id
    updated_by: {
        type: Date,
        required: true
    },
    last_uploaded: {
        type: Date,
        required: true
    },
    status: {
        type: Boolean,
        required: true,
        default: false
    }
});

module.exports = mongoose.model("BusinessPartnerFee",BusinessPartnerFee);
