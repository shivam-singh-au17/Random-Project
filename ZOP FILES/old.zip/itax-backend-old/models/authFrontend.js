const mongoose = require("mongoose");
const bcrypt = require("bcrypt");



const authFrontendSchema = new mongoose.Schema(
    {
        registerAs: { type: String, required: true },
        firstName: { type: String, required: true },
        middleName: { type: String },
        lastName: { type: String, required: true },
        email: { type: String, required: true, unique: true },
        mobile: { type: String, required: true },
        password: { type: String, required: true },
        confirmPassword: { type: String, required: true },
        accountType: { type: String, required: true, default: "iTaxDirect Login" },
        secretKey: { type: Boolean, required: true, default: false },
        isCustomer: { type: Boolean, required: true, default: false },
        isServiceProvider: { type: Boolean, required: true, default: false },
        otp: { type: String, expires: 3600, default: Date.now },

    },
    {
        versionKey: false,
        timestamps: true
    }

);



authFrontendSchema.pre("save", function (next) {

    if (!this.isModified("password")) {
        return next();
    }

    bcrypt.hash(this.password, 8, (err, hash) => {
        if (err) {
            return next(err);
        }
        this.password = hash;
        next();
    });
});



authFrontendSchema.pre("save", function (next) {

    if (!this.isModified("confirmPassword")) {
        return next();
    }

    bcrypt.hash(this.confirmPassword, 8, (err, hash) => {
        if (err) {
            return next(err);
        }
        this.confirmPassword = hash;
        next();
    });

});



authFrontendSchema.methods.checkPassword = function (password) {
    const passwordHash = this.password;
    return new Promise((resolve, reject) => {
        bcrypt.compare(password, passwordHash, (err, same) => {
            if (err) {
                return reject(err);
            }
            resolve(same);
        });
    });
};



const AuthFrontend = mongoose.model("authFrontend", authFrontendSchema);

module.exports = AuthFrontend;

