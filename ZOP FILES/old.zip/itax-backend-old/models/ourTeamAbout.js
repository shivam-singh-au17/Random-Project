const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let ourTeamAboutSchema = new Schema(
    {
        heading: { type: String, required: true },
        image: { type: String, required: true },
        number: { type: Number, required: true },
        color: { type: String, required: true },
    },
    { timestamps: true }
);


let OurTeamAbout = mongoose.model("ourTeamAbout", ourTeamAboutSchema);

module.exports = { OurTeamAbout };


