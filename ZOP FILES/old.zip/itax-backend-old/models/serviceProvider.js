const mongoose = require("mongoose");

const serviceProviderSchema = new mongoose.Schema(
    {
        registerAs: { type: String, required: true },
        firstName: { type: String, required: true },
        middleName: { type: String },
        lastName: { type: String, required: true },
        email: { type: String, required: true, unique: true },
        mobile: { type: String, required: true },
        password: { type: String, required: true },
        confirmPassword: { type: String, required: true },
        accountType: { type: String, required: true, default: "iTaxDirect Login" },
        secretKey: { type: Boolean, required: true, default: false },

    },
    {
        versionKey: false,
        timestamps: true
    }
);



const ServiceProvider = mongoose.model("serviceProvider", serviceProviderSchema);

module.exports = ServiceProvider;

