const mongoose = require("mongoose");
let Schema = mongoose.Schema;

let stateMasterSchema = new Schema(
    {
        stateName: { type: String, required: true },
        stateCode: { type: String, required: true },
    },
    { timestamps: true }
);


let StateMaster = mongoose.model("stateMaster", stateMasterSchema);

module.exports = { StateMaster };
