
const mongoose = require("mongoose");
let Schema = mongoose.Schema;
const moment = require("moment-timezone");

let calendarEventSchema = new Schema(
    {
        type: { type: String },
        typeId: { type: String },
        eventTitle: { type: String },
        eventDescription: { type: String },
        date: { type: String, default: moment().format("DD/MM/YYYY") },
        time: { type: String, default: moment().tz("Asia/Kolkata").format("h:mm:ss A") },
        initiatedBy: { type: String },
        initiatedFor: { type: String },
        isCompleted: { type: Boolean },
    },
    {
        timestamps: true,
        versionKey: false
    }
);


let CalendarEvents = mongoose.model("calendarEvent", calendarEventSchema);

module.exports = { CalendarEvents };
