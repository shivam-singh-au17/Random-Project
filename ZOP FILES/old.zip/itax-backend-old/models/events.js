const mongoose = require("mongoose");


const Events = new mongoose.Schema({

    event_date: {
        type: String,
        required: true
    },
    event_heading: {
        type: String,
        required: true
    },
    event_description: {
        type: String,
        required: true,
    },
    service_category: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceCategories" },
    event_image_banner: {
        type: String,
    },
    show_on_homepage: {
        type: Boolean,
        required: true
    },
    status: {
        type: Boolean,
        required: true,
        default: false
    }
});

module.exports = mongoose.model("Events",Events);
