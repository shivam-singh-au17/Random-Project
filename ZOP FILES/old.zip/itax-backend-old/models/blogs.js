const mongoose = require("mongoose");


const Blogs = new mongoose.Schema({

    blog_category: {
        type: String,
        required: true
    },
    blog_heading: {
        type: String,
        required: true
    },
    blog_owner: {
        type: String,
        required: true
    },
    short_description: {
        type: String,
        required: true,
    },
    full_description: {
        type: String,
        required: true
    },
    image: {
        type: String,
    },
    approved: {
        type: Boolean,
    },
    user_type: {
        type: String,
    },
    created_on: {
        type: String,
        required: true,
    },
    remark: {
        type: String,
    },
    approval_status: {
        type: String,
    },
    blog_status: {
        type: Boolean,
    },
    approved_by: {
        type: String,
    },
    approved_on: {
        type: String,
    },
    showOnHomePage: {
        type: Boolean,
        default: true,
        require: true,
    },
    published_date: {
        type: String,
    },
    approvar_remark:{
        type: String,
    },
});

module.exports = mongoose.model("Blogs",Blogs);
