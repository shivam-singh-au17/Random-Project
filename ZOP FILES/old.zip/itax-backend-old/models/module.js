const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let moduleSchema = new Schema(
    {
        module: { type: String, required: true },
        categoryId: { type: mongoose.Schema.Types.ObjectId, ref: "category", required: true },
    },
    { timestamps: true }
);


let Module = mongoose.model("module", moduleSchema);

module.exports = { Module };
