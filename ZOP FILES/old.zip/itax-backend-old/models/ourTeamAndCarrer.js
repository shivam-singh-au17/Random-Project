const mongoose = require("mongoose");
let Schema = mongoose.Schema;


let ourTeamAndCarrerSchema = new Schema(
    {
        teamHeading: { type: String, required: true },
        teamContent: { type: String, required: true },
        careerHeading: { type: String, required: true },
        carrerContent: { type: String, required: true },
        imgFile: { type: String, required: true },
    },
    { timestamps: true }
);


let OurTeamAndCarrer = mongoose.model("ourTeamAndCarrer", ourTeamAndCarrerSchema);

module.exports = { OurTeamAndCarrer };


