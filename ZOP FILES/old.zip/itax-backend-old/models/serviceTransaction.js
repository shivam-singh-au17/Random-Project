const mongoose = require("mongoose");

const ServiceTransaction = new mongoose.Schema({

    serviceTicketNo: {
        type: String,
    },
    serviceId: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceMaster", required: true, },
    briedDiscussion: {
        type: String,
    },
    financialYearId: { type: mongoose.Schema.Types.ObjectId, ref: "Option", required: true, },
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: "CustomerMgmt", required: true, },
    typeNew: {
        type: Boolean,
        default: true,
    },
    typeApproved: {
        type: Boolean,
        default: false,
    },
    typeReject: {
        type: Boolean,
        default: false,
    },
    documents: [{
        documentName: { type: String },
        path: { type: String },
    }],
    milestone: [{ type: String }],
    serviceAmount: {
        type: Number,
        required: true,
    },
    paymentAmount: {
        type: Number,
        required: true,
    },
    isCustomized: {
        type: Boolean,
        default: false,
        required: true,
    },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "Registeration" },
    assignedToComments: {
        type: String,
    },
    serviceStatus: {
        type: Boolean,
        default: true,
    },
    ticketDate: {
        type: String,
    },
});

module.exports = mongoose.model("ServiceTransaction", ServiceTransaction);
