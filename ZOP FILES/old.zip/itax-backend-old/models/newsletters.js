const mongoose = require("mongoose");


const NewsLetters = new mongoose.Schema({

    month: {
        type: String,
        required: true
    },
    year: {
        type: String,
        required: true
    },
    letter_heading: {
        type: String,
        required: true,
    },
    sort_description: {
        type: String,
        required: true
    },
    file_upload: {
        type: String,
    },
    status: {
        type: Boolean,
        required: true,
        default: false
    }

});

module.exports = mongoose.model("NewsLetters",NewsLetters);
