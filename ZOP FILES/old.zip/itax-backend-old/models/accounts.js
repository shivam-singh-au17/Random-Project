const mongoose = require("mongoose");


const Accounts = new mongoose.Schema({

    service_request_no: {
        type: String,
        required: true
    }, // id
    ticket_no: {
        type: String,
        required: true
    },// id
    ticket_date: {
        type: Date,
        required: true,
    },
    service_status: {
        type: String,
        required: true
    },
    type_of_invoices: {
        type: String,
        required: true
    },
    service_fee: {
        type: String,
        required: true
    },
    Invoice_number: {
        type: String,
        required: true
    },
    invoice_date: {
        type: Date,
        required: true
    },
    already_invoies: {
        type: String,
        required: true
    },
    professional_fee: {
        type: String,
        required: true
    },
    gst_amount: {
        type: String,
        required: true
    },
    Remb_exp: {
        type: String,
        required: true
    },
    uploaded_reimb_exp: {
        type: String,
        required: true
    },
    amount_payable: {
        type: String,
        required: true
    },
    balance_amount: {
        type: String,
        required: true
    },
    gst_number: {
        type: String,
        required: true
    },
    remarks: {
        type: String,
        required: true
    },
    comments: {
        type: String,
        required: true
    },
    approver_comments: {
        type: String,
        required: true
    },
    payment_mode: {
        type: String,
        required: true
    }, // select field
    payment_date: {
        type: Date,
        required: true
    },
    referrence_no_cheque: {
        type: String,
        required: true
    },
    bank_details: {
        type: String,
        required: true
    },
    payment_remarks: {
        type: String,
        required: true
    },
    invoices: {
        type: String,
        required: true
    },
    service_provider: {
        type: String,
        required: true
    },
    tds_amount: {
        type: String,
        required: true
    },
    payable: {
        type: String,
        required: true
    },
    amount: {
        type: String,
        required: true
    },
    bsr_code: {
        type: String,
        required: true
    },
    payment_details: {
        type: String,
        required: true
    },
    challan_no: {
        type: String,
        required: true
    },
    boolean: {
        type: Boolean,
        required: true,
        default: false
    }

});

module.exports = mongoose.model("Accounts",Accounts);
