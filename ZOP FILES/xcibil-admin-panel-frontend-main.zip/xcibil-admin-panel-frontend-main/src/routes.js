export const RoutesPath = {
  // Private
  Dashboard: { path: "/dashboard" },
  AllUser: { path: "/all-user" },
  AllUserWithPan: { path: "/all-user-with-pan" },
  AllUserWithoutPan: { path: "/all-user-without-pan" },
  AdminMgmt: { path: "/admin-mgmt" },
  RoleMgmt: { path: "/role-mgmt" },
  RoleAuthCtrl: { path: "/role-auth-ctrl" },
  // Public
  Signin: { path: "/sign-in" },
  HomeNavigation: { path: "/" },
  ForgotPassword: { path: "/forgot-password" },
  ResetPassword: { path: "/reset-password" },
};
