import React from "react";
// component
import SvgColor from "../../../components/svg-color";
import { RoutesPath } from "../../../routes";

// ----------------------------------------------------------------------

const icon = (name) => (
  <SvgColor
    src={`/assets/icons/navbar/${name}.svg`}
    sx={{ width: 1, height: 1 }}
  />
);

const pngIcon = (name) => (
  <SvgColor
    src={`/assets/icons/navbar/${name}.png`}
    sx={{ width: 1, height: 1 }}
  />
);

const navConfig = [
  {
    title: "dashboard",
    path: RoutesPath.Dashboard.path,
    icon: icon("ic_analytics"),
  },
  {
    title: "AdminMgmt",
    path: RoutesPath.AdminMgmt.path,
    icon: icon("ic_user"),
  },
  {
    title: "RoleMgmt",
    path: RoutesPath.RoleMgmt.path,
    icon: pngIcon("ic_role"),
  },
  {
    title: "RoleAuthCtrl",
    path: RoutesPath.RoleAuthCtrl.path,
    icon: icon("ic_lock"),
  },
  {
    title: "Reports",
    path: "/dashboard/report",
    icon: pngIcon("ic_report"),
  },
  {
    title: "Transactions",
    path: "/dashboard/transaction",
    icon: pngIcon("ic_transaction"),
  },
];

export default navConfig;
