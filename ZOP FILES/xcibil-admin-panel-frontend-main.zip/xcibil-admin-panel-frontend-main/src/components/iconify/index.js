export { default } from "./Iconify";
