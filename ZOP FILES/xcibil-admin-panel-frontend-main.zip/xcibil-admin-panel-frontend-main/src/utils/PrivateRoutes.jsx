import React from "react";
import { Outlet, Navigate } from "react-router-dom";
import { RoutesPath } from "../routes";

const PrivateRoutes = () => {
  let auth = false;
  const user = JSON.parse(localStorage.getItem("user"));
  if (user) {
    auth = true;
  }
  return auth ? <Outlet /> : <Navigate to={RoutesPath.Signin.path} />;
};

export default PrivateRoutes;
