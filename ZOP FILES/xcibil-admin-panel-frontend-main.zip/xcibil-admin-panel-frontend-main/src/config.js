export const Config = {
  // Backend_URL: "http://localhost:3030/api/v1",
  Backend_URL: "https://api.newpaytm.com/api/v1",
};
