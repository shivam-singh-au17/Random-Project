// ----------------------------------------------------------------------

const account = () => {
  const mainUser = JSON.parse(localStorage.getItem("user"));
  let myObj = {};
  myObj.displayName = mainUser.user.fullName;
  myObj.email = mainUser.user.email;
  myObj.role = "XCIBIL";
  myObj.photoURL = "/assets/images/avatars/avatar_default.webp";
  return myObj;
};

export default account;
