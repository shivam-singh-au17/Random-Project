import React, { createContext } from "react";

const UserInfo = createContext();

const AllUserData = () => {
    return <>
        <UserInfo.Provider>
            
        </UserInfo.Provider>
    </>;
};

export default AllUserData;
