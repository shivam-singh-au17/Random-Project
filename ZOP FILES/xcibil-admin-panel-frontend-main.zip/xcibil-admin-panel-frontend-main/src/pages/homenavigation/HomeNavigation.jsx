import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
// @mui
import { Grid, Container, Typography } from "@mui/material";
// sections
import { AppTasks, AppWidgetSummary } from "../../sections/@dashboard/app";

import { Config } from "../../config";
import axios from "axios";
// Link
import { Link } from "react-router-dom";
import { RoutesPath } from "../../routes";

// ----------------------------------------------------------------------

export default function HomeNavigation() {
  const [allUserNo, setAllUserNo] = useState("");
  const [allUserWithPanNo, setAllUserWithPanNo] = useState("");
  const [allUserWithoutPanNo, setAllUserWithoutPanNo] = useState("");

  useEffect(() => {
    const mainUser = JSON.parse(localStorage.getItem("user"));
    allUserInfo(mainUser.token);
    allUserInfoWithPen(mainUser.token);
    allUserInfoWithoutPen(mainUser.token);
  }, []);

  const allUserInfo = async (token) => {
    try {
      const response = await axios.get(
        `${Config.Backend_URL}/user/allUserInfo`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAllUserNo(response.data.allUserCount);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  const allUserInfoWithPen = async (token) => {
    try {
      const response = await axios.get(
        `${Config.Backend_URL}/user/userInfoWithPan`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAllUserWithPanNo(response.data.allUserWithPanCount);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  const allUserInfoWithoutPen = async (token) => {
    try {
      const response = await axios.get(
        `${Config.Backend_URL}/user/userInfoWithoutPan`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAllUserWithoutPanNo(response.data.allUserWithoutPanCount);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  return (
    <>
      <Helmet>
        <title> Dashboard | XCIBIL </title>
      </Helmet>

      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Hi, Welcome back
        </Typography>

        <Typography variant="h4">User Cards</Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <Link to={RoutesPath.AllUser.path}>
              <AppWidgetSummary
                title="Total Registered Users"
                total={Number(allUserNo)}
                icon={"ri:user-3-fill"}
              />
            </Link>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Link to={RoutesPath.AllUserWithPan.path}>
              <AppWidgetSummary
                title="Total Users With Pan Card"
                total={Number(allUserWithPanNo)}
                color="info"
                icon={"ri:user-follow-fill"}
              />
            </Link>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Link to={RoutesPath.AllUserWithoutPan.path}>
              <AppWidgetSummary
                title="Total Users Without Pan Card"
                total={Number(allUserWithoutPanNo)}
                color="warning"
                icon={"ri:user-unfollow-fill"}
              />
            </Link>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Users Connected With Tally"
              total={234}
              color="error"
              icon={"ri:user-settings-fill"}
            />
          </Grid>
        </Grid>

        <Typography variant="h4" sx={{ mt: 2 }}>
          Transaction Cards
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Transaction Added"
              total={714000}
              icon={"fa6-solid:hand-holding-dollar"}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total New Transaction"
              total={1352831}
              color="info"
              icon={"fa6-solid:circle-dollar-to-slot"}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Old Transaction"
              total={1723315}
              color="warning"
              icon={"fa-solid:file-invoice-dollar"}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Old Defaulted Transaction"
              total={234}
              color="error"
              icon={"fa-solid:funnel-dollar"}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Defaulted Transaction"
              total={714000}
              icon={"fa6-solid:money-check-dollar"}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary
              title="Total Settled Transaction"
              total={1352831}
              color="info"
              icon={"fa6-solid:sack-dollar"}
            />
          </Grid>

          <Grid item xs={12} md={12} lg={12} sx={{ mb: 5 }}>
            <AppTasks
              title="Tasks"
              list={[
                { id: "1", label: "Create a user for the Payment section" },
                {
                  id: "2",
                  label: "Solve user problem of PAN number ASDCF3456A",
                },
                { id: "3", label: "Assign the role of TESTER to Mohan Singh" },
                { id: "4", label: "View transaction details for this month" },
                {
                  id: "5",
                  label:
                    "You can use this section for your day to day activities",
                },
              ]}
            />
          </Grid>
        </Grid>
      </Container>
    </>
  );
}
