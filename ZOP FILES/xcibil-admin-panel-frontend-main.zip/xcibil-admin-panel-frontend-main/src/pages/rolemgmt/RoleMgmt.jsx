import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { filter } from "lodash";
// @mui
import {
  Card,
  Table,
  Stack,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  Alert,
  TablePagination,
  Snackbar,
  Box,
  TextField,
  Button,
  IconButton,
  Popover,
  MenuItem,
} from "@mui/material";

// sections
import { UserListHead } from "../../sections/@dashboard/user";
import axios from "axios";
import { Config } from "../../config";
import { useNavigate } from "react-router-dom";
import { RoutesPath } from "../../routes";
import Iconify from "../../components/iconify";
import Scrollbar from "../../components/scrollbar";
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: "sn", label: "S. N.", alignRight: false },
  { id: "rolename", label: "Role Name", alignRight: false },
  { id: "createddate", label: "Created Date", alignRight: false },
  { id: "" },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(
      array,
      (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function RoleMgmt() {
  const navigate = useNavigate();

  const [open, setOpen] = useState(null);
  const [curntId, setCurntId] = useState(null);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("name");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [allUserInfo, setAllUserInfo] = useState([]);
  const [allUserInfoErr, setAllUserInfoErr] = useState(false);

  // States for token
  const [userToken, setUserToken] = useState("");

  // States for roles
  const [roleName, setRoleName] = useState("");

  const handleOpenMenu = (e) => {
    setCurntId(e.currentTarget.id);
    setOpen(e.currentTarget);
  };

  const handleCloseMenu = () => {
    setOpen(null);
  };

  // Handling the confirm password change
  const handleRoleName = (e) => {
    setRoleName(e.target.value);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (roleName === "") {
      alert("Please enter all the fields.");
    } else {
      const payLoad = {
        roleName: roleName,
      };
      addRoles(payLoad);
      setRoleName("");
    }
  };

  const addRoles = async (body) => {
    try {
      await axios.post(`${Config.Backend_URL}/role/create`, body, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      });
      alert(`Role (${body.roleName}) successfully created!`);
      allRoleInfoFun(userToken);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  // Handling the role delete
  const handleDelete = () => {
    deleteRoles(curntId);
    setOpen(null);
  };

  const deleteRoles = async (id) => {
    try {
      await axios.delete(`${Config.Backend_URL}/role/delete/${id}`, {
        headers: {
          Authorization: `Bearer ${userToken}`,
        },
      });
      alert("Role successfully deleted!");
      allRoleInfoFun(userToken);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  useEffect(() => {
    const mainUser = JSON.parse(localStorage.getItem("user"));
    setUserToken(mainUser.token);
    allRoleInfoFun(mainUser.token);
  }, []);

  const allRoleInfoFun = async (token) => {
    try {
      const response = await axios.get(`${Config.Backend_URL}/role/allRoles`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setAllUserInfo(response.data);
    } catch (error) {
      if (
        error.response.data.message ===
        "You Are Not Permitted To Access This..."
      ) {
        setAllUserInfoErr(true);
        setTimeout(() => {
          navigate(RoutesPath.HomeNavigation.path);
        }, 3000);
      } else {
        alert(error.response.data.message);
      }
    }
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };

  const filteredUsers = applySortFilter(
    allUserInfo,
    getComparator(order, orderBy)
  );

  if (allUserInfoErr) {
    return (
      <Snackbar open={true} autoHideDuration={6000}>
        <Alert severity="error" sx={{ width: "100%" }}>
          <b>You Are Not Permitted To Access This!</b>
        </Alert>
      </Snackbar>
    );
  } else {
    return (
      <>
        <Helmet>
          <title> Role Management | XCIBIL </title>
        </Helmet>

        <Container>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={2}
          >
            <Typography variant="h4" gutterBottom>
              Create a new role
            </Typography>
          </Stack>

          <Box mb={10}>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { width: "100%" },
              }}
              noValidate
              autoComplete="off"
            >
              <TextField
                id="outlined-basic"
                label="Role Name"
                variant="outlined"
                onChange={handleRoleName}
                value={roleName}
              />
            </Box>
            <Box mt={2}>
              <Button
                variant="contained"
                style={{ backgroundColor: "#103996" }}
                onClick={handleSubmit}
              >
                Create
              </Button>
            </Box>
          </Box>

          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={2}
          >
            <Typography variant="h4" gutterBottom>
              List of all roles
            </Typography>
          </Stack>

          <Card>
            <Scrollbar>
              <TableContainer sx={{ minWidth: 800 }}>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                    rowCount={allUserInfo.length}
                    onRequestSort={handleRequestSort}
                  />
                  <TableBody>
                    {filteredUsers
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row, indexNo) => {
                        const { id, roleName, createdAt } = row;

                        return (
                          <TableRow hover key={id} tabIndex={-1}>
                            <TableCell align="left">{indexNo + 1}</TableCell>

                            <TableCell align="left">{roleName}</TableCell>

                            <TableCell align="left">
                              {createdAt.split("T")[0]}
                            </TableCell>

                            <TableCell align="right">
                              <IconButton
                                id={id}
                                size="large"
                                color="inherit"
                                onClick={handleOpenMenu}
                              >
                                <Iconify icon={"eva:more-vertical-fill"} />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Scrollbar>

            <TablePagination
              rowsPerPageOptions={[10, 25, 50]}
              component="div"
              count={allUserInfo.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Card>
        </Container>

        <Popover
          open={Boolean(open)}
          anchorEl={open}
          onClose={handleCloseMenu}
          anchorOrigin={{ vertical: "top", horizontal: "left" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
          PaperProps={{
            sx: {
              p: 1,
              width: 140,
              "& .MuiMenuItem-root": {
                px: 1,
                typography: "body2",
                borderRadius: 0.75,
              },
            },
          }}
        >
          <MenuItem sx={{ color: "error.main" }} onClick={handleDelete}>
            <Iconify icon={"eva:trash-2-outline"} sx={{ mr: 2 }} />
            Delete
          </MenuItem>
        </Popover>
      </>
    );
  }
}
