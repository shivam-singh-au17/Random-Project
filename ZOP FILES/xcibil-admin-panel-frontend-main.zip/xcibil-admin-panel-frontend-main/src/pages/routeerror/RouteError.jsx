import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleLeft } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";

import { RoutesPath } from "../../routes";
import BgImage from "../../assets/logo.png";
import ErrorImage from "../../assets/404.svg";
import styles from "./routeError.module.css";

export default function RouteError() {
  return (
    <main>
      <section className={styles.mainContainer}>
        <div className="mb-5">
          <img src={BgImage} alt="LOGO" />
        </div>
        <div className={styles.container}>
          <div className={styles.maibBox}>
            <button className={styles.btn}>
              <Link to={RoutesPath.HomeNavigation.path}>
                <span className={styles.backSign}>
                  <FontAwesomeIcon icon={faAngleLeft} />
                </span>
                <span className="px-4">Go back home</span>
              </Link>
            </button>
            <div className={styles.errorImage}>
              <img src={ErrorImage} alt="" />
            </div>
            <div className={styles.mainh3}>
              <p>Page not found</p>
            </div>
            <div className={styles.subP}>
              Oops! Looks like you followed a bad link. If you think this is a
              problem with us, please tell us.
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
