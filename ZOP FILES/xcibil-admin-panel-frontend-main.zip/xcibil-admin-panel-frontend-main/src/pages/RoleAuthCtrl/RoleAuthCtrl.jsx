import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { filter } from "lodash";
// @mui
import {
  Card,
  Table,
  Stack,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  Alert,
  TablePagination,
  Snackbar,
  Button,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  Checkbox,
  ListItemText,
  Grid,
} from "@mui/material";

// sections
import { UserListHead } from "../../sections/@dashboard/user";
import axios from "axios";
import { Config } from "../../config";
import { useNavigate } from "react-router-dom";
import { RoutesPath } from "../../routes";
import Scrollbar from "../../components/scrollbar";
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: "sn", label: "S. N.", alignRight: false },
  { id: "servicename", label: "Service Name", alignRight: false },
  { id: "createddate", label: "Created Date", alignRight: false },
  { id: "adminroles", label: "Admin Roles", alignRight: false },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(
      array,
      (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }
  return stabilizedThis.map((el) => el[0]);
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const names = [
  "Oliver Hansen",
  "Van Henry",
  "April Tucker",
  "Ralph Hubbard",
  "Omar Alexander",
  "Carlos Abbott",
  "Miriam Wagner",
  "Bradley Wilkerson",
  "Virginia Andrews",
  "Kelly Snyder",
];

export default function RoleAuthCtrl() {
  const navigate = useNavigate();

  const [page, setPage] = useState(0);
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("name");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [allRoleServicesInfo, setAllRoleServicesInfo] = useState([]);
  const [allUserInfoErr, setAllUserInfoErr] = useState(false);
  const [serviceName, setServiceName] = useState([]);
  const [roleName, setRoleName] = useState([]);

  // States for token
  const [userToken, setUserToken] = useState("");
  console.log("userToken:", userToken);

  useEffect(() => {
    const mainUser = JSON.parse(localStorage.getItem("user"));
    setUserToken(mainUser.token);
    allRoleAuthInfoFun(mainUser.token);
  }, []);

  const allRoleAuthInfoFun = async (token) => {
    try {
      const response = await axios.get(
        `${Config.Backend_URL}/roleAuthCtrl/allRoleAuthCtrls`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAllRoleServicesInfo(response.data);
    } catch (error) {
      if (
        error.response.data.message ===
        "You Are Not Permitted To Access This..."
      ) {
        setAllUserInfoErr(true);
        setTimeout(() => {
          navigate(RoutesPath.HomeNavigation.path);
        }, 3000);
      } else {
        alert(error.response.data.message);
      }
    }
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };

  const filteredUsers = applySortFilter(
    allRoleServicesInfo,
    getComparator(order, orderBy)
  );

  const handleChangeService = (event) => {
    const {
      target: { value },
    } = event;
    setServiceName(typeof value === "string" ? value.split(",") : value);
  };

  const handleChangeRole = (event) => {
    const {
      target: { value },
    } = event;
    setRoleName(typeof value === "string" ? value.split(",") : value);
  };

  if (allUserInfoErr) {
    return (
      <Snackbar open={true} autoHideDuration={6000}>
        <Alert severity="error" sx={{ width: "100%" }}>
          <b>You Are Not Permitted To Access This!</b>
        </Alert>
      </Snackbar>
    );
  } else {
    return (
      <>
        <Helmet>
          <title> Role Authentication Controller | XCIBIL </title>
        </Helmet>

        <Container>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={2}
          >
            <Typography variant="h4" gutterBottom>
              Assign roles to the service
            </Typography>
          </Stack>

          <Grid container spacing={1} mb={10}>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl sx={{ width: 200 }}>
                <InputLabel id="all-services">All Services</InputLabel>
                <Select
                  labelId="all-services"
                  label="All Services"
                  multiple
                  value={serviceName}
                  onChange={handleChangeService}
                  input={<OutlinedInput label="All Services" />}
                  renderValue={(selected) => selected.join(", ")}
                  MenuProps={MenuProps}
                >
                  {allRoleServicesInfo.map((item) => {
                    let name = item.roleTitle;
                    return (
                      <MenuItem key={item.id} value={name}>
                        <Checkbox checked={serviceName.indexOf(name) > -1} />
                        <ListItemText primary={name} />
                      </MenuItem>
                    );
                  })}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl id="available-roles" sx={{ width: 200 }}>
                <InputLabel>Available Roles</InputLabel>
                <Select
                  labelId="available-roles"
                  label="Available Roles"
                  multiple
                  value={roleName}
                  onChange={handleChangeRole}
                  input={<OutlinedInput label="Available Roles" />}
                  renderValue={(selected) => selected.join(", ")}
                  MenuProps={MenuProps}
                >
                  {names.map((name) => (
                    <MenuItem key={name} value={name}>
                      <Checkbox checked={roleName.indexOf(name) > -1} />
                      <ListItemText primary={name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl sx={{ width: 200, height: "100%" }}>
                <Button
                  variant="contained"
                  style={{ backgroundColor: "#103996", padding: "16px" }}
                >
                  Save Assign Roles
                </Button>
              </FormControl>
            </Grid>
          </Grid>

          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={2}
          >
            <Typography variant="h4" gutterBottom>
              List of all Role Authentication Services
            </Typography>
          </Stack>

          <Card>
            <Scrollbar>
              <TableContainer sx={{ minWidth: 800 }}>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                    rowCount={allRoleServicesInfo.length}
                    onRequestSort={handleRequestSort}
                  />
                  <TableBody>
                    {filteredUsers
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row, indexNo) => {
                        const { id, roleTitle, createdAt, adminRoles } = row;

                        return (
                          <TableRow hover key={id} tabIndex={-1}>
                            <TableCell align="left">{indexNo + 1}</TableCell>

                            <TableCell align="left">{roleTitle}</TableCell>

                            <TableCell align="left">
                              {createdAt.split("T")[0]}
                            </TableCell>

                            <TableCell align="left">
                              <FormControl
                                variant="filled"
                                sx={{ minWidth: 150 }}
                              >
                                <InputLabel>Admin Roles</InputLabel>
                                <Select label="Admin Roles">
                                  {adminRoles.map((item, idx) => {
                                    return (
                                      <span key={idx}>
                                        <MenuItem>
                                          {item !== "" ? item : "NA"}
                                        </MenuItem>
                                      </span>
                                    );
                                  })}
                                </Select>
                              </FormControl>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Scrollbar>

            <TablePagination
              rowsPerPageOptions={[10, 25, 50]}
              component="div"
              count={allRoleServicesInfo.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Card>
        </Container>
      </>
    );
  }
}
