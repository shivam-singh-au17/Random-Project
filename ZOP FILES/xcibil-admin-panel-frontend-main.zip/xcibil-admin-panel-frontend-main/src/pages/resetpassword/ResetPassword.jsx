import React, { useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faAngleLeft,
  faEnvelope,
  faKey,
  faUnlockAlt,
  faLock,
} from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";
import validator from "validator";

import { RoutesPath } from "../../routes";
import { Config } from "../../config";
import BgImage from "../../assets/logo.png";
import styles from "./resetPassword.module.css";

export default function ResetPassword() {
  const navigate = useNavigate();

  // States for registration
  const [otpCode, setOtpCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Handling the name change
  const handleOtpCode = (e) => {
    setOtpCode(e.target.value);
  };

  // Handling the email change
  const handleEmail = (e) => {
    setEmail(e.target.value);
  };

  // Handling the password change
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  // Handling the confirm password change
  const handleConfirmPassword = (e) => {
    setConfirmPassword(e.target.value);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      otpCode === "" ||
      email === "" ||
      password === "" ||
      confirmPassword === ""
    ) {
      alert("Please enter all the fields.");
    } else if (validator.isEmail(email) === false) {
      alert("Please provide a correct email address.");
    } else if (otpCode.trim().length !== 6) {
      alert("OTP must have 6 length.");
    } else if (password.trim().length < 8) {
      alert("Password must have at least 8 characters.");
    } else if (confirmPassword !== password) {
      alert("Password confirmation does not match.");
    } else {
      const payLoad = {
        email: email,
        otpCode: otpCode,
        password: password,
      };
      addPosts(payLoad);
      setOtpCode("");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
    }
  };

  const addPosts = async (body) => {
    try {
      const response = await axios.post(
        `${Config.Backend_URL}/admin/resetPassword`,
        body
      );
      alert(response.data.status);
      navigate(RoutesPath.Signin.path);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  return (
    <main>
      <section className="bg-[#F5F8FB] min-h-screen">
        <div className="flex">
          <div className={styles.container}>
            <div className="py-3">
              <img src={BgImage} alt="LOGO" />
            </div>
            <div className="bg-[white] rounded-2xl shadow-md">
              <div>
                <div className="px-[8%] py-[6%]">
                  <div>
                    <h3 className={styles.mainh3}>Reset password</h3>
                  </div>
                  <form action="" className="text-[1.2rem]">
                    <div className="mt-[4%]">
                      <label htmlFor="">Your Email</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faEnvelope} />
                        </span>
                        <input
                          onChange={handleEmail}
                          value={email}
                          className={styles.formControle}
                          type="email"
                          placeholder="example@gmail.com"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Your OTP</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faKey} />
                        </span>
                        <input
                          onChange={handleOtpCode}
                          value={otpCode}
                          className={styles.formControle}
                          type="text"
                          placeholder="123456"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Your New Password</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faUnlockAlt} />
                        </span>
                        <input
                          onChange={handlePassword}
                          value={password}
                          className={styles.formControle}
                          type="text"
                          placeholder="Password"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Confirm Password</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faLock} />
                        </span>
                        <input
                          onChange={handleConfirmPassword}
                          value={confirmPassword}
                          className={styles.formControle}
                          type="password"
                          placeholder="Confirm Password"
                        />
                      </div>
                    </div>
                    <button onClick={handleSubmit} className={styles.btn}>
                      Reset password
                    </button>
                  </form>
                  <div className="mt-[4%] text-center">
                    <span>OR</span>
                  </div>
                  <div className="mt-[4%]">
                    <span className={styles.backSign}>
                      <FontAwesomeIcon icon={faAngleLeft} />
                    </span>
                    <Link to={RoutesPath.Signin.path}>
                      <span className={styles.loginText}>Back to sign in</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
