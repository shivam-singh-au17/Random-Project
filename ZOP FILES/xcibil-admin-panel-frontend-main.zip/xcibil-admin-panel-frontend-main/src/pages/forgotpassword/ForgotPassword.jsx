import React, { useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleLeft, faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";
import validator from "validator";

import { RoutesPath } from "../../routes";
import { Config } from "../../config";
import BgImage from "../../assets/logo.png";
import styles from "./forgotPassword.module.css";

export default function ForgotPassword() {
  const navigate = useNavigate();

  // States for registration
  const [email, setEmail] = useState("");

  // Handling the email change
  const handleEmail = (e) => {
    setEmail(e.target.value);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (email === "") {
      alert("Please enter all the fields.");
    } else if (validator.isEmail(email) === false) {
      alert("Please provide a correct email address.");
    } else {
      const payLoad = {
        email: email,
      };
      addPosts(payLoad);
      setEmail("");
    }
  };

  const addPosts = async (body) => {
    try {
      const response = await axios.post(
        `${Config.Backend_URL}/admin/forgotPassword`,
        body
      );
      alert(response.data.status);
      navigate(RoutesPath.ResetPassword.path);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  return (
    <main>
      <section className="bg-[#F5F8FB] min-h-screen">
        <div className="flex">
          <div className={styles.container}>
            <div className="py-3">
              <img src={BgImage} alt="LOGO" />
            </div>
            <div className="bg-[white] rounded-2xl shadow-md">
              <div>
                <div className="px-[8%] py-[6%]">
                  <div>
                    <h3 className={styles.mainh3}>Forgot your password?</h3>
                  </div>
                  <div className="text-center py-3 text-[1.2rem] text-[#474747]">
                    Do not fret! Just type in your email and we will send you a
                    code to reset your password!
                  </div>
                  <form action="" className="text-[1.2rem]">
                    <div className="mt-[5%]">
                      <label htmlFor="">Your Email</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faEnvelope} />
                        </span>
                        <input
                          onChange={handleEmail}
                          value={email}
                          className={styles.formControle}
                          type="email"
                          placeholder="example@gmail.com"
                        />
                      </div>
                    </div>
                    <button onClick={handleSubmit} className={styles.btn}>
                      Recover password
                    </button>
                  </form>
                  <div className="mt-[5%] text-center">
                    <span>OR</span>
                  </div>
                  <div className="flex mt-[5%]">
                    <span className={styles.loginText}>
                      <Link to={RoutesPath.Signin.path}>
                        <FontAwesomeIcon icon={faAngleLeft} /> Back to sign in
                      </Link>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
