import React, { useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faUnlockAlt,
  faMobile,
  faLock,
} from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import validator from "validator";

import { RoutesPath } from "../../routes";
import { Config } from "../../config";
import styles from "./signup.module.css";

export default function Signup() {
  const navigate = useNavigate();

  // States for registration
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Handling the name change
  const handlePhone = (e) => {
    setPhone(e.target.value);
  };

  // Handling the email change
  const handleEmail = (e) => {
    setEmail(e.target.value);
  };

  // Handling the password change
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  // Handling the confirm password change
  const handleConfirmPassword = (e) => {
    setConfirmPassword(e.target.value);
  };

  // Handling the form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      phone === "" ||
      email === "" ||
      password === "" ||
      confirmPassword === ""
    ) {
      alert("Please enter all the fields.");
    } else if (validator.isEmail(email) === false) {
      alert("Please provide a correct email address.");
    } else if (phone.trim().length !== 10) {
      alert("Please provide a correct mobaile number.");
    } else if (password.trim().length < 8) {
      alert("Password must have at least 8 characters.");
    } else if (confirmPassword !== password) {
      alert("Password confirmation does not match.");
    } else {
      const payLoad = {
        email: email,
        mobile: phone,
        password: password,
      };
      addPosts(payLoad);
      setPhone("");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
    }
  };

  const addPosts = async (body) => {
    try {
      await axios.post(`${Config.Backend_URL}/admin/register`, body);
      alert(`User (${body.email}) successfully registered!`);
      navigate(RoutesPath.Signin.path);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  return (
    <main>
      <section className="bg-[#F5F8FB] min-h-screen">
        <div className="flex">
          <div className={styles.container}>
            <div className="bg-[white] rounded-2xl shadow-md">
              <div>
                <div className="px-[8%] py-[6%]">
                  <div>
                    <h3 className={styles.mainh3}>Create an account</h3>
                  </div>
                  <form action="" className="text-[1.2rem]">
                    <div className="mt-[4%]">
                      <label htmlFor="">Your Email</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faEnvelope} />
                        </span>
                        <input
                          onChange={handleEmail}
                          value={email}
                          className={styles.formControle}
                          type="email"
                          placeholder="example@gmail.com"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Your Phone</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faMobile} />
                        </span>
                        <input
                          onChange={handlePhone}
                          value={phone}
                          className={styles.formControle}
                          type="text"
                          placeholder="Phone"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Your Password</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faUnlockAlt} />
                        </span>
                        <input
                          onChange={handlePassword}
                          value={password}
                          className={styles.formControle}
                          type="text"
                          placeholder="Password"
                        />
                      </div>
                    </div>
                    <div className="mt-[4%]">
                      <label htmlFor="">Confirm Password</label>
                      <div className={styles.inputGroup}>
                        <span className={styles.inputGroupText}>
                          <FontAwesomeIcon icon={faLock} />
                        </span>
                        <input
                          onChange={handleConfirmPassword}
                          value={confirmPassword}
                          className={styles.formControle}
                          type="password"
                          placeholder="Confirm Password"
                        />
                      </div>
                    </div>
                    <button
                      onClick={handleSubmit}
                      className={styles.btn}
                      type="submit"
                    >
                      Sign up
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
