import React from "react";
// theme
import ThemeProvider from "./theme";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import { RoutesPath } from "./routes";

import DashboardLayout from "./layouts/dashboard";
import Login from "./pages/login/Login";
import ForgotPassword from "./pages/forgotpassword/ForgotPassword";
import ResetPassword from "./pages/resetpassword/ResetPassword";
import RouteError from "./pages/routeerror/RouteError";
import HomeNavigation from "./pages/homenavigation/HomeNavigation";
import PrivateRoutes from "./utils/PrivateRoutes";
import AllUser from "./pages/alluser/AllUser";
import AllUserWithoutPan from "./pages/alluser/AllUserWithoutPan";
import AllUserWithPan from "./pages/alluser/AllUserWithPan";
import UserMgmt from "./pages/usermgmt/UserMgmt";
import RoleMgmt from "./pages/rolemgmt/RoleMgmt";
import RoleAuthCtrl from "./pages/RoleAuthCtrl/RoleAuthCtrl";

function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<PrivateRoutes />}>
            <Route
              path={RoutesPath.HomeNavigation.path}
              element={<DashboardLayout />}
            >
              <Route
                path={RoutesPath.Dashboard.path}
                element={<HomeNavigation />}
              />
              <Route
                path={RoutesPath.HomeNavigation.path}
                element={<HomeNavigation />}
              />
              <Route path={RoutesPath.AllUser.path} element={<AllUser />} />
              <Route
                path={RoutesPath.AllUserWithoutPan.path}
                element={<AllUserWithoutPan />}
              />
              <Route
                path={RoutesPath.AllUserWithPan.path}
                element={<AllUserWithPan />}
              />
              <Route path={RoutesPath.AdminMgmt.path} element={<UserMgmt />} />
              <Route path={RoutesPath.RoleMgmt.path} element={<RoleMgmt />} />
              <Route
                path={RoutesPath.RoleAuthCtrl.path}
                element={<RoleAuthCtrl />}
              />
            </Route>
          </Route>
          <Route path={RoutesPath.Signin.path} element={<Login />} exact />
          <Route
            path={RoutesPath.ForgotPassword.path}
            element={<ForgotPassword />}
          />
          <Route
            path={RoutesPath.ResetPassword.path}
            element={<ResetPassword />}
          />
          <Route path="*" element={<RouteError />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
