# Syoft Technical Task

# Steps to browse the project:

### First you clone or download this project from here.
```
git clone https://github.com/shivam-singh-au17/syoft-assignment.git
```

### And then open it in VS Code and then enter these commands in the terminal.  
```
npm install
```
```
npm start
```

### You can see the list of APIs here
#### Note:- Test API on the postman because due to lack of time, the functionality of sending tokens has not been implemented in it.
```
http://localhost:3000/docs
```

### Authorization work for only three roles - admin, manager, and staff

### Thank you for giving it a read...
