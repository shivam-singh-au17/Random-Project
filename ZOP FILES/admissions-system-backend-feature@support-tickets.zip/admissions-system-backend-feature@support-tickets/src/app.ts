import { json } from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { Application } from "express";
import createHttpError from "http-errors";
import mongoose from "mongoose";
import morgan from "morgan";
import path from "path";
import swaggerUi from "swagger-ui-express";
import YAML from "yamljs";

import { dbUrl } from "./config";
import { errorHandlers } from "./middlewares/errorHanlders";
import { academicYear } from "./routes/academicYear";
import { addGender } from "./routes/addGender";
import { applicationForm } from "./routes/applicationForm";
import { attachDepartmentCodes } from "./routes/attachDepartmentCodes";
import { attachMediumCodes } from "./routes/attachMediumCodes";
import { attachProgramCodes } from "./routes/attachProgramCodes";
import { bankAccount } from "./routes/bankAccount";
import { disability } from "./routes/disability";
import { category } from "./routes/category";
import { feeHead } from "./routes/feeHead";
import { feeStructureCodes } from "./routes/feeStructureCodes";
import { razorpayIntegrationRouter } from "./routes/integrations/razorpay/razorpay.router";
import { invoiceRouter } from "./routes/invoice/invoice.router";
import { martialStatus } from "./routes/martialStatus";
import { paymentRouter } from "./routes/payments/payments.router";

// Routers Imports
import { projectMgmtService } from "./routes/projectMgmtService";
import { registrationForm } from "./routes/registrationForm";
import { setupDegree } from "./routes/setupDegree";
import { setupDepartment } from "./routes/setupDepartment";
import { setupLanguage } from "./routes/setupLanguage";
import { setupProgram } from "./routes/setupProgram";
import { sms } from "./routes/sms";
import { staffAppEndPoints } from "./routes/staffAppEndPoints";
import { staffAppRegistration } from "./routes/staffAppRegistration";
import { dcrRouter } from "./routes/dcr/dcr.router";
import { getUser } from "./middlewares/authentications/get-user";
import { supportTicketsCategory } from "./routes/supportTicketsCategory";
import { supportTicket } from "./routes/supportTicket";
import { compulsorySubject } from "./routes/compulsorySubject";
import { combinationSubject } from "./routes/combinationSubject";
import { subjectAllocation } from "./routes/subjectAllocation";
import { juniorCollegeEndpoints } from "./routes/juniorCollegeEndpoints";
import { freezeSeatRouter } from "./routes/userActions/meritList/feezeSeat.router";
import { seatAllocation } from "./routes/seatAllocation";
import { projectSetup } from "./routes/projectSetup";

// Server Configurations.
const app: Application = express();
app.use(cors());

// Allowing service to parse json
app.use(json());

// Enabling Cookies On To Translate Between Client & MicroService
app.use(cookieParser());

// HTTP request logger middleware
app.use(morgan("dev"));

// Swagger UI documentation configuration
const ymlPath = path.join(__dirname, "../api-docs.yml");
app.use("/docs", swaggerUi.serve, (req, res) => {
  res.send(swaggerUi.generateHTML(YAML.load(ymlPath)));
});

const ymlPathTwo = path.join(__dirname, "../extracted-docs.yml");
app.use("/extracted/docs", swaggerUi.serve, (req, res) => {
  res.send(swaggerUi.generateHTML(YAML.load(ymlPathTwo)));
});

// get user
app.use(getUser);

app.use("/current-user", (req, res) => {
  const user = req.user ? req.user : { currentUser: null };
  res.send(user);
});

// Project Management Service Router
app.use(projectMgmtService);
app.use(registrationForm);
app.use(applicationForm);
app.use(staffAppRegistration);
app.use(staffAppEndPoints);
app.use(academicYear);
app.use(category);
app.use(feeHead);
app.use(bankAccount);
app.use(setupDegree);
app.use(setupProgram);
app.use(setupDepartment);
app.use(setupLanguage);
app.use(addGender);
app.use(martialStatus);
app.use(disability);
app.use(sms);
app.use(attachDepartmentCodes);
app.use(attachMediumCodes);
app.use(attachProgramCodes);
app.use(feeStructureCodes);
app.use(supportTicketsCategory);
app.use(supportTicket);
app.use(compulsorySubject);
app.use(combinationSubject);
app.use(subjectAllocation);
app.use(juniorCollegeEndpoints);
app.use(seatAllocation);
app.use(projectSetup);

// Invoice Router
app.use(invoiceRouter);

// Integrations Router
app.use(razorpayIntegrationRouter);

// DCR Router
app.use(dcrRouter);

// Payment Router
app.use(paymentRouter);

// User Actions Routers
app.use(freezeSeatRouter);

// Catching all unexpected routes & Error Handler.
app.all("*", () => {
  // Route not found error.
  throw createHttpError(404, "Route not found");
});

app.use(errorHandlers);

// Mongodb Connection
mongoose
  .connect(dbUrl)
  .then(() => {
    console.log("Connected To Database ✅");
  })
  .catch(() => {
    throw createHttpError(501, "Unable to connect database");
  });

export { app };
