import { Schema, model, Document } from "mongoose";

interface academicYearDocument extends Document {
  academicYear: string;
  status: boolean;
}

const academicYearSchema = new Schema(
  {
    academicYear: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const AcademicYear = model<academicYearDocument>(
  "academicYear",
  academicYearSchema
);

export { AcademicYear };
