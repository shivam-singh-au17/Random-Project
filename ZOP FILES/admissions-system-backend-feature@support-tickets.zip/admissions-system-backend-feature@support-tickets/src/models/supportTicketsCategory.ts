import { Schema, model, Document } from "mongoose";

interface supportTicketsCategoryDocument extends Document {
  categoryName: string;
  assignCategoryPerson: string;
  description: string;
}

const supportTicketsCategorySchema = new Schema(
  {
    categoryName: { type: String, required: true },
    assignCategoryPerson: { type: String, required: true },
    description: { type: String, required: true },
  },
  { versionKey: false }
);

const SupportTicketsCategory = model<supportTicketsCategoryDocument>(
  "supportTicketsCategory",
  supportTicketsCategorySchema
);

export { SupportTicketsCategory };
