import { Schema, model, Document } from "mongoose";

interface attachMediumCodesDocument extends Document {
  selectLanguageMedium: string;
  addCode: string;
}

const attachMediumCodesSchema = new Schema(
  {
    selectLanguageMedium: { type: String, required: true },
    addCode: { type: String, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const AttachMediumCodes = model<attachMediumCodesDocument>(
  "attachMediumCodes",
  attachMediumCodesSchema
);

export { AttachMediumCodes };
