import { Schema, model, Document } from "mongoose";

interface martialStatusDocument extends Document {
  addMartialStatus: string;
  status: boolean;
}

const martialStatusSchema = new Schema(
  {
    addMartialStatus: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const MartialStatus = model<martialStatusDocument>(
  "martialStatus",
  martialStatusSchema
);

export { MartialStatus };
