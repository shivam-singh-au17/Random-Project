import { Schema, model, Document } from "mongoose";

interface attachProgramCodesDocument extends Document {
  programFullName: string;
  programShortName: string;
  addCode: string;
  status: boolean;
}

const attachProgramCodesSchema = new Schema(
  {
    programFullName: { type: String, required: true },
    programShortName: { type: String, required: true },
    addCode: { type: String, required: true },
    status: { type: Boolean, default: false },
  },
  {
    versionKey: false,
  }
);

const AttachProgramCodes = model<attachProgramCodesDocument>(
  "attachProgramCodes",
  attachProgramCodesSchema
);

export { AttachProgramCodes };
