import { Document, model, Schema } from "mongoose";

interface feeHeadDocument extends Document {
  feeHeadName: string;
  category: string;
  bankAccount: string;
}

const feeHeadSchema = new Schema(
  {
    feeHeadName: { type: String, required: true },
    category: { type: Schema.Types.ObjectId, ref: "category", required: true },
    bankAccount: {
      type: Schema.Types.ObjectId,
      ref: "bankAccount",
      required: true,
    },
  },
  {
    versionKey: false,
  }
);

const FeeHead = model<feeHeadDocument>("feeHead", feeHeadSchema);

export { FeeHead };
