import { Document, model, Schema } from "mongoose";

interface categoryDocument extends Document {
  categoryName: string;
}

const categorySchema = new Schema(
  {
    categoryName: { type: String, required: true },
  },
  {
    versionKey: false,
  }
);

const Category = model<categoryDocument>("category", categorySchema);

export { Category };
