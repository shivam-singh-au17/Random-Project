import { Schema, model, Document } from "mongoose";

interface setupLanguageDocument extends Document {
  languageName: string;
  status: boolean;
}

const setupLanguageSchema = new Schema(
  {
    languageName: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const SetupLanguage = model<setupLanguageDocument>(
  "setupLanguage",
  setupLanguageSchema
);

export { SetupLanguage };
