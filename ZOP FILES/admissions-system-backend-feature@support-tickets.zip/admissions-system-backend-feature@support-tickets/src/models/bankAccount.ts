import { Schema, model, Document } from "mongoose";

interface bankAccountDocument extends Document {
  bankName: string;
  branch: string;
  bankAddress: string;
  ifscCode: string;
  accountNo: string;
}

const bankAccountSchema = new Schema(
  {
    bankName: { type: String, required: true },
    branch: { type: String, required: true },
    bankAddress: { type: String, required: true },
    ifscCode: { type: String, required: true },
    accountNo: { type: String, required: true },
  },
  {
    versionKey: false,
  }
);

const BankAccount = model<bankAccountDocument>(
  "bankAccount",
  bankAccountSchema
);

export { BankAccount, bankAccountSchema, bankAccountDocument };
