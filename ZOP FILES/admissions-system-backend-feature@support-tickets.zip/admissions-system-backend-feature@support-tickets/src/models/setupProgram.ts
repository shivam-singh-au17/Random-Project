import { Schema, model, Document } from "mongoose";

interface setupProgramDocument extends Document {
  programFullName: string;
  programShortName: string;
  status: boolean;
}

const setupProgramSchema = new Schema(
  {
    programFullName: { type: String, required: true },
    programShortName: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const SetupProgram = model<setupProgramDocument>(
  "setupProgram",
  setupProgramSchema
);

export { SetupProgram };
