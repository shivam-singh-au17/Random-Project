import { Schema, model, Document } from "mongoose";

interface setupDegreeDocument extends Document {
  degreeFullName: string;
  degreeShortName: string;
  status: boolean;
}

const setupDegreeSchema = new Schema(
  {
    degreeFullName: { type: String, required: true },
    degreeShortName: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const SetupDegree = model<setupDegreeDocument>(
  "setupDegree",
  setupDegreeSchema
);

export { SetupDegree };
