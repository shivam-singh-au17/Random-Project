import mongoose from "mongoose";
import { Schema } from "mongoose";

export interface head {
  head: string;
  amount: number;
}
export interface payment {
  name: string;
  status: string;
  dues: head[];
  paid: head[];
  invoices: string[];
}

// payments attrs & documents.
export interface paymentAttrs {
  user_id: mongoose.Schema.Types.ObjectId;
  payments: payment[];
}
const paymentHistorySchema = new Schema(
  {
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    payments: [
      {
        name: {
          type: String,
          required: true,
        },
        status: {
          type: String,
          required: true,
        },
        dues: [{ head: String, amount: Number }],
        paid: [{ head: String, amount: Number }],
      },
    ],
  },
  {
    timestamps: true,
  }
);

interface paymentHistoryModel extends mongoose.Model<paymentAttrs> {
  build(attr: paymentAttrs): paymentAttrs;
}

paymentHistorySchema.statics.build = (attrs: paymentAttrs) => {
  return new Payment(attrs);
};
const Payment = mongoose.model<paymentAttrs, paymentHistoryModel>(
  "Payment",
  paymentHistorySchema
);

export { Payment };
