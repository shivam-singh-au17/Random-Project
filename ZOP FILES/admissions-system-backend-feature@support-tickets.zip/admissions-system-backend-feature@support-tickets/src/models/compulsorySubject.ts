import { Schema, model, Document } from "mongoose";

interface compulsorySubjectDocument extends Document {
  programName: string;
  yearAppliedFor: string;
  compulsorySubject: string;
}

const compulsorySubjectSchema = new Schema(
  {
    programName: { type: String, required: true },
    yearAppliedFor: { type: String, required: true},
    compulsorySubject: [
      {
        subjectName: { type: String, required: true },
      },
    ],
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

const CompulsorySubject = model<compulsorySubjectDocument>(
  "compulsorySubject",
  compulsorySubjectSchema
);

export { CompulsorySubject };
