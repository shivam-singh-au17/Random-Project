import { Schema, model, Document } from "mongoose";

interface supportTicketDocument extends Document {
  ticketNumber: string;
  candidateId: string;
  applicationFormNumber: string;
  ticketRequester: string;
  subject: string;
  requestCategoryId: string;
  description: string;
  ticketStatus: string;
  ticketCreatedDate: string;
}

const supportTicketSchema = new Schema(
  {
    ticketNumber: { type: String, required: true },
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: "registrationForm",
      required: true,
    },
    applicationFormNumber: { type: String },
    ticketRequester: { type: String, required: true },
    subject: { type: String, required: true },
    requestCategoryId: {
      type: Schema.Types.ObjectId,
      ref: "supportTicketsCategory",
      required: true,
    },
    description: { type: String, required: true },
    ticketStatus: { type: String, required: true, default: "OPEN" },
    ticketCreatedDate: { type: String, required: true },
    adminStudentComment: [
      {
        studentComment: { type: String },
        adminComment: { type: String },
        studentDateTime: { type: String },
        adminDateTime: { type: String },
      },
    ],
  },
  { versionKey: false }
);

const SupportTicket = model<supportTicketDocument>(
  "supportTicket",
  supportTicketSchema
);

export { SupportTicket };
