import { Schema, model, Document } from "mongoose";

// This schema is being used to generate the counter of the registration number.

interface globalCounterDocument extends Document {
  registrationNoCount: number;
}

const globalCounterSchema = new Schema(
  {
    registrationNoCount: { type: Number, required: true },
  },
  {
    versionKey: false,
  }
);

const GlobalCounterService = model<globalCounterDocument>(
  "globalCounter",
  globalCounterSchema
);

// This schema is being used to generate the counter of the form number.

interface formCounterDocument extends Document {
  formNoCount: number;
}

const formCounterSchema = new Schema(
  {
    formNoCount: { type: Number, required: true },
  },
  {
    versionKey: false,
  }
);

const FormCounterService = model<formCounterDocument>(
  "formCounter",
  formCounterSchema
);

// This schema is being used to generate the counter of the support ticket.

interface supportTicketCounterDocument extends Document {
  supportTicketCount: number;
}

const supportTicketCounterSchema = new Schema(
  {
    supportTicketCount: { type: Number, required: true },
  },
  {
    versionKey: false,
  }
);

const SupportTicketCounter = model<supportTicketCounterDocument>(
  "supportTicketCounter",
  supportTicketCounterSchema
);

export { GlobalCounterService, FormCounterService, SupportTicketCounter };
