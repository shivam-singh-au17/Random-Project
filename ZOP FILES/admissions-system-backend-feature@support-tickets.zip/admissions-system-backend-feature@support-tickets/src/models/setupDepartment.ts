import { Schema, model, Document } from "mongoose";

interface setupDepartmentDocument extends Document {
  departmentName: string;
  status: boolean;
}

const setupDepartmentSchema = new Schema(
  {
    departmentName: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const SetupDepartment = model<setupDepartmentDocument>(
  "setupDepartment",
  setupDepartmentSchema
);

export { SetupDepartment };
