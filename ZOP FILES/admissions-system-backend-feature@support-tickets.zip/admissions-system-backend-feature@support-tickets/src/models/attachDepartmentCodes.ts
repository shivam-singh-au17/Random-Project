import { Schema, model, Document } from "mongoose";

interface attachDepartmentCodesDocument extends Document {
  departmentName: string;
  addCode: string;
  status: boolean;
}

const attachDepartmentCodesSchema = new Schema(
  {
    departmentName: { type: String, required: true },
    addCode: { type: String, required: true },
    status: { type: Boolean, default: false },
  },
  {
    versionKey: false,
  }
);

const AttachDepartmentCodes = model<attachDepartmentCodesDocument>(
  "attachDepartmentCodes",
  attachDepartmentCodesSchema
);

export { AttachDepartmentCodes };
