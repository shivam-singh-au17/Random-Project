import mongoose from "mongoose";
import { ObjectId, Schema } from "mongoose";
import { bankAccountDocument, bankAccountSchema } from "./bankAccount";
import { feeStructureCodesDocument } from "./feeStructureCodes";

// invoice interface for creating new invoice document.
interface invoiceAttrs {
  ["INVOICE NO"]: string;
  ["NAME"]: string;
  ["AMOUNT PAID"]: number;
  ["TOTAL"]: number;
  ["SUB TOTAL"]: number;
  ["FEE STRUCTURE"]: feeStructureCodesDocument;
  ["USER ID"]: string;
  ["USER DETAILS"]: {
    NAME: string;
    CONTACT: string;
    EMAIL: string;
  };
  SIGNATURES: Record<string, object>;
  REMARKS?: string;
  ["INSTALLMENT NO"]?: number;
  ["BENEFICIARY ACCOUNT"]: bankAccountDocument;
  MODE: Record<any, object>;
}

// mongodb document interface.
interface InvoiceDoc {
  ["INVOICE NO"]: string;
  ["NAME"]: string;
  ["AMOUNT PAID"]: number;
  ["TOTAL"]: number;
  ["SUB TOTAL"]: number;
  ["FEE STRUCTURE"]: feeStructureCodesDocument;
  ["USER ID"]: string;
  ["USER DETAILS"]: {
    NAME: string;
    CONTACT: string;
    EMAIL: string;
  };
  SIGNATURES: Record<string, object>;
  REMARKS?: string;
  ["INSTALLMENT NO"]?: number;
  ["BENEFICIARY ACCOUNT"]: bankAccountDocument;
  ["INVOICE ID"]: Schema.Types.ObjectId;
  MODE: Record<any, object>;
}
// attaching build object on model
interface InvoiceModel extends mongoose.Model<InvoiceDoc> {
  build(attr: invoiceAttrs): InvoiceDoc;
}

// schema for invoice.
const InvoiceSchema = new Schema(
  {
    ["INVOICE NO"]: String,
    ["NAME"]: String,
    ["AMOUNT PAID"]: Number,
    ["TOTAL"]: Number,
    ["SUB TOTAL"]: Number,
    ["FEE STRUCTURE"]: {},
    ["USER ID"]: String,
    ["USER DETAILS"]: {
      NAME: String,
      CONTACT: String,
      EMAIL: String,
    },
    SIGNATURES: {},
    REMARKS: String,
    ["INSTALLMENT NO"]: Number,
    ["BENEFICIARY ACCOUNT"]: bankAccountSchema,
    MODE: {},
  },
  {
    timestamps: true,
    toObject: {
      transform: function (doc, ret) {
        ret["INVOICE ID"] = ret._id;
      },
    },
  }
);

// availing typescript with mongodb.
InvoiceSchema.statics.build = (attrs: invoiceAttrs) => {
  return new Invoice(attrs);
};

const Invoice = mongoose.model<InvoiceDoc, InvoiceModel>(
  "Invoice",
  InvoiceSchema
);

export { Invoice };
