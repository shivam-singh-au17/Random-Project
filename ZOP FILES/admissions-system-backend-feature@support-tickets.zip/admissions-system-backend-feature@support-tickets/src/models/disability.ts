import { Schema, model, Document } from "mongoose";

interface disabilityDocument extends Document {
  disability: string;
  status: boolean;
}

const disabilitySchema = new Schema(
  {
    disability: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const Disability = model<disabilityDocument>(
  "disability",
  disabilitySchema
);

export { Disability };
