import { Schema, model, Document } from "mongoose";

interface subjectAllocationDocument extends Document {
  programName: string;
  yearAppliedFor: string;
}

const subjectAllocationSchema = new Schema(
  {
    programName: { type: String, required: true },
    yearAppliedFor: { type: String, required: true },
    combinationSubject: {
      type: Schema.Types.ObjectId,
      ref: "combinationSubject",
      required: true,
    },
    compulsorySubject: {
      type: Schema.Types.ObjectId,
      ref: "compulsorySubject",
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const SubjectAllocation = model<subjectAllocationDocument>(
  "subjectAllocation",
  subjectAllocationSchema
);

export { SubjectAllocation };
