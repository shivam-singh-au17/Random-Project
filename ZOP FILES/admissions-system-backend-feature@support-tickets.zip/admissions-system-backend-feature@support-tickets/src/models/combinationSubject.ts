import { Schema, model, Document } from "mongoose";

interface combinationSubject {
  subjectName: string;
}

interface combinationSubjectDocument extends Document {
  programName: string;
  yearAppliedFor: string;
  combinationSubject: combinationSubject[];
}

const combinationSubjectSchema = new Schema(
  {
    programName: { type: String, required: true },
    yearAppliedFor: { type: String, required: true},
    combinationSubject: [
      {
        subjectName: { type: String },
      },
    ],
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const CombinationSubject = model<combinationSubjectDocument>(
  "combinationSubject",
  combinationSubjectSchema
);

export { CombinationSubject };
