import { Schema, model, Document } from "mongoose";

interface projectMgmtServiceDocument extends Document {
  project_name: string;
  start_date: string;
  end_date: string;
  team: string[];
  team_name: string;
  course_code: number;
  course_year: number;
}

/*
export interface TrueFalseItem {
  text: string;
  value: boolean;
}

export interface TrueFalseListWrapper {
  // renamed from ITrueFalse
  itemList: TrueFalseItem[];
}
*/

const projectMgmtServiceSchema = new Schema(
  {
    project_name: { type: String, required: true },
    start_date: { type: String, required: true, default: new Date() },
    end_date: { type: String },
    team: { type: Array, required: true },
    team_name: { type: String, required: true, unique: false },
    course_code: { type: Number, required: true },
    course_year: { type: Number, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const ProjectMgmtService = model<projectMgmtServiceDocument>(
  "projectMgmtService",
  projectMgmtServiceSchema
);

export { ProjectMgmtService };
