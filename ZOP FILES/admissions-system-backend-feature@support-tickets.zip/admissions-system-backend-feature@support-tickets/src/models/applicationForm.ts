import { Schema, model, Document } from "mongoose";

interface otherDocument {
  documentName: string;
  url: string;
  submitted: boolean;
  valid: boolean;
  message: string;
  isMandatory: boolean;
  _id: string;
}

interface mandatoryDocumentCommon {
  documentName: string;
  url: string;
  submitted: boolean;
  valid: boolean;
  message: string;
  _id: string;
}

interface mandatoryDocument {
  signature: mandatoryDocumentCommon;
  photo: mandatoryDocumentCommon;
  _id: string;
}

interface jcMandatoryDocuments {
  xLeavingCertificate: mandatoryDocumentCommon;
  xMarksheet: mandatoryDocumentCommon;
  aadharCard: mandatoryDocumentCommon;
  signature: mandatoryDocumentCommon;
  photo: mandatoryDocumentCommon;
  _id: string;
}

interface combinationSubject {
  subjectCode: string;
  preference: number;
  _id: string;
}

interface personalDetails {
  aadharNumber: string;
  govPorEnrollNumber: string;
  firstName: string;
  lastName: string;
  fatherName: string;
  motherName: string;
  placeOfBirth: string;
  dateOfBirth: string;
  motherTongue: string;
  category: string;
  bloodGroup: string;
  nationality: string;
  religion: string;
  gender: string;
  maritalStatus: boolean;
  caste: string;
  subCaste: string;
  _id: string;
}

interface contactDetails {
  mobile: string;
  parentMobile: string;
  parentEmail: string;
  district: string;
  address: string;
  pinCode: string;
  state: string;
  _id: string;
}

interface matricEducation {
  boardName: string;
  schoolName: string;
  passingDate: string;
  isGrade: string;
  score: string;
  seatNumber: number;
  obtainedMarks: number;
  totalMarks: number;
  _id: string;
}

interface intermediateEducation {
  boardName: string;
  schoolName: string;
  passingDate: string;
  isGrade: string;
  score: string;
  seatNumber: number;
  obtainedMarks: number;
  totalMarks: number;
  _id: string;
}

interface bachelorsDegree {
  yearOfPassing: string;
  instituteName: string;
  degreeTitle: string;
  yearsOffered: string;
  sem1stScore: string;
  sem2ndScore: string;
  CGPA: string;
  obtainOutOf: string;
  _id: string;
}

interface otherDegree {
  yearOfPassing: string;
  instituteName: string;
  degreeTitle: string;
  percentage: string;
  physicsMarks: string;
  chemistryMarks: string;
  mathsMarks: string;
  biologyMarks: string;
  _id: string;
}

interface academicDetails {
  matricEducation: matricEducation;
  intermediateEducation: intermediateEducation;
  bachelorsDegree: bachelorsDegree;
  otherDegree: otherDegree;
  _id: string;
}

interface legalDetails {
  domicile: string;
  parentOccupation: string;
  annualIncome: number;
  reservationInformation: string;
  sikhMinority: boolean;
  parentAddress: string;
  parentMobile: string;
  _id: string;
}

interface declaration {
  place: string;
  date: string;
  termsCondition: boolean;
  _id: string;
}

interface additionalDocs {
  documentName: string;
  documentType: string;
  priority: boolean;
  emailCommunication: boolean;
  smsCommunication: boolean;
  messageTemplate: string;
  _id: string;
}

interface jcAcademicDetails {
  examName: string;
  boardName: string;
  schoolName: string;
  passingDate: string;
  seatNumber: number;
  totalMarks: number;
  obtainedMarks: number;
  percentage: number;
  _id: string;
}

interface allocatedSubjects {
  compulsorySubject: string;
  combinationSubjects: string;
  combinationSubjectsId: string;
  _id: string;
}

interface META {
  TAGS: string[];
  FEE_STRUCTURE: string;
}

interface applicationFormDocument extends Document {
  formNo: string;
  typeOfForm: string;
  collegeType: string;
  stepCounter: number;
  secondStepCount: number;
  formSubmitted: boolean;
  isInHouse: boolean;
  yearAppliedFor: string;
  dateAppliedOn: string;
  candidateId: string;
  programName: string;
  programCode: string;
  compulsorySubject: string;
  applicationFee: boolean;
  combinationSubject: combinationSubject[];
  academicYear: string;
  uanNumber: string;
  personalDetails: personalDetails;
  contactDetails: contactDetails;
  academicDetails: academicDetails;
  jcAcademicDetails: jcAcademicDetails;
  legalDetails: legalDetails;
  declaration: declaration;
  otherDocuments: otherDocument[];
  mandatoryDocuments: mandatoryDocument;
  jcMandatoryDocuments: jcMandatoryDocuments;
  inReview: boolean;
  reviewedPerson: string;
  applicationReviewRound: string;
  inScrutiny: boolean;
  scrutinizedPerson: string;
  applicationScrutinyRound: string;
  isAllocatedSubjects: boolean;
  allocatedSubjects: allocatedSubjects;
  isAllocatedBy: string;
  verificationRound: string;
  verificationRoundPerson: string;
  meritListCandidate: string;
  inMeritList: boolean;
  additionalDocs: additionalDocs[];
  denyReason: string;
  denyPerson: string;
  isGeneratedList: boolean;
  isPublishedList: boolean;
  META: META;
  _id: string;
}

const applicationFormSchema = new Schema(
  {
    formNo: { type: String, required: true },
    typeOfForm: { type: String, required: true },
    collegeType: { type: String, required: true },
    stepCounter: { type: Number, required: true, default: 1 },
    secondStepCount: { type: Number, required: true, default: 0 },
    formSubmitted: { type: Boolean, required: true, default: false },
    isInHouse: { type: Boolean },
    applicationFee: { type: Boolean, required: true, default: false },
    yearAppliedFor: { type: String, required: true },
    dateAppliedOn: { type: String },
    candidateId: {
      type: Schema.Types.ObjectId,
      ref: "registrationForm",
      required: true,
    },
    programName: { type: String, required: true },
    programCode: { type: String, required: true },
    compulsorySubject: { type: String, required: true },
    combinationSubject: [
      {
        subjectCode: { type: String },
        preference: { type: Number },
      },
    ],
    academicYear: { type: String },
    uanNumber: { type: String },
    personalDetails: {
      aadharNumber: { type: String, maxlength: 12, minlength: 12 },
      govPorEnrollNumber: { type: String },
      firstName: { type: String },
      lastName: { type: String },
      fatherName: { type: String },
      motherName: { type: String },
      placeOfBirth: { type: String },
      dateOfBirth: { type: String },
      motherTongue: { type: String },
      category: { type: String },
      bloodGroup: { type: String },
      nationality: { type: String },
      religion: { type: String },
      gender: { type: String },
      maritalStatus: { type: String },
      caste: { type: String },
      subCaste: { type: String },
    },
    contactDetails: {
      mobile: { type: String, maxlength: 10, minlength: 10 },
      parentMobile: { type: String, maxlength: 10, minlength: 10 },
      parentEmail: { type: String },
      district: { type: String },
      address: { type: String },
      pinCode: { type: String, maxlength: 6, minlength: 6 },
      state: { type: String },
    },
    academicDetails: {
      matricEducation: {
        boardName: { type: String },
        schoolName: { type: String },
        passingDate: { type: String },
        isGrade: { type: String },
        score: { type: String },
        seatNumber: { type: Number },
        obtainedMarks: { type: Number },
        totalMarks: { type: Number },
      },
      intermediateEducation: {
        boardName: { type: String },
        schoolName: { type: String },
        passingDate: { type: String },
        isGrade: { type: String },
        score: { type: String },
        seatNumber: { type: Number },
        obtainedMarks: { type: Number },
        totalMarks: { type: Number },
      },
      bachelorsDegree: {
        yearOfPassing: { type: String },
        instituteName: { type: String },
        degreeTitle: { type: String },
        yearsOffered: { type: String },
        sem1stScore: { type: String },
        sem2ndScore: { type: String },
        CGPA: { type: String },
        obtainOutOf: { type: String },
      },
      otherDegree: {
        yearOfPassing: { type: String },
        instituteName: { type: String },
        degreeTitle: { type: String },
        percentage: { type: String },
      },
    },
    jcAcademicDetails: {
      examName: { type: String },
      boardName: { type: String },
      schoolName: { type: String },
      passingDate: { type: String },
      seatNumber: { type: Number },
      totalMarks: { type: Number },
      obtainedMarks: { type: Number },
      percentage: { type: Number },
    },
    legalDetails: {
      domicile: { type: String },
      parentOccupation: { type: String },
      annualIncome: { type: Number },
      reservationInformation: { type: String },
      sikhMinority: { type: Boolean },
      parentAddress: { type: String },
      parentMobile: { type: String, maxlength: 10, minlength: 10 },
    },
    declaration: {
      place: { type: String },
      date: { type: String },
      termsCondition: { type: Boolean },
    },
    mandatoryDocuments: {
      signature: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
      photo: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
    },
    jcMandatoryDocuments: {
      xLeavingCertificate: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
      xMarksheet: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
      aadharCard: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
      signature: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
      photo: {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
      },
    },
    otherDocuments: [
      {
        documentName: { type: String },
        url: { type: String },
        submitted: { type: Boolean },
        valid: { type: Boolean },
        message: { type: String },
        isMandatory: { type: Boolean, default: false },
      },
    ],
    inReview: { type: Boolean, default: false },
    reviewedPerson: { type: String },
    applicationReviewRound: { type: String, default: "WAITLIST" },
    inScrutiny: { type: Boolean, default: false },
    scrutinizedPerson: { type: String },
    applicationScrutinyRound: { type: String, default: "WAITLIST" },
    isAllocatedSubjects: { type: Boolean, default: false },
    allocatedSubjects: {
      compulsorySubject: { type: String },
      combinationSubjects: { type: String },
      combinationSubjectsId: { type: String },
    },
    isAllocatedBy: { type: String },
    verificationRound: { type: String, default: "WAITLIST" },
    verificationRoundPerson: { type: String },
    meritListCandidate: { type: String, default: "not considered" },
    inMeritList: { type: Boolean, default: false },
    denyReason: { type: String },
    denyPerson: { type: String },
    additionalDocs: [
      {
        documentName: { type: String },
        documentType: { type: String },
        priority: { type: Boolean },
        emailCommunication: { type: Boolean, default: true },
        smsCommunication: { type: Boolean, default: false },
        messageTemplate: { type: String },
      },
    ],
    isGeneratedList: { type: Boolean, required: true, default: false },
    isPublishedList: { type: Boolean, required: true, default: false },
    META: {
      TAGS: [{ type: String }],
      FEE_STRUCTURE: { type: String },
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const ApplicationForm = model<applicationFormDocument>(
  "applicationForm",
  applicationFormSchema
);

export { ApplicationForm };
