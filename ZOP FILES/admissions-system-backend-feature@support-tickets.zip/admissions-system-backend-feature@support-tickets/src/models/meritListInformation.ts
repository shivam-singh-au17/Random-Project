import { Schema, model, Document } from "mongoose";

interface meritListInformationDocument extends Document {
  name: string;
  number: number;
  branch: string;
  department: string;
  generatedDate: string;
  publishDate: string;
  programName: string;
  yearAppliedFor: string;
  programCode: string;
  selectedStudents: string[];
  publishMeritListPerson: string;
  meritListStatus: string;
  emailSendingStatus: boolean;
}

const meritListInformationSchema = new Schema(
  {
    name: { type: String, required: true },
    number: { type: Number, required: true },
    branch: { type: String, required: true },
    department: { type: String, required: true },
    generatedDate: { type: String, required: true },
    publishDate: { type: String },
    programName: { type: String, required: true },
    yearAppliedFor: { type: String, required: true },
    programCode: { type: String, required: true },
    selectedStudents: [
      {
        type: Schema.Types.ObjectId,
        ref: "applicationForm",
        required: true,
      },
    ],
    publishMeritListPerson: { type: String, required: true },
    meritListStatus: { type: String, required: true, default: "GENERATED" },
    emailSendingStatus: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const MeritListInformation = model<meritListInformationDocument>(
  "meritListInformation",
  meritListInformationSchema
);

export { MeritListInformation };
