import { Schema, model, Document } from "mongoose";

interface selectHeads {
  [key: string]: Record<string, object | string | number>;
}

interface META {
  TAGS: string[];
}

interface feeStructureCodesDocument extends Document {
  name: string;
  collegeType: string;
  categoryType: string;
  programName: string;
  departmentName: string;
  yearAppliedFor: string;
  _id: string;
  selectHeads: selectHeads[];
  META: META;
}

const feeStructureCodesSchema = new Schema(
  {
    name: { type: String, required: true },
    collegeType: { type: String, required: true },
    categoryType: {
      type: Schema.Types.ObjectId,
      ref: "category",
      required: true,
    },
    programName: {
      type: Schema.Types.ObjectId,
      ref: "attachProgramCodes",
      required: true,
    },
    departmentName: {
      type: Schema.Types.ObjectId,
      ref: "attachDepartmentCodes",
      required: true,
    },
    yearAppliedFor: { type: String, required: true, max: 3 },
    selectHeads: [
      {
        selectedHeads: {
          type: Schema.Types.ObjectId,
          ref: "feeHead",
          required: true,
        },
        amount: { type: Number, required: true },
      },
    ],
    META: {
      TAGS: [{ type: String }],
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const FeeStructureCodes = model<feeStructureCodesDocument>(
  "feeStructureCodes",
  feeStructureCodesSchema
);

export {
  FeeStructureCodes,
  feeStructureCodesSchema,
  feeStructureCodesDocument,
};
