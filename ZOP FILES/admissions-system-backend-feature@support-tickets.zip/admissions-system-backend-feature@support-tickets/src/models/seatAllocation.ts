import { Schema, model, Document } from "mongoose";

interface commanCombination {
  subjectName: string;
  totalSeat: number;
  allocatedSeat: number;
  provisionalSeat: number;
  minProvisionalSeat: number;
  isAvailable: boolean;
  _id: string;
}

interface compulsorySubject {
  subjectName: string;
  _id: string;
}

interface singleCombinationSubject {
  subjectCombinationName: string;
  subjectCombinationIds: string[];
  _id: string;
}

interface seatAllocationDocument extends Document {
  programName: string;
  yearAppliedFor: string;
  isSemesterExam: boolean;
  isSubjectGroup: boolean;
  allSingleSubjectList: commanCombination[];
  groupCombinationSubject: commanCombination[];
  singleCombinationSubject: singleCombinationSubject[];
  compulsorySubject: compulsorySubject[];
  _id: string;
}

const seatAllocation = new Schema(
  {
    programName: { type: String },
    yearAppliedFor: { type: String },
    isSemesterExam: { type: Boolean },
    isSubjectGroup: { type: Boolean },
    allSingleSubjectList: [
      {
        subjectName: { type: String },
        totalSeat: { type: Number },
        allocatedSeat: { type: Number },
        provisionalSeat: { type: Number },
        minProvisionalSeat: { type: Number },
        isAvailable: { type: Boolean },
      },
    ],
    groupCombinationSubject: [
      {
        subjectName: { type: String },
        totalSeat: { type: Number },
        allocatedSeat: { type: Number },
        provisionalSeat: { type: Number },
        minProvisionalSeat: { type: Number },
        isAvailable: { type: Boolean },
      },
    ],
    singleCombinationSubject: [
      {
        subjectCombinationName: { type: String },
        subjectCombinationIds: [{ type: String }],
      },
    ],
    compulsorySubject: [
      {
        subjectName: { type: String },
      },
    ],
  },
  {
    versionKey: false,
  }
);

const SeatAllocation = model<seatAllocationDocument>(
  "seatAllocation",
  seatAllocation
);

export { SeatAllocation };
