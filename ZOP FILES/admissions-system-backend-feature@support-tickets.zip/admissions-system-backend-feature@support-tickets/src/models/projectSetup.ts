import { Document, model, Schema } from "mongoose";

interface team {
  email: string;
  role: string;
}

interface projectSetupDocument extends Document {
  projectFullName: string;
  projectShortName: string;
  attachProgram: string;
  applicableYear: string;
  academicYear: string;
  eligibility: string[];
  reservation: string[];
  feeStructure: string[];
  seats: number[];
  subjectDict: string[];
  subjectBundles: string[];
  status: boolean;
  team: team;
}

const projectSetupSchema = new Schema(
  {
    projectFullName: { type: String, required: true },
    projectShortName: { type: String, required: true },
    attachProgram: {
      type: Schema.Types.ObjectId,
      ref: "attachProgramCodes",
      required: true,
    },
    applicableYear: { type: String, required: true },
    academicYear: { type: String, required: true },
    eligibility: [{ type: String, required: true }],
    reservation: [{ type: String, required: true }],
    feeStructure: [
      {
        type: Schema.Types.ObjectId,
        ref: "feeStructureCodes",
        required: true,
      },
    ],
    seats: [{ type: Number, required: true }],
    subjectDict: [{ type: String, required: true }],
    subjectBundles: [{ type: String, required: true }],
    status: { type: String, required: true },
    team: [
      {
        email: { type: String, required: true },
        role: { type: String, required: true },
      },
    ],
  },
  {
    versionKey: false,
  }
);

const ProjectSetup = model<projectSetupDocument>(
  "projectSetup",
  projectSetupSchema
);

export { ProjectSetup };
