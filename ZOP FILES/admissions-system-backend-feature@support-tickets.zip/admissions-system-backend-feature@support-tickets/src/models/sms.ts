import { Schema, model, Document } from "mongoose";

interface smsDocument extends Document {
  addUrl: string;
  addNumber: string;
  user: string;
}

const smsSchema = new Schema(
  {
    addUrl: { type: String, required: true },
    addNumber: { type: String, required: true },
    user: { type: String, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const Sms = model<smsDocument>("sms", smsSchema);

export { Sms };
