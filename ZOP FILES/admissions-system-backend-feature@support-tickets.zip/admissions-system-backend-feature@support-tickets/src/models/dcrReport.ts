import mongoose, { Schema } from "mongoose";

// Head Type
type HEAD = {
  [key: string]: string | number;
};

// Output Document Type
interface DcrReportDoc {
  "INVOICE NO": string;
  // "COLLEGE NAME": string;
  "TYPE OF COLLEGE": string;
  "REPORT CATEGORY": string;
  TOTAL: number;
  HEADS: HEAD[];
  DATE: string;
}
// Schema Attr Type
interface DcrReportAttr {
  "INVOICE NO": string;
  // "COLLEGE NAME": string;
  "TYPE OF COLLEGE": string;
  "REPORT CATEGORY": string;
  TOTAL: number;
  HEADS: HEAD[];
}
// attaching build object on model
interface DcrModel extends mongoose.Model<DcrReportDoc> {
  build(attr: DcrReportAttr): DcrReportDoc;
}

// Schema Design
const DcrSchema: any = new Schema(
  {
    ["INVOICE NO"]: {
      type: String,
      required: true,
    },
    // ["COLLEGE NAME"]: {
    //   type: String,
    //   required: true,
    // },
    ["TYPE OF COLLEGE"]: {
      type: String,
      required: true,
    },
    ["REPORT CATEGORY"]: {
      type: String,
      required: true,
    },
    TOTAL: {
      type: Number,
      required: true,
    },
    HEADS: [],
  },
  {
    timestamps: true,
    toObject: {
      transform: function (doc, ret) {
        ret["INVOICE ID"] = ret._id;
        const date = new Date();
        const dateformat = `${date.getDate()}-${date.getMonth()}-${date.getFullYear()}`;
        ret.DATE = dateformat;
      },
    },
  }
);

// Schema Statics & Advance
DcrSchema.statics.build = (attrs: DcrReportAttr) => {
  return new DCR(attrs);
};
const DCR = mongoose.model<DcrReportDoc, DcrModel>("DCR", DcrSchema);

// Model & Export
export { DCR };
