import { Schema, model, Document } from "mongoose";
import moment from "moment-timezone";
import bcrypt from "bcrypt";

interface registrationFormDocument extends Document {
  registrationNo: string;
  applicationNo: string;
  joined: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phoneNumber: string;
  picture: string;
  emailUpdates: boolean;
  smsUpdates: boolean;
}

const registrationFormSchema = new Schema(
  {
    registrationNo: { type: String, required: true },
    applicationNo: { type: String },
    joined: {
      type: String,
      required: true,
      default: moment().format("Do MMMM YYYY"),
    },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, maxlength: 20, minlength: 8 },
    phoneNumber: { type: String, maxlength: 10, minlength: 10 },
    picture: { type: String },
    emailUpdates: { type: Boolean },
    smsUpdates: { type: Boolean },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

registrationFormSchema.pre("save", function (next) {
  if (!this.isModified("password")) {
    return next();
  }

  bcrypt.hash(this.password, 10, (err, hash) => {
    if (err) {
      return next(err);
    }
    this.password = hash;
    next();
  });
});

const RegistrationFormService = model<registrationFormDocument>(
  "registrationForm",
  registrationFormSchema
);

export { RegistrationFormService };
