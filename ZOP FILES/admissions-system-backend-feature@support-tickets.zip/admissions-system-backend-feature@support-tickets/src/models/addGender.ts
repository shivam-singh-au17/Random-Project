import { Schema, model, Document } from "mongoose";

interface addGenderDocument extends Document {
  addGender: string;
  status: boolean;
}

const addGenderSchema = new Schema(
  {
    addGender: { type: String, required: true },
    status: { type: Boolean, required: true, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const AddGender = model<addGenderDocument>(
  "addGender",
  addGenderSchema
);

export { AddGender };
