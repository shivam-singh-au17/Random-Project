import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const candidatesForms: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      formSubmitted: true,
      inReview: false,
      inScrutiny: false,
      isAllocatedSubjects: false,
      inMeritList: false,
    })
      .select(
        "candidateId formNo prnNumber programName programCode academicYear yearAppliedFor preferenceArray personalDetails contactDetails academicDetails legalDetails dateAppliedOn"
      )
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { candidatesForms };
