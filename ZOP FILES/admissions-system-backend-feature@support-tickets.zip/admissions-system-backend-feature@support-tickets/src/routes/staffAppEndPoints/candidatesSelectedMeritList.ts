import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const candidatesSelectedMeritList: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      inMeritList: true,
      isGeneratedList: false,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { candidatesSelectedMeritList };
