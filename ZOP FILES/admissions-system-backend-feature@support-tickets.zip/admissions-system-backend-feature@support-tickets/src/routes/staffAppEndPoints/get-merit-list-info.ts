import { MeritListInformation } from "../../models/meritListInformation";
import { RequestHandler } from "express";

const getMeritListInfo: RequestHandler = async (req, res, next) => {
  try {
    const item = await MeritListInformation.find()
      .populate({
        path: "selectedStudents",
        model: "applicationForm",
        select:
          "formNo programName yearAppliedFor academicYear personalDetails.aadharNumber personalDetails.firstName personalDetails.lastName contactDetails.mobile",
        populate: [
          {
            path: "candidateId",
            model: "registrationForm",
            select: "email picture",
          },
        ],
      })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getMeritListInfo };
