import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  updateReviewStatus: Joi.object({
    formIdArray: Joi.array().required(),
    adminEmail: Joi.string().email({ minDomainSegments: 2 }),
    inReview: Joi.boolean().required(),
    reviewedPerson: Joi.string().required().email({ minDomainSegments: 2 }),
  }),

  updateScrutinyStatus: Joi.object({
    inScrutiny: Joi.boolean().required(),
    scrutinizedPerson: Joi.string().required().email({ minDomainSegments: 2 }),
  }),

  allocateDepartment: Joi.object({
    isAllocatedSubjects: Joi.boolean().required(),
    allocatedSubjects: Joi.object({
      compulsorySubject: Joi.string().required(),
      combinationSubjects: Joi.string().required(),
      combinationSubjectsId: Joi.string().required(),
    }).required(),
    isAllocatedBy: Joi.string().required().email({ minDomainSegments: 2 }),
  }),

  updateMeritListStatus: Joi.object({
    formIdArray: Joi.array().required(),
    verificationRoundPerson: Joi.string()
      .required()
      .email({ minDomainSegments: 2 }),
  }),

  candidatesMaintainMeritList: Joi.object({
    inMeritList: Joi.boolean().required(),
  }),

  candidateGenerateMeritList: Joi.object({
    name: Joi.string().required(),
    number: Joi.number().required(),
    branch: Joi.string().required(),
    department: Joi.string().required(),
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    programCode: Joi.string().required(),
    selectedStudents: Joi.array().required(),
    publishMeritListPerson: Joi.string()
      .required()
      .email({ minDomainSegments: 2 }),
  }),

  candidatePublishMeritList: Joi.object({
    publishDate: Joi.string().required(),
  }),

  additionalDocs: Joi.object({
    documentName: Joi.string().required(),
    documentType: Joi.string().required(),
    priority: Joi.boolean().required(),
    emailCommunication: Joi.boolean(),
    smsCommunication: Joi.boolean(),
    messageTemplate: Joi.string().required(),
  }),

  denyForm: Joi.object({
    denyReason: Joi.string().required(),
    denyPerson: Joi.string().required().email({ minDomainSegments: 2 }),
  }),
};

const updateReviewStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateReviewStatus, req.body, next);

const updateScrutinyStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateScrutinyStatus, req.body, next);

const allocateDepartmentValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.allocateDepartment, req.body, next);

const updateMeritListStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateMeritListStatus, req.body, next);

const candidatesMaintainMeritListValidation: RequestHandler = (req,res,next) =>
  validateParams(validationSchema.candidatesMaintainMeritList, req.body, next);

const candidateGenerateMeritListValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.candidateGenerateMeritList, req.body, next);

const candidatePublishMeritListValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.candidatePublishMeritList, req.body, next);

const additionalDocsValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.additionalDocs, req.body, next);

const denyFormValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.denyForm, req.body, next);

export {
  updateReviewStatusValidation,
  updateScrutinyStatusValidation,
  allocateDepartmentValidation,
  updateMeritListStatusValidation,
  candidatesMaintainMeritListValidation,
  candidateGenerateMeritListValidation,
  candidatePublishMeritListValidation,
  additionalDocsValidation,
  denyFormValidation,
};
