import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const reviewedCandidates: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      inReview: true,
      applicationReviewRound: "PASS",
      inScrutiny: false,
      verificationRound: "WAITLIST",
      isAllocatedSubjects: false,
      inMeritList: false,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { reviewedCandidates };
