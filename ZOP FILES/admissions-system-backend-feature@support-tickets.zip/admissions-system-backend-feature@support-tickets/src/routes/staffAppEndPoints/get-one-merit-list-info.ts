import { MeritListInformation } from "../../models/meritListInformation";
import { RequestHandler } from "express";

const getOneMeritListInfo: RequestHandler = async (req, res, next) => {
  try {
    const item = await MeritListInformation.findById(req.params.id)
      .populate({
        path: "selectedStudents",
        select: "formNo programName yearAppliedFor",
      })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneMeritListInfo };
