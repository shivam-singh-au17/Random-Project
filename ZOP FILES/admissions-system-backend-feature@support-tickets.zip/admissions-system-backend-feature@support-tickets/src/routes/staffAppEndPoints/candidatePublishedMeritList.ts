import { RequestHandler } from "express";
import _ from "lodash";
import moment from "moment-timezone";
import cron from "node-cron";
import nodemailer from "nodemailer";
import hbs from "nodemailer-express-handlebars";
import path from "path";

import { mailPass, mailService, mailUser, senderAddress } from "../../config";
import { ApplicationForm } from "../../models/applicationForm";
import { MeritListInformation } from "../../models/meritListInformation";

const mainPublishStudent = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

mainPublishStudent.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/staffAppEndPoints/publishUserViews"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/staffAppEndPoints/publishUserViews"
    ),
  })
);

const candidatePublishedMeritList: RequestHandler = async (req, res, next) => {
  try {
    const check = moment(`${req.body.publishDate}`, "DD/MM/YYYY");
    const month = check.format("MMMM");
    const date = check.format("D");
    const day = check.format("dddd");

    const nowDate = moment().format("DD/MM/YYYY");
    const dateCheck = nowDate === req.body.publishDate;

    if (moment(req.body.publishDate, "DD/MM/YYYY", true).isValid() === true) {
      req.body.emailSendingStatus = true;
      req.body.meritListStatus = "PUBLISHED";
      const item = await MeritListInformation.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );

      if (item !== null) {
        const itemData = await MeritListInformation.findById(item._id)
          .populate({
            path: "selectedStudents",
            model: "applicationForm",
            select: "formNo programName yearAppliedFor academicYear",
            populate: [
              {
                path: "candidateId",
                model: "registrationForm",
                select: "email picture",
              },
            ],
          })
          .lean()
          .exec();

        if (itemData !== null) {
          const allSelected = itemData.selectedStudents;

          for (let i = 0; i < allSelected.length; i++) {
            const oneItem: any = allSelected[i];

            await ApplicationForm.findByIdAndUpdate(
              oneItem._id,
              {
                isPublishedList: true,
                stepCounter: 4,
              },
              { new: true }
            );

            const sendMailStudent = {
              from: `${senderAddress} <${mailUser}>`,
              to: `${oneItem.candidateId.email}`,
              subject: "Congratulations | You Are Selected For The Merit List",
              template: "publishUserViews",
              context: {
                formNo: oneItem.formNo,
                programName: oneItem.programName,
                academicYear: oneItem.academicYear,
                yearAppliedFor: oneItem.yearAppliedFor,
                studentPicture: oneItem.candidateId.picture,
              },
            };

            if (dateCheck === true) {
              mainPublishStudent.sendMail(
                sendMailStudent,
                function (error, info) {
                  if (error) {
                    return console.log(error);
                  }
                  console.log("Message sent to Student: " + info.response);
                }
              );
            }
            cron.schedule(
              `1 1 ${date} ${month} ${day}`,
              () => {
                mainPublishStudent.sendMail(
                  sendMailStudent,
                  function (error, info) {
                    if (error) {
                      return console.log(error);
                    }
                    console.log("Message sent to Student: " + info.response);
                  }
                );
              },
              {
                scheduled: item.emailSendingStatus,
                timezone: "Asia/Kolkata",
              }
            );
          }
        }

        // perform continuous payment history attachment.
        const selectedCandidateIds = () => {
          const candidates: string[] = [];
          _.forEach(itemData?.selectedStudents, (candidateDetails) =>
            //     candidateDetails.
            candidates.push(
              _.get(candidateDetails, ["candidateId", "_id"]) as string
            )
          );
          return candidates;
        };
        // attach payment on user payment history to all selected merit list students.
        const attachPaymentHistoryBody = {
          feeStructureName: itemData?.programCode,
          user_id: selectedCandidateIds(),
        };

        req.body = attachPaymentHistoryBody;
      }
      // assert new payment to all candidate account.
      next();
    } else {
      return res.status(400).send({
        status: "Error",
        message: "The given date is not correct OR its format is not correct.",
      });
    }
  } catch (error) {
    return next(error);
  }
};

export { candidatePublishedMeritList };
