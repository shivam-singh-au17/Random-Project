import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const candidatesDemoteMeritList: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();
    if (formData !== null) {
      if (
        formData.verificationRound === "PASS" &&
        formData.meritListCandidate === "considered" &&
        formData.isAllocatedSubjects === true
      ) {
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          {
            verificationRound: "WAITLIST",
            meritListCandidate: "not considered",
            inMeritList: false,
          },
          { new: true }
        );
        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Eroor",
          message:
            "You can only demote those students who have passed the verification round.",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { candidatesDemoteMeritList };
