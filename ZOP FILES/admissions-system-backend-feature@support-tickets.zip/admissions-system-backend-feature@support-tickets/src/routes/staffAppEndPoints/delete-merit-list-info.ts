import { MeritListInformation } from "../../models/meritListInformation";
import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const deleteMeritListInfo: RequestHandler = async (req, res, next) => {
  try {
    const itemData = await MeritListInformation.findById(req.params.id)
      .lean()
      .exec();

    if (itemData !== null) {
      if (itemData.meritListStatus !== "GENERATED") {
        return res.status(400).send({
          status: "Error",
          message: "You can only delete merit lists whose status is GENERATED",
        });
      }

      const selectedData = itemData.selectedStudents;

      for (let i = 0; i < selectedData.length; i++) {
        const oneItem = selectedData[i];
        await ApplicationForm.findByIdAndUpdate(
          oneItem,
          {
            inMeritList: false,
            isGeneratedList: false,
          },
          {
            new: true,
          }
        );
      }

      const item = await MeritListInformation.findByIdAndDelete(req.params.id);
      return res.status(200).send(item);
    }
  } catch (error) {
    return next(error);
  }
};

export { deleteMeritListInfo };
