import { ApplicationForm } from "../../models/applicationForm";
import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const deallocateSubject: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();
    if (formData !== null) {
      if (formData.isAllocatedSubjects === true) {
        const seatCheck = await SeatAllocation.findOne({
          programName: formData.programName,
          yearAppliedFor: formData.yearAppliedFor,
        })
          .lean()
          .exec();

        if (seatCheck === null) {
          return res.status(400).send({
            status: "Error",
            message: "No seats have been allocated for this program!",
          });
        }

        if (seatCheck.isSubjectGroup === true) {
          const seatItem = await SeatAllocation.find(
            {
              $and: [
                { programName: formData.programName },
                { yearAppliedFor: formData.yearAppliedFor },
                {
                  "groupCombinationSubject._id":
                    formData.allocatedSubjects.combinationSubjectsId,
                },
              ],
            },
            {
              "groupCombinationSubject.$": 1,
            }
          )
            .lean()
            .exec();

          if (seatItem[0] === undefined) {
            return res.status(400).send({
              status: "Error",
              message: "No data found for combinationSubjectsId!",
            });
          }

          const provisionalSeatData =
            seatItem[0].groupCombinationSubject[0].provisionalSeat !== undefined
              ? seatItem[0].groupCombinationSubject[0].provisionalSeat
              : 0;

          await SeatAllocation.updateOne(
            {
              _id: seatItem[0]._id,
              "groupCombinationSubject._id":
                seatItem[0].groupCombinationSubject[0]._id,
            },
            {
              $set: {
                "groupCombinationSubject.$.provisionalSeat":
                  provisionalSeatData - 1,
              },
            }
          );
        }

        if (seatCheck.isSubjectGroup === false) {
          const singleSeatItem = await SeatAllocation.find(
            {
              $and: [
                { programName: formData.programName },
                { yearAppliedFor: formData.yearAppliedFor },
                {
                  "singleCombinationSubject._id":
                    formData.allocatedSubjects.combinationSubjectsId,
                },
              ],
            },
            {
              "singleCombinationSubject.$": 1,
            }
          )
            .lean()
            .exec();

          if (singleSeatItem[0] === undefined) {
            return res.status(400).send({
              status: "Error",
              message: "No data found for combinationSubjectsId!",
            });
          }

          const allSubject =
            singleSeatItem[0].singleCombinationSubject[0].subjectCombinationIds;

          for (let i = 0; i < allSubject.length; i++) {
            const oneItem = allSubject[i];

            const seatItemSingle = await SeatAllocation.find(
              {
                $and: [
                  { programName: formData.programName },
                  { yearAppliedFor: formData.yearAppliedFor },
                  {
                    "allSingleSubjectList._id": oneItem,
                  },
                ],
              },
              {
                "allSingleSubjectList.$": 1,
              }
            )
              .lean()
              .exec();

            const provisionalSeatSingleData =
              seatItemSingle[0].allSingleSubjectList[0].provisionalSeat !==
              undefined
                ? seatItemSingle[0].allSingleSubjectList[0].provisionalSeat
                : 0;

            await SeatAllocation.updateOne(
              {
                _id: seatItemSingle[0]._id,
                "allSingleSubjectList._id":
                  seatItemSingle[0].allSingleSubjectList[0]._id,
              },
              {
                $set: {
                  "allSingleSubjectList.$.provisionalSeat":
                    provisionalSeatSingleData - 1,
                },
              }
            );
          }
        }

        await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          {
            allocatedSubjects: {},
            isAllocatedSubjects: false,
          },
          {
            new: true,
          }
        );

        return res.status(200).send({ status: "success" });
      } else {
        return res.status(400).send({
          status: "Not authorized",
          message:
            "Application Form has not passed the isAllocatedSubjects Round",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { deallocateSubject };
