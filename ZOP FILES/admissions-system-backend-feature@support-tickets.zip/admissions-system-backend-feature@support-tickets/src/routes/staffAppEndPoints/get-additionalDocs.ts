import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const getAllAdditionalDocs: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.findById(req.params.form_id)
      .lean()
      .exec();
    if (item !== null) {
      return res.status(200).send(item.additionalDocs);
    }
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAllAdditionalDocs };
