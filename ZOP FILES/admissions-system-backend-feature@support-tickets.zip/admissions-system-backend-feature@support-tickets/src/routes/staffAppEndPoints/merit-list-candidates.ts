import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const meritListCandidates: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      verificationRound: "PASS",
      meritListCandidate: "considered",
      inMeritList: false,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { meritListCandidates };
