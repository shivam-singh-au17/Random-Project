import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const mainAdmin = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

mainAdmin.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/staffAppEndPoints/adminViews"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/staffAppEndPoints/adminViews"
    ),
  })
);

const updateReviewStatus: RequestHandler = async (req, res, next) => {
  try {
    const dataArr = req.body.formIdArray;
    const adminEmailData = req.body.adminEmail;

    for (let i = 0; i < dataArr.length; i++) {
      const oneItem = dataArr[i];
      const formData = await ApplicationForm.findById(oneItem).lean().exec();

      if (formData !== null) {
        if (formData.formSubmitted === true) {
          await ApplicationForm.findByIdAndUpdate(
            oneItem,
            {
              "mandatoryDocuments.signature.valid": true,
              "mandatoryDocuments.photo.valid": true,
              inReview: req.body.inReview,
              reviewedPerson: req.body.reviewedPerson,
              applicationReviewRound: "PASS",
            },
            {
              new: true,
            }
          );
        }
      }
    }

    if (adminEmailData !== undefined) {
      const allData = await ApplicationForm.find({
        inReview: true,
        applicationReviewRound: "PASS",
      })
        .lean()
        .exec();

      const sendMailAdmin = {
        from: `${senderAddress} <${mailUser}>`,
        to: `${adminEmailData}`,
        subject: "With regard to students passing the Review phase",
        template: "adminTemplate",
        context: {
          programName: allData[0].programName,
          academicYear: allData[0].academicYear,
          yearAppliedFor: allData[0].yearAppliedFor,
          studentCount: allData.length,
        },
      };

      mainAdmin.sendMail(sendMailAdmin, function (error, info) {
        if (error) {
          return console.log(error);
        }
        console.log("Message sent to Admin: " + info.response);
      });
    }

    return res.status(200).send({ status: "success" });
  } catch (error) {
    return next(error);
  }
};

export { updateReviewStatus };
