import { ApplicationForm } from "../../models/applicationForm";
import { MeritListInformation } from "../../models/meritListInformation";
import { RequestHandler } from "express";
import moment from "moment-timezone";

const candidateGenerateMeritList: RequestHandler = async (req, res, next) => {
  try {
    const dataArr = req.body.selectedStudents;
    const newDataArr: string[] = [];

    for (let i = 0; i < dataArr.length; i++) {
      const oneItem = dataArr[i];
      const formData = await ApplicationForm.findById(oneItem).lean().exec();

      if (formData !== null) {
        if (
          formData.verificationRound === "PASS" &&
          formData.meritListCandidate === "considered" &&
          formData.isGeneratedList === false &&
          formData.isPublishedList === false
        ) {
          await ApplicationForm.findByIdAndUpdate(
            formData._id,
            {
              isGeneratedList: true,
            },
            { new: true }
          );
          newDataArr.push(oneItem);
        }
      }
    }

    if (newDataArr[0] === undefined) {
      return res.status(400).send({
        status: "Error",
        message:
          "At least one student must be selected to generate the merit list OR You cannot generate students selected in one merit list in another merit list.",
      });
    }
    req.body.selectedStudents = newDataArr;
    req.body.generatedDate = moment()
      .tz("Asia/Kolkata")
      .format("DD/MM/YYYY - h:mm:ss A");

    const item = await MeritListInformation.create(req.body);

    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { candidateGenerateMeritList };
