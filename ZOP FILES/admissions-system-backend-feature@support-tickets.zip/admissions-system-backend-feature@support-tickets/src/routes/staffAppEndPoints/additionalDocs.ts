import { ApplicationForm } from "../../models/applicationForm";
import { RegistrationFormService } from "../../models/registrationForm";
import { RequestHandler } from "express";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const mainAdditionalDocs = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

mainAdditionalDocs.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/staffAppEndPoints/additionalDocsViews"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/staffAppEndPoints/additionalDocsViews"
    ),
  })
);

const additionalDocs: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.form_id)
      .lean()
      .exec();

    if (formData !== null) {
      if (formData.inReview === true) {
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.form_id,
          { $push: { additionalDocs: req.body } },
          { new: true }
        );

        const tempEmail = formData.candidateId;
        const itemEmail = await RegistrationFormService.findById(tempEmail)
          .lean()
          .exec();

        if (itemEmail !== null) {
          const studentEmail = itemEmail.email;

          if (req.body.emailCommunication === true) {
            const sendAdditionalDocs = {
              from: `${senderAddress} <${mailUser}>`,
              to: `${studentEmail}`,
              subject: `Additional Documents Required | ${req.body.documentName}`,
              template: "additionalDocsTemplate",
              context: {
                studentName: `${itemEmail.firstName} ${itemEmail.lastName}`,
                documentName: req.body.documentName,
                documentType: req.body.documentType,
                priority: req.body.priority,
                messageTemplate: req.body.messageTemplate,
              },
            };

            mainAdditionalDocs.sendMail(
              sendAdditionalDocs,
              function (error, info) {
                if (error) {
                  return console.log(error);
                }
                console.log("Message sent to Student: " + info.response);
              }
            );
          }
        }

        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Not authorized",
          message:
            "This student's form has not been reviewed, please review it first.",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { additionalDocs };
