import express from "express";

import { assertNewPaymentToPaymentHistory } from "../../controllers/payments/assert-payment-history";
import { additionalDocs } from "./additionalDocs";
import { allocateDepartment } from "./allocate-department";
import { candidateGenerateMeritList } from "./candidateGenerateMeritList";
import { candidatePublishedMeritList } from "./candidatePublishedMeritList";
import { candidatesForms } from "./candidates";
import { candidatesDemoteMeritList } from "./candidatesDemoteMeritList";
import { candidatesMaintainMeritList } from "./candidatesMaintainMeritList";
import { candidatesSelectedMeritList } from "./candidatesSelectedMeritList";
import { deleteMeritListInfo } from "./delete-merit-list-info";
import { denyForm } from "./deny-form";
import { getAllAdditionalDocs } from "./get-additionalDocs";
import { getMeritListInfo } from "./get-merit-list-info";
import { getOneMeritListInfo } from "./get-one-merit-list-info";
import { meritListCandidates } from "./merit-list-candidates";
import { reviewedCandidates } from "./reviewed-candidates";
import { scrutinizedCandidates } from "./scrutinized-candidates";
import { updateMeritListStatus } from "./update-merit-list-status";
import { updateReviewStatus } from "./update-review-status";
import { updateScrutinyStatus } from "./update-scrutiny-status";
import { deallocateSubject } from "./deallocateSubject";
import { additionalDocsValidation, allocateDepartmentValidation, candidateGenerateMeritListValidation, candidatePublishMeritListValidation, candidatesMaintainMeritListValidation, denyFormValidation, updateMeritListStatusValidation, updateReviewStatusValidation, updateScrutinyStatusValidation } from "./validation";

const router = express.Router();

router.get("/candidates/", candidatesForms);

router.patch(
  "/candidates/update-review-status",
  updateReviewStatusValidation,
  updateReviewStatus
);

router.get("/reviewed-candidates/", reviewedCandidates);

router.patch(
  "/candidates/update-scrutiny-status/:id",
  updateScrutinyStatusValidation,
  updateScrutinyStatus
);

router.get("/scrutinized-candidates/", scrutinizedCandidates);

router.patch(
  "/candidates/allocate-department/:id",
  allocateDepartmentValidation,
  allocateDepartment
);

router.patch("/candidates/deallocate/subject/:id", deallocateSubject);

router.patch(
  "/candidates/update-merit-list-status/",
  updateMeritListStatusValidation,
  updateMeritListStatus
);

router.get("/merit-list-candidates/", meritListCandidates);

router.patch(
  "/candidates/merit-list/maintain/:id",
  candidatesMaintainMeritListValidation,
  candidatesMaintainMeritList
);

router.patch("/candidates/merit-list/demote/:id", candidatesDemoteMeritList);

router.get("/candidates/merit-list/selected/", candidatesSelectedMeritList);

router.post(
  "/candidates/merit-list/generate/",
  candidateGenerateMeritListValidation,
  candidateGenerateMeritList
);

router.get("/get-merit-list-info/", getMeritListInfo);

// @ash
router.patch(
  "/candidates/merit-list/publish/:id",
  candidatePublishMeritListValidation,
  candidatePublishedMeritList,
  assertNewPaymentToPaymentHistory
);

router.get("/get-one-merit-list-info/:id", getOneMeritListInfo);

router.delete("/delete-merit-list-info/:id", deleteMeritListInfo);

router.patch(
  "/candidates/:form_id/additionalDocs/",
  additionalDocsValidation,
  additionalDocs
);

router.get("/candidates/:form_id/getAll-additionalDocs/", getAllAdditionalDocs);

router.patch("/candidates/:form_id/deny-form/", denyFormValidation, denyForm);

export { router as staffAppEndPoints };
