import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const updateScrutinyStatus: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();
    if (formData !== null) {
      if (
        formData.formSubmitted === true &&
        formData.inReview === true &&
        formData.mandatoryDocuments.signature.valid === true &&
        formData.mandatoryDocuments.photo.valid === true
      ) {
        const temp = formData.otherDocuments;
        for (let i = 0; i < temp.length; i++) {
          const oneItem = temp[i];
          if (
            oneItem.isMandatory === true &&
            (oneItem.valid === false ||
              oneItem.valid === undefined ||
              oneItem.valid === null)
          ) {
            return res.status(400).send({
              status: "Not authorized",
              message: "isMandatory document must be valid",
            });
          }
        }
        req.body.applicationScrutinyRound = "PASS";
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          req.body,
          { new: true }
        );
        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Not authorized",
          message: "First, submit the form, pay the fee and review the form",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { updateScrutinyStatus };
