import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const denyForm: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.form_id)
      .lean()
      .exec();

    if (formData !== null) {
      if (
        formData.inReview === true &&
        formData.inScrutiny === false &&
        formData.isAllocatedSubjects === false &&
        formData.inMeritList === false
      ) {
        req.body.inReview = false;
        req.body.applicationReviewRound = "WAITLIST";
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.form_id,
          req.body,
          { new: true }
        );

        if (item !== null) {
          return res.status(200).send({
            status: "Success",
            message: `Candidate Name : ${item.personalDetails.firstName} ${item.personalDetails.lastName} , Form Number : ${item.formNo} application has been put on hold. They will be removed from the curren admission cyle`,
          });
        }
      } else {
        return res.status(400).send({
          status: "Failed",
          message:
            "The form needs to be reviewed before deny AND The form has not progressed beyond the scrutiny round.",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field.");
    }
  } catch (error) {
    return next(error);
  }
};

export { denyForm };
