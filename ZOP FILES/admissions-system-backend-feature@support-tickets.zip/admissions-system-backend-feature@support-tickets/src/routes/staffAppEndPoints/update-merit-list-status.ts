import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const updateMeritListStatus: RequestHandler = async (req, res, next) => {
  try {
    const dataArr = req.body.formIdArray;

    for (let i = 0; i < dataArr.length; i++) {
      const oneItem = dataArr[i];
      const formData = await ApplicationForm.findById(oneItem).lean().exec();

      if (formData !== null) {
        if (formData.isAllocatedSubjects === true) {
          await ApplicationForm.findByIdAndUpdate(
            oneItem,
            {
              meritListCandidate: "considered",
              verificationRound: "PASS",
              verificationRoundPerson: req.body.verificationRoundPerson,
            },
            {
              new: true,
            }
          );
        }
      }
    }
    return res.status(200).send({ status: "success" });
  } catch (error) {
    return next(error);
  }
};

export { updateMeritListStatus };
