import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const candidatesMaintainMeritList: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();

    if (formData !== null) {
      if (
        formData.verificationRound === "PASS" &&
        formData.meritListCandidate === "considered"
      ) {
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          req.body,
          { new: true }
        );

        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Eroor",
          message:
            "You can select the students for the merit list only after passing the verification round.",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { candidatesMaintainMeritList };
