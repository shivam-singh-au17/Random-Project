import { BankAccount } from "../../models/bankAccount";
import { RequestHandler } from "express";

const getBankAccount: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await BankAccount.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await BankAccount.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getBankAccount };
