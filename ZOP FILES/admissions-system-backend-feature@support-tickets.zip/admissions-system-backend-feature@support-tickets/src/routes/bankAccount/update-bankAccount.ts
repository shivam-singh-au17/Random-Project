import { BankAccount } from "../../models/bankAccount";
import { RequestHandler } from "express";

const updateBankAccount: RequestHandler = async (req, res, next) => {
  try {
    const item = await BankAccount.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateBankAccount };
