import { BankAccount } from "../../models/bankAccount";
import { RequestHandler } from "express";

const getOneBankAccount: RequestHandler = async (req, res, next) => {
  try {
    const item = await BankAccount.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneBankAccount };
