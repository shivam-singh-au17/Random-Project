import { BankAccount } from "../../models/bankAccount";
import { RequestHandler } from "express";

const createBankAccount: RequestHandler = async (req, res, next) => {
  try {
    const item = await BankAccount.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createBankAccount };
