import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createBankAccount } from "./create-bankAccount";
import { getBankAccount } from "./get-bankAccount";
import { getOneBankAccount } from "./get-one-bankAccount";
import { deleteBankAccount } from "./delete-bankAccount";
import { updateBankAccount } from "./update-bankAccount";
import { SetupsPolicy } from "../../middlewares/policies/setups/@setups.policies";

const router = express.Router();
router.post(
  "/create-bankAccount/",
  SetupsPolicy.create(),
  createValidation,
  createBankAccount
);

router.get("/get-bankAccount/", SetupsPolicy.read(), getBankAccount);

router.get("/get-one-bankAccount/:id", SetupsPolicy.read(), getOneBankAccount);

router.delete(
  "/delete-bankAccount/:id",
  SetupsPolicy.delete(),
  deleteBankAccount
);

router.patch(
  "/update-bankAccount/:id",
  SetupsPolicy.update(),
  updateValidation,
  updateBankAccount
);

export { router as bankAccount };
