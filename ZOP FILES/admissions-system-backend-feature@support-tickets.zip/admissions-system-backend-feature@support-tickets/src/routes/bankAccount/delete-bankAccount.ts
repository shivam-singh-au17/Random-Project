import { BankAccount } from "../../models/bankAccount";
import { RequestHandler } from "express";

const deleteBankAccount: RequestHandler = async (req, res, next) => {
  try {
    const item = await BankAccount.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteBankAccount };
