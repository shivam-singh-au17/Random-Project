import { SupportTicket } from "../../models/supportTicket";
import { ApplicationForm } from "../../models/applicationForm";
import moment from "moment-timezone";
import { RequestHandler } from "express";
import { RegistrationFormService } from "../../models/registrationForm";
import { SupportTicketsCategory } from "../../models/supportTicketsCategory";
import {
  createSupportTicketCounter,
  getSupportTicketCount,
  generateSupportTicketCount,
} from "../globalCounter/supportTicketCounter";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const adminSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

const userSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

adminSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketAdmin"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketAdmin"
    ),
  })
);

userSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketUser"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketUser"
    ),
  })
);

const createSupportTicket: RequestHandler = async (req, res, next) => {
  try {
    const applicationData = await ApplicationForm.find({
      candidateId: req.body.candidateId,
    })
      .lean()
      .exec();

    const count: number = await getSupportTicketCount();
    req.body.ticketNumber = generateSupportTicketCount(count);
    createSupportTicketCounter(count);
    req.body.applicationFormNumber =
      applicationData[0] !== undefined
        ? applicationData[0].formNo
        : "The student has not filled out the form yet.";
    req.body.ticketCreatedDate = moment()
      .tz("Asia/Kolkata")
      .format("MMM M, YYYY [at] h:mm A");
    const item = await SupportTicket.create(req.body);

    const itemEmail = await RegistrationFormService.findById(
      req.body.candidateId
    )
      .lean()
      .exec();

    const itemAdminEmail = await SupportTicketsCategory.findById(
      req.body.requestCategoryId
    )
      .lean()
      .exec();

    if (itemEmail !== null && itemAdminEmail !== null) {
      const sendUserSupportTicket = {
        from: `${senderAddress} <${mailUser}>`,
        to: `${req.body.ticketRequester}`,
        subject: `Ticket Received - ${req.body.subject}`,
        template: "supportTicketUser",
        context: {
          studentName: `${itemEmail.firstName.toUpperCase()} ${itemEmail.lastName.toUpperCase()}`,
        },
      };

      userSupportTicket.sendMail(sendUserSupportTicket, function (error, info) {
        if (error) {
          return console.log(error);
        }
        console.log("Message sent to Student: " + info.response);
      });

      const sendAdminSupportTicket = {
        from: `${senderAddress} <${mailUser}>`,
        to: `${itemAdminEmail.assignCategoryPerson}`,
        subject: `New Ticket - ${req.body.subject} #${item.ticketNumber}`,
        template: "supportTicketAdmin",
        context: {
          studentName: `${itemEmail.firstName.toUpperCase()} ${itemEmail.lastName.toUpperCase()}`,
          ticketNumber: `${item.ticketNumber}`,
          ticketRequester: `${item.ticketRequester}`,
          description: `${item.description}`,
          formNumber: `${item.applicationFormNumber}`,
          mobaile: `${
            applicationData[0] !== undefined
              ? applicationData[0].contactDetails.mobile
              : "Not Available"
          }`,
        },
      };

      adminSupportTicket.sendMail(
        sendAdminSupportTicket,
        function (error, info) {
          if (error) {
            return console.log(error);
          }
          console.log("Message sent to Admin: " + info.response);
        }
      );
    }

    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSupportTicket };
