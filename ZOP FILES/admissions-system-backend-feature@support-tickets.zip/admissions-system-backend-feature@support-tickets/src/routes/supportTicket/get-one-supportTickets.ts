import { SupportTicket } from "../../models/supportTicket";
import { RequestHandler } from "express";

const getOneSupportTickets: RequestHandler = async (req, res, next) => {
  try {
    const item = await SupportTicket.findById(req.params.id)
      .populate("candidateId")
      .populate("requestCategoryId")
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneSupportTickets };
