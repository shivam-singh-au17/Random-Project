import { SupportTicket } from "../../models/supportTicket";
import { RegistrationFormService } from "../../models/registrationForm";
import { SupportTicketsCategory } from "../../models/supportTicketsCategory";
import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const transferSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

transferSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketTransfer"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketTransfer"
    ),
  })
);

const transferSupportTickets: RequestHandler = async (req, res, next) => {
  try {
    const item = await SupportTicket.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (item === null) {
      return res.status(400).send({ status: "Error" });
    }

    const itemAdminEmail = await SupportTicketsCategory.findById(
      item.requestCategoryId
    )
      .lean()
      .exec();

    const applicationData = await ApplicationForm.find({
      candidateId: item.candidateId,
    })
      .lean()
      .exec();

    const itemEmail = await RegistrationFormService.findById(item.candidateId)
      .lean()
      .exec();

    if (
      itemEmail === null ||
      itemAdminEmail === null ||
      applicationData === null
    ) {
      return res.status(400).send({ status: "Error" });
    }

    const sendTransferSupportTicket = {
      from: `${senderAddress} <${mailUser}>`,
      to: `${itemAdminEmail.assignCategoryPerson}`,
      subject: `New Transferred Ticket - ${item.subject} #${item.ticketNumber}`,
      template: "supportTicketTransfer",
      context: {
        studentName: `${itemEmail.firstName.toUpperCase()} ${itemEmail.lastName.toUpperCase()}`,
        ticketNumber: `${item.ticketNumber}`,
        ticketRequester: `${item.ticketRequester}`,
        description: `${item.description}`,
        formNumber: `${item.applicationFormNumber}`,
        mobaile: `${
          applicationData[0] !== undefined
            ? applicationData[0].contactDetails.mobile
            : "Not Available"
        }`,
      },
    };

    transferSupportTicket.sendMail(
      sendTransferSupportTicket,
      function (error, info) {
        if (error) {
          return console.log(error);
        }
        console.log("Message sent to Admin: " + info.response);
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { transferSupportTickets };
