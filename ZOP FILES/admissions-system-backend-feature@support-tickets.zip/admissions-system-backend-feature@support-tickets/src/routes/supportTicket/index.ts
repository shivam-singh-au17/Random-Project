import express from "express";

import {
  createValidation,
  updateValidation,
  replyValidation,
  transferValidation,
} from "./validation";

import { createSupportTicket } from "./create-supportTicket";
import { getAllSupportTickets } from "./getAll-supportTickets";
import { getOneSupportTickets } from "./get-one-supportTickets";
import { getSupportTickets } from "./get-supportTickets";
import { closeSupportTickets } from "./close-supportTicket";
import { replySupportTickets } from "./reply-supportTickets";
import { transferSupportTickets } from "./transfer-supportTickets";

const router = express.Router();

router.post(
  "/support/ticket/new",
  createValidation,
  createSupportTicket
);

router.get("/support/tickets/", getAllSupportTickets);

router.patch(
  "/support/tickets/:id/close",
  updateValidation,
  closeSupportTickets
);

router.patch(
  "/support/tickets/:id/reply",
  replyValidation,
  replySupportTickets
);

router.patch(
  "/support/tickets/:id/transfer",
  transferValidation,
  transferSupportTickets
);

router.get("/support/tickets/:id", getOneSupportTickets);

router.get("/support/:candidateId/tickets/", getSupportTickets);

export { router as supportTicket };
