import { SupportTicket } from "../../models/supportTicket";
import { RequestHandler } from "express";
import { RegistrationFormService } from "../../models/registrationForm";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const closeSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

closeSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketClose"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketClose"
    ),
  })
);

const closeSupportTickets: RequestHandler = async (req, res, next) => {
  try {
    const item = await SupportTicket.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (item === null) {
      return res.status(400).send({ status: "Error" });
    }

    const itemEmail = await RegistrationFormService.findById(item.candidateId)
      .lean()
      .exec();

    if (itemEmail === null) {
      return res.status(400).send({ status: "Error" });
    }

    const sendCloseSupportTicket = {
      from: `${senderAddress} <${mailUser}>`,
      to: `${item.ticketRequester}`,
      subject: `Ticket Closed - ${item.subject} - #${item.ticketNumber}`,
      template: "supportTicketClose",
      context: {
        studentName: `${itemEmail.firstName.toUpperCase()} ${itemEmail.lastName.toUpperCase()}`,
      },
    };

    closeSupportTicket.sendMail(sendCloseSupportTicket, function (error, info) {
      if (error) {
        return console.log(error);
      }
      console.log("Message sent to Student: " + info.response);
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { closeSupportTickets };
