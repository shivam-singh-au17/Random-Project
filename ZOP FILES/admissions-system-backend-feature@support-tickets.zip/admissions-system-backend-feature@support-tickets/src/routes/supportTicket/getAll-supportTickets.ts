import { SupportTicket } from "../../models/supportTicket";
import { RequestHandler } from "express";

const getAllSupportTickets: RequestHandler = async (req, res, next) => {
  try {
    if (
      req.query.id !== undefined &&
      req.query.candidateId === undefined &&
      req.query.ticketStatus === undefined
    ) {
      const itemOne = await SupportTicket.findById(req.query.id)
        .populate("candidateId")
        .populate("requestCategoryId")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId !== undefined &&
      req.query.ticketStatus === undefined
    ) {
      const itemOne = await SupportTicket.find({
        candidateId: req.query.candidateId,
      })
        .populate("candidateId")
        .populate("requestCategoryId")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.ticketStatus !== undefined
    ) {
      const itemOne = await SupportTicket.find({
        ticketStatus: req.query.ticketStatus,
      })
        .populate("candidateId")
        .populate("requestCategoryId")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }

    const item = await SupportTicket.find()
      .populate("candidateId")
      .populate("requestCategoryId")
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAllSupportTickets };
