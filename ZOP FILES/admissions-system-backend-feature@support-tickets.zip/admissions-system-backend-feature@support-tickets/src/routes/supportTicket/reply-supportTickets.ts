import { SupportTicket } from "../../models/supportTicket";
import { SupportTicketsCategory } from "../../models/supportTicketsCategory";
import { RegistrationFormService } from "../../models/registrationForm";
import { RequestHandler } from "express";
import moment from "moment-timezone";
import hbs from "nodemailer-express-handlebars";
import nodemailer from "nodemailer";
import path from "path";
import { mailService, mailUser, mailPass, senderAddress } from "../../config";

const replyAdminSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

replyAdminSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketAdminReply"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketAdminReply"
    ),
  })
);

const replyStudentSupportTicket = nodemailer.createTransport({
  service: mailService,
  auth: {
    user: mailUser,
    pass: mailPass,
  },
});

replyStudentSupportTicket.use(
  "compile",
  hbs({
    viewEngine: {
      partialsDir: path.join(
        __dirname,
        "../../../src/routes/supportTicket/supportTicketStudentReply"
      ),
      defaultLayout: false,
    },
    viewPath: path.join(
      __dirname,
      "../../../src/routes/supportTicket/supportTicketStudentReply"
    ),
  })
);

const replySupportTickets: RequestHandler = async (req, res, next) => {
  try {
    if (
      req.body.studentComment !== undefined &&
      req.body.adminComment !== undefined
    ) {
      return res.status(400).send({
        status: "Not Allowed",
        message: "You can't pass both comments at once.",
      });
    }

    if (
      req.body.studentComment !== undefined &&
      req.body.adminComment === undefined
    ) {
      const item = await SupportTicket.findByIdAndUpdate(
        req.params.id,
        {
          $push: {
            adminStudentComment: {
              studentComment: req.body.studentComment,
              studentDateTime: moment()
                .tz("Asia/Kolkata")
                .format("MMM M, YYYY [at] h:mm A"),
            },
          },
        },
        { new: true }
      );

      if (item === null) {
        return res.status(400).send({ status: "Error" });
      }

      const itemEmail = await RegistrationFormService.findById(item.candidateId)
        .lean()
        .exec();

      const itemCategory = await SupportTicketsCategory.findById(
        item.requestCategoryId
      )
        .lean()
        .exec();

      if (itemEmail === null || itemCategory === null) {
        return res.status(400).send({ status: "Error" });
      }

      const sendReplyStudentSupportTicket = {
        from: `${senderAddress} <${mailUser}>`,
        to: `${itemCategory.assignCategoryPerson}`,
        subject: `Re: ${item.subject} - #${item.ticketNumber}`,
        template: "supportTicketStudentReply",
        context: {
          studentName: `${itemEmail.firstName} ${itemEmail.lastName}`,
          studentComment: `${req.body.studentComment}`,
          description: `${item.description}`,
          dateTime: `${item.ticketCreatedDate}`,
          studentEmail: `${item.ticketRequester}`,
        },
      };

      replyStudentSupportTicket.sendMail(
        sendReplyStudentSupportTicket,
        function (error, info) {
          if (error) {
            return console.log(error);
          }
          console.log("Message sent to Admin: " + info.response);
        }
      );
      return res.status(200).send(item);
    }

    if (
      req.body.studentComment === undefined &&
      req.body.adminComment !== undefined
    ) {
      const item = await SupportTicket.findByIdAndUpdate(
        req.params.id,
        {
          $push: {
            adminStudentComment: {
              adminComment: req.body.adminComment,
              adminDateTime: moment()
                .tz("Asia/Kolkata")
                .format("MMM M, YYYY [at] h:mm A"),
            },
          },
        },
        { new: true }
      );

      if (item === null) {
        return res.status(400).send({ status: "Error" });
      }

      const itemEmail = await RegistrationFormService.findById(item.candidateId)
        .lean()
        .exec();

      if (itemEmail === null) {
        return res.status(400).send({ status: "Error" });
      }

      const sendReplyAdminSupportTicket = {
        from: `${senderAddress} <${mailUser}>`,
        to: `${item.ticketRequester}`,
        subject: `Re: ${item.subject}`,
        template: "supportTicketAdminReply",
        context: {
          studentName: `${itemEmail.firstName} ${itemEmail.lastName}`,
          adminComment: `${req.body.adminComment}`,
          description: `${item.description}`,
          dateTime: `${item.ticketCreatedDate}`,
          studentEmail: `${item.ticketRequester}`,
        },
      };

      replyAdminSupportTicket.sendMail(
        sendReplyAdminSupportTicket,
        function (error, info) {
          if (error) {
            return console.log(error);
          }
          console.log("Message sent to Student: " + info.response);
        }
      );
      return res.status(200).send(item);
    }

    return res.status(400).send({
      status: "Not Allowed",
      message: "Please pass at least one comment.",
    });
  } catch (error) {
    return next(error);
  }
};

export { replySupportTickets };
