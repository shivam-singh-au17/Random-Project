import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  create: Joi.object({
    candidateId: Joi.string().required(),
    ticketRequester: Joi.string().required().email({ minDomainSegments: 2 }),
    subject: Joi.string().required(),
    requestCategoryId: Joi.string().required(),
    description: Joi.string().required(),
  }),

  update: Joi.object({
    ticketStatus: Joi.string().required(),
  }),

  reply: Joi.object({
    studentComment: Joi.string(),
    adminComment: Joi.string(),
  }),

  transfer: Joi.object({
    requestCategoryId: Joi.string().required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

const replyValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.reply, req.body, next);

const transferValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.transfer, req.body, next);

export {
  createValidation,
  updateValidation,
  replyValidation,
  transferValidation,
};
