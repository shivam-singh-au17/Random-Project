import { SupportTicket } from "../../models/supportTicket";
import { RequestHandler } from "express";

function regex(string) {
  string = string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`.*${string}.*`, "i");
}

const getSupportTickets: RequestHandler = async (req, res, next) => {
  try {
    let query = {};
    if (req.query.ticketStatus) {
      query = {
        ...query,
        candidateId: req.params.candidateId,
        ticketStatus: { $regex: regex(req.query.ticketStatus) },
      };

      const itemOne = await SupportTicket.find(query)
        .populate("candidateId")
        .populate("requestCategoryId")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await SupportTicket.find({
      candidateId: req.params.candidateId,
    })
      .populate("candidateId")
      .populate("requestCategoryId")
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getSupportTickets };
