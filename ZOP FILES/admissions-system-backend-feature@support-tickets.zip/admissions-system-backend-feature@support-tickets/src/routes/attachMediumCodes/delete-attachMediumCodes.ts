import { AttachMediumCodes } from "../../models/attachMediumCodes";
import { RequestHandler } from "express";

const deleteAttachMediumCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachMediumCodes.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteAttachMediumCodes };
