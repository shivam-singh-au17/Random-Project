import { AttachMediumCodes } from "../../models/attachMediumCodes";
import { RequestHandler } from "express";

const updateAttachMediumCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachMediumCodes.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateAttachMediumCodes };
