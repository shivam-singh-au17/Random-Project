import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createAttachMediumCodes } from "./create-attachMediumCodes";
import { getAttachMediumCodes } from "./get-attachMediumCodes";
import { getOneAttachMediumCodes } from "./get-one-attachMediumCodes";
import { deleteAttachMediumCodes } from "./delete-attachMediumCodes";
import { updateAttachMediumCodes } from "./update-attachMediumCodes";

const router = express.Router();

router.post("/create-attachMediumCodes/", createValidation, createAttachMediumCodes);

router.get("/get-attachMediumCodes/", getAttachMediumCodes);

router.get("/get-one-attachMediumCodes/:id", getOneAttachMediumCodes);

router.delete("/delete-attachMediumCodes/:id", deleteAttachMediumCodes);

router.patch("/update-attachMediumCodes/:id", updateValidation, updateAttachMediumCodes);

export { router as attachMediumCodes };
