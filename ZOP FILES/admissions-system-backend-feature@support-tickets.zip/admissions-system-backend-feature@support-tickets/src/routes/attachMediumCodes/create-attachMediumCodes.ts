import { AttachMediumCodes } from "../../models/attachMediumCodes";
import { RequestHandler } from "express";

const createAttachMediumCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachMediumCodes.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createAttachMediumCodes };
