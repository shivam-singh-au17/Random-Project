import { Category } from "../../models/category";
import { RequestHandler } from "express";

const updateCategory: RequestHandler = async (req, res, next) => {
  try {
    const item = await Category.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateCategory };
