import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createCategory } from "./create-category";
import { getCategory } from "./get-category";
import { deleteCategory } from "./delete-category";
import { updateCategory } from "./update-category";

const router = express.Router();

router.post("/create-category/", createValidation, createCategory);

router.get("/get-category/", getCategory);

router.delete("/delete-category/:id", deleteCategory);

router.patch("/update-category/:id", updateValidation, updateCategory);

export { router as category };
