import { Category } from "../../models/category";
import { RequestHandler } from "express";

const getCategory: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await Category.findById(req.query.id)
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await Category.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getCategory };
