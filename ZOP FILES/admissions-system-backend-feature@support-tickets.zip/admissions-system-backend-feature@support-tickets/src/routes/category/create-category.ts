import { Category } from "../../models/category";
import { RequestHandler } from "express";

const createCategory: RequestHandler = async (req, res, next) => {
  try {
    const item = await Category.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createCategory };
