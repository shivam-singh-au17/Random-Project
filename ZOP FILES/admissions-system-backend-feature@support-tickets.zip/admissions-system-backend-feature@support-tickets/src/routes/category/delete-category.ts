import { Category } from "../../models/category";
import { RequestHandler } from "express";

const deleteCategory: RequestHandler = async (req, res, next) => {
  try {
    const item = await Category.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteCategory };
