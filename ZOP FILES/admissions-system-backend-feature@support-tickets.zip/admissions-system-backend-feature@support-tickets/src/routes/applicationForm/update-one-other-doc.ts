import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const updateOneOtherDocument: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.updateOne(
      {
        _id: req.params.id,
        "otherDocuments._id": req.params.odId,
      },
      {
        $set: {
          "otherDocuments.$.documentName": req.body.documentName,
          "otherDocuments.$.url": req.body.url,
          "otherDocuments.$.submitted": req.body.submitted,
          "otherDocuments.$.isMandatory": req.body.isMandatory,
        },
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateOneOtherDocument };
