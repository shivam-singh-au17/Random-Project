import { ApplicationForm } from "../../models/applicationForm";
import { FeeStructureCodes } from "../../models/feeStructureCodes";
import { RequestHandler } from "express";
import moment from "moment-timezone";

const updateStatus: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();

    if (formData !== null) {
      if (formData.stepCounter === 3 && formData.secondStepCount === 6) {
        const tagsArray = [formData.personalDetails.gender];

        const feeStructureData = await FeeStructureCodes.find({
          "META.TAGS": tagsArray,
        })
          .lean()
          .exec();

        if (feeStructureData.length === 1) {
          const item = await ApplicationForm.findByIdAndUpdate(
            req.params.id,
            {
              formSubmitted: req.body.formSubmitted,
              dateAppliedOn: moment()
                .tz("Asia/Kolkata")
                .format("DD/MM/YYYY - h:mm:ss A"),
              META: {
                TAGS: tagsArray,
                FEE_STRUCTURE: feeStructureData[0]._id,
              },
            },
            { new: true }
          );
          return res.status(200).send(item);
        }

        const feeStructureDefaultData = await FeeStructureCodes.findOne({
          "META.TAGS": ["DEFAULT"],
        })
          .lean()
          .exec();

        if (feeStructureDefaultData === null) {
          return res.status(400).send({
            status: "Error",
            message: "Can't find the default fee structure",
          });
        }

        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          {
            formSubmitted: req.body.formSubmitted,
            dateAppliedOn: moment()
              .tz("Asia/Kolkata")
              .format("DD/MM/YYYY - h:mm:ss A"),
            META: {
              TAGS: tagsArray,
              FEE_STRUCTURE: feeStructureDefaultData._id,
            },
          },
          { new: true }
        );
        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Not authorized",
          message: "Fill the front form data first and then the back data",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { updateStatus };
