import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const allDocumentsStatus: RequestHandler = async (req, res, next) => {
  try {
    const data = await ApplicationForm.findById(req.params.id).lean().exec();

    if (data !== null && data !== undefined) {
      const documentsData = data.otherDocuments;

      for (let i = 0; i < documentsData.length; i++) {
        const temp = documentsData[i];

        await ApplicationForm.updateOne(
          {
            _id: req.params.id,
            "otherDocuments._id": temp._id,
          },
          {
            $set: {
              "otherDocuments.$.valid": true,
              "otherDocuments.$.message": req.body.message,
            },
          }
        );
      }

      const item = await ApplicationForm.findById(req.params.id).lean().exec();
      return res.status(200).send(item);
    } else {
      return res.status(400).send("Getting the null value of data field");
    }
  } catch (error) {
    return next(error);
  }
};

export { allDocumentsStatus };
