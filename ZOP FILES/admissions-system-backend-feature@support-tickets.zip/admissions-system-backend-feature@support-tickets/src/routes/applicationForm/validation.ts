import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const combinationSchema = Joi.object({
  subjectCode: Joi.string().required(),
  preference: Joi.number().required(),
}).required();

const combinationSubjectSchema = Joi.array()
  .items(combinationSchema)
  .unique()
  .required();

const validationSchema = {
  createForm: Joi.object({
    candidateId: Joi.string().required(),
    collegeType: Joi.string().required(),
    programName: Joi.string().required(),
    programCode: Joi.string().required(),
    compulsorySubject: Joi.string().required(),
    combinationSubject: Joi.alternatives()
      .try(combinationSchema, combinationSubjectSchema)
      .required(),
    academicYear: Joi.string(),
    yearAppliedFor: Joi.string().required(),
    isInHouse: Joi.boolean().required(),
  }),

  updateApplicant: Joi.object({
    uanNumber: Joi.string(),
  }),

  updatePersonal: Joi.object({
    personalDetails: Joi.object({
      aadharNumber: Joi.string().required().min(12).max(12),
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      fatherName: Joi.string().required(),
      motherName: Joi.string().required(),
      placeOfBirth: Joi.string().required(),
      dateOfBirth: Joi.string().required(),
      motherTongue: Joi.string().required(),
      category: Joi.string().required(),
      bloodGroup: Joi.string().required(),
      nationality: Joi.string().required(),
      religion: Joi.string().required(),
      gender: Joi.string().required(),
      maritalStatus: Joi.string().required(),
      caste: Joi.string().required(),
      subCaste: Joi.string(),
    }),
  }),

  updateContact: Joi.object({
    contactDetails: Joi.object({
      mobile: Joi.string().required().min(10).max(10),
      parentMobile: Joi.string().required().min(10).max(10),
      parentEmail: Joi.string().required().email({ minDomainSegments: 2 }),
      district: Joi.string().required(),
      address: Joi.string().required(),
      pinCode: Joi.string().required().min(6).max(6),
      state: Joi.string().required(),
    }),
  }),

  updateAcademic: Joi.object({
    academicDetails: Joi.object({
      matricEducation: Joi.object({
        boardName: Joi.string().required(),
        schoolName: Joi.string().required(),
        passingDate: Joi.string().required(),
        isGrade: Joi.string().required(),
        score: Joi.string().required(),
        seatNumber: Joi.number(),
        obtainedMarks: Joi.number(),
        totalMarks: Joi.number(),
      }).required(),

      intermediateEducation: Joi.object({
        boardName: Joi.string().required(),
        schoolName: Joi.string().required(),
        passingDate: Joi.string().required(),
        isGrade: Joi.string().required(),
        score: Joi.string().required(),
        seatNumber: Joi.number(),
        obtainedMarks: Joi.number(),
        totalMarks: Joi.number(),
      }).required(),

      bachelorsDegree: Joi.object({
        yearOfPassing: Joi.string(),
        instituteName: Joi.string(),
        degreeTitle: Joi.string(),
        yearsOffered: Joi.string(),
        sem1stScore: Joi.string(),
        sem2ndScore: Joi.string(),
        CGPA: Joi.string(),
        obtainOutOf: Joi.string(),
      }),

      otherDegree: Joi.object({
        yearOfPassing: Joi.string(),
        instituteName: Joi.string(),
        degreeTitle: Joi.string(),
        percentage: Joi.string(),
      }),
    }),
  }),

  updateLegal: Joi.object({
    legalDetails: Joi.object({
      domicile: Joi.string().required(),
      parentOccupation: Joi.string().required(),
      annualIncome: Joi.number().required(),
      sikhMinority: Joi.boolean().required(),
      reservationInformation: Joi.string(),
    }),
  }),

  updateDeclaration: Joi.object({
    declaration: Joi.object({
      place: Joi.string().required(),
      date: Joi.string().required(),
      termsCondition: Joi.boolean().required(),
    }),
  }),

  mandatoryDocuments: Joi.object({
    mandatoryDocuments: Joi.object({
      signature: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),

      photo: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),
    }),
  }),

  otherDocuments: Joi.object({
    documentName: Joi.string().required(),
    url: Joi.string().required(),
    submitted: Joi.boolean().required(),
    valid: Joi.boolean(),
    message: Joi.string(),
    isMandatory: Joi.boolean(),
  }),

  updateOneOtherDoc: Joi.object({
    documentName: Joi.string().required(),
    url: Joi.string().required(),
    submitted: Joi.boolean().required(),
    isMandatory: Joi.boolean(),
  }),

  updateDocumentsStatus: Joi.object({
    valid: Joi.boolean().required(),
    message: Joi.string(),
  }),

  updateAllDocumentsStatus: Joi.object({
    message: Joi.string(),
  }),

  updateStatus: Joi.object({
    formSubmitted: Joi.boolean().required(),
  }),

  updateApplicationFee: Joi.object({
    applicationFee: Joi.boolean().required(),
  }),
};

const createFormValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createForm, req.body, next);

const updateApplicantValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateApplicant, req.body, next);

const updatePersonalValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updatePersonal, req.body, next);

const updateContactValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateContact, req.body, next);

const updateAcademicValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateAcademic, req.body, next);

const updateLegalValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateLegal, req.body, next);

const updateDeclarationValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateDeclaration, req.body, next);

const updateMandatoryDocumentsValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.mandatoryDocuments, req.body, next);

const updateOtherDocumentsValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.otherDocuments, req.body, next);

const updateDocumentsStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateDocumentsStatus, req.body, next);

const updateAllDocumentsStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateAllDocumentsStatus, req.body, next);

const updateStatusValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateStatus, req.body, next);

const updateOneOtherDocumentValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateOneOtherDoc, req.body, next);

const updateApplicationFeeValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateApplicationFee, req.body, next);

export {
  createFormValidation,
  updateApplicantValidation,
  updatePersonalValidation,
  updateContactValidation,
  updateAcademicValidation,
  updateLegalValidation,
  updateDeclarationValidation,
  updateMandatoryDocumentsValidation,
  updateOtherDocumentsValidation,
  updateDocumentsStatusValidation,
  updateAllDocumentsStatusValidation,
  updateStatusValidation,
  updateOneOtherDocumentValidation,
  updateApplicationFeeValidation,
};
