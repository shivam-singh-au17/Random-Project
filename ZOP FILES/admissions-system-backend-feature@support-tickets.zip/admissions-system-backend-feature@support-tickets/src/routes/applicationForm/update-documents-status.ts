import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const updateDocumentsStatus: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.updateOne(
      {
        _id: req.params.id,
        "otherDocuments._id": req.params.mdId,
      },
      {
        $set: {
          "otherDocuments.$.valid": req.body.valid,
          "otherDocuments.$.message": req.body.message,
        },
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateDocumentsStatus };
