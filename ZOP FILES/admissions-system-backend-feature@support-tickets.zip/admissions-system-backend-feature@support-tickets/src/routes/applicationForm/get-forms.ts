import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const getForms: RequestHandler = async (req, res, next) => {
  try {
    if (
      req.query.id !== undefined &&
      req.query.candidateId === undefined &&
      req.query.programName === undefined &&
      req.query.academicYear === undefined &&
      req.query.yearAppliedFor === undefined
    ) {
      const itemOne = await ApplicationForm.findById(req.query.id)
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }

    if (
      req.query.id === undefined &&
      req.query.programName === undefined &&
      req.query.academicYear === undefined &&
      req.query.yearAppliedFor === undefined &&
      req.query.candidateId !== undefined
    ) {
      const itemOne = await ApplicationForm.find({
        candidateId: req.query.candidateId,
      })
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName !== undefined &&
      req.query.academicYear !== undefined &&
      req.query.yearAppliedFor !== undefined
    ) {
      const itemSeven = await ApplicationForm.find({
        programName: req.query.programName,
        academicYear: req.query.academicYear,
        yearAppliedFor: req.query.yearAppliedFor,
      })
        .lean()
        .exec();
      return res.status(200).send(itemSeven);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName !== undefined &&
      req.query.academicYear !== undefined &&
      req.query.yearAppliedFor === undefined
    ) {
      const itemFive = await ApplicationForm.find({
        programName: req.query.programName,
        academicYear: req.query.academicYear,
      })
        .lean()
        .exec();
      return res.status(200).send(itemFive);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName !== undefined &&
      req.query.academicYear === undefined &&
      req.query.yearAppliedFor !== undefined
    ) {
      const itemSix = await ApplicationForm.find({
        programName: req.query.programName,
        yearAppliedFor: req.query.yearAppliedFor,
      })
        .lean()
        .exec();
      return res.status(200).send(itemSix);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName !== undefined &&
      req.query.academicYear === undefined &&
      req.query.yearAppliedFor === undefined
    ) {
      const itemTwo = await ApplicationForm.find({
        programName: req.query.programName,
      })
        .lean()
        .exec();
      return res.status(200).send(itemTwo);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName === undefined &&
      req.query.academicYear !== undefined &&
      req.query.yearAppliedFor === undefined
    ) {
      const itemThree = await ApplicationForm.find({
        academicYear: req.query.academicYear,
      })
        .lean()
        .exec();
      return res.status(200).send(itemThree);
    }

    if (
      req.query.id === undefined &&
      req.query.candidateId === undefined &&
      req.query.programName === undefined &&
      req.query.academicYear === undefined &&
      req.query.yearAppliedFor !== undefined
    ) {
      const itemFour = await ApplicationForm.find({
        yearAppliedFor: req.query.yearAppliedFor,
      })
        .lean()
        .exec();
      return res.status(200).send(itemFour);
    }

    const item = await ApplicationForm.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

const getFormpName: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      programName: req.params.programName,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

const getFormYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      academicYear: req.params.academicYear,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

const getFormFor: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      yearAppliedFor: req.params.yearAppliedFor,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

const getFormNameYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      programName: req.params.programName,
      academicYear: req.params.academicYear,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

const getFormNameYearFor: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({
      programName: req.params.programName,
      academicYear: req.params.academicYear,
      yearAppliedFor: req.params.yearAppliedFor,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export {
  getForms,
  getFormpName,
  getFormYear,
  getFormFor,
  getFormNameYear,
  getFormNameYearFor,
};
