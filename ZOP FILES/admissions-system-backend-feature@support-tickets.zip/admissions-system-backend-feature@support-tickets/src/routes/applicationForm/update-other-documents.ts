import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const updateOtherDocuments: RequestHandler = async (req, res, next) => {
  try {
    const formData = await ApplicationForm.findById(req.params.id)
      .lean()
      .exec();
    if (formData !== null) {
      if (formData.stepCounter === 3 && formData.secondStepCount === 6) {
        const item = await ApplicationForm.findByIdAndUpdate(
          req.params.id,
          { $push: { otherDocuments: req.body } },
          { new: true }
        );
        return res.status(200).send(item);
      } else {
        return res.status(400).send({
          status: "Not authorized",
          message: "Fill the front form data first and then the back data",
        });
      }
    } else {
      return res.status(400).send("Getting the null value of FormData field");
    }
  } catch (error) {
    return next(error);
  }
};

export { updateOtherDocuments };
