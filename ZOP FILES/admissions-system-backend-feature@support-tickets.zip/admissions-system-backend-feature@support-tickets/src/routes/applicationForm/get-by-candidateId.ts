import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const getByCandidateId: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.find({ candidateId: req.params.id })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getByCandidateId };
