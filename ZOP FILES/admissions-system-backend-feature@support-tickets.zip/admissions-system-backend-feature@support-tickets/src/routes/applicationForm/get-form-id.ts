import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";

const getFormById: RequestHandler = async (req, res, next) => {
  try {
    const item = await ApplicationForm.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getFormById };
