import express from "express";

import {
  createFormValidation,
  updateApplicantValidation,
  updatePersonalValidation,
  updateContactValidation,
  updateAcademicValidation,
  updateLegalValidation,
  updateDeclarationValidation,
  updateMandatoryDocumentsValidation,
  updateOtherDocumentsValidation,
  updateDocumentsStatusValidation,
  updateAllDocumentsStatusValidation,
  updateStatusValidation,
  updateOneOtherDocumentValidation,
  updateApplicationFeeValidation,
} from "./validation";

import { createForm } from "./create-form";
import {
  getForms,
  getFormpName,
  getFormYear,
  getFormFor,
  getFormNameYear,
  getFormNameYearFor,
} from "./get-forms";

import { getFormById } from "./get-form-id";
import { updateApplicant } from "./update-applicant";
import { updatePersonal } from "./update-personal";
import { updateContact } from "./update-contact";
import { updateAcademic } from "./update-academic";
import { updateLegal } from "./update-legal";
import { updateDeclaration } from "./update-declaration";
import { updateMandatoryDocuments } from "./update-mandatory-documents";
import { updateOtherDocuments } from "./update-other-documents";
import { updateDocumentsStatus } from "./update-documents-status";
import { allDocumentsStatus } from "./all-documents-status";
import { updateStatus } from "./update-status";
import { getByCandidateId } from "./get-by-candidateId";
import { updateOneOtherDocument } from "./update-one-other-doc";
import { updateApplicationFee } from "./update-application-fee";

const router = express.Router();

router.post("/create-form/", createFormValidation, createForm);

router.get("/get-forms/", getForms);
router.get("/get-forms/:programName", getFormpName);
router.get("/get-forms/:academicYear", getFormYear);
router.get("/get-forms/:yearAppliedFor", getFormFor);
router.get("/get-forms/:programName/:academicYear", getFormNameYear);
router.get(
  "/get-forms/:programName/:academicYear/:yearAppliedFor",
  getFormNameYearFor
);

router.get("/get-form-id/:id", getFormById);
router.get("/get-by-candidateId/:id", getByCandidateId);

router.patch(
  "/update-applicant/:id",
  updateApplicantValidation,
  updateApplicant
);

router.patch("/update-personal/:id", updatePersonalValidation, updatePersonal);

router.patch("/update-contact/:id", updateContactValidation, updateContact);

router.patch("/update-academic/:id", updateAcademicValidation, updateAcademic);

router.patch("/update-legal/:id", updateLegalValidation, updateLegal);

router.patch(
  "/update-declaration/:id",
  updateDeclarationValidation,
  updateDeclaration
);

router.patch(
  "/update-mandatory-documents/:id",
  updateMandatoryDocumentsValidation,
  updateMandatoryDocuments
);

router.patch(
  "/update-other-documents/:id",
  updateOtherDocumentsValidation,
  updateOtherDocuments
);

router.patch(
  "/update-documents-status/:id/:mdId",
  updateDocumentsStatusValidation,
  updateDocumentsStatus
);

router.patch(
  "/all-documents-status/:id",
  updateAllDocumentsStatusValidation,
  allDocumentsStatus
);

router.patch("/update-status/:id", updateStatusValidation, updateStatus);

router.patch(
  "/update-one-other-doc/:id/:odId",
  updateOneOtherDocumentValidation,
  updateOneOtherDocument
);

router.patch(
  "/update-application-fee/:id/",
  updateApplicationFeeValidation,
  updateApplicationFee
);

export { router as applicationForm };
