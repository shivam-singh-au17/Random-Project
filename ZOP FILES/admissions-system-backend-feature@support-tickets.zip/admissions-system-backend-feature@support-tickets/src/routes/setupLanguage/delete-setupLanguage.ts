import { SetupLanguage } from "../../models/setupLanguage";
import { RequestHandler } from "express";

const deleteSetupLanguage: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupLanguage.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteSetupLanguage };
