import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSetupLanguage } from "./create-setupLanguage";
import { getSetupLanguage } from "./get-setupLanguage";
import { getOneSetupLanguage } from "./get-one-setupLanguage";
import { deleteSetupLanguage } from "./delete-setupLanguage";
import { updateSetupLanguage } from "./update-setupLanguage";
import { SetupsPolicy } from "../../middlewares/policies/setups/@setups.policies";

const router = express.Router();

router.post(
  "/create-setupLanguage/",
  SetupsPolicy.create(),
  createValidation,
  createSetupLanguage
);

router.get("/get-setupLanguage/", SetupsPolicy.read(), getSetupLanguage);

router.get(
  "/get-one-setupLanguage/:id",
  SetupsPolicy.read(),
  getOneSetupLanguage
);

router.delete(
  "/delete-setupLanguage/:id",
  SetupsPolicy.delete(),
  deleteSetupLanguage
);

router.patch(
  "/update-setupLanguage/:id",
  SetupsPolicy.update(),

  updateValidation,
  updateSetupLanguage
);

export { router as setupLanguage };
