import { SetupLanguage } from "../../models/setupLanguage";
import { RequestHandler } from "express";

const getOneSetupLanguage: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupLanguage.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneSetupLanguage };
