import { SetupLanguage } from "../../models/setupLanguage";
import { RequestHandler } from "express";

const getSetupLanguage: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await SetupLanguage.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await SetupLanguage.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getSetupLanguage };
