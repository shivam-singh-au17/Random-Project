import { SetupLanguage } from "../../models/setupLanguage";
import { RequestHandler } from "express";

const createSetupLanguage: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupLanguage.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSetupLanguage };
