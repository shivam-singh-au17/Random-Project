import { Router } from "express";

import { assertNewPaymentToPaymentHistory } from "../../controllers/payments/assert-payment-history";
import { getPaymentHistory } from "../../controllers/payments/get-payment-history";

const router = Router();
// payment router
router.post("/payment-history", assertNewPaymentToPaymentHistory);
// query router dynamic query on payment-history @feat
router.get("/payment-history", getPaymentHistory);
export { router as paymentRouter };
