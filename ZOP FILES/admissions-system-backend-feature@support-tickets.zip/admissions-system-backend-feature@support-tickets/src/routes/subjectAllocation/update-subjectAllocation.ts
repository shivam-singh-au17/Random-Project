import { SubjectAllocation } from "../../models/subjectAllocation";
import { RequestHandler } from "express";

const updateSubjectAllocation: RequestHandler = async (req, res, next) => {
  try {
    const item = await SubjectAllocation.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateSubjectAllocation };
