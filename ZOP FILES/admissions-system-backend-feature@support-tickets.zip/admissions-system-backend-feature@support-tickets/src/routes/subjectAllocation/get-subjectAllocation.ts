import { SubjectAllocation } from "../../models/subjectAllocation";
import { RequestHandler } from "express";

const getSubjectAllocation: RequestHandler = async (req, res, next) => {
  try {
    const item = await SubjectAllocation.find()
      .populate({
        path: "combinationSubject",
        model: "combinationSubject",
        select: "combinationSubject",
      })
      .populate({
        path: "compulsorySubject",
        model: "compulsorySubject",
        select: "compulsorySubject",
      })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getSubjectAllocation };
