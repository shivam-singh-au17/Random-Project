import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSubjectAllocation } from "./create-subjectAllocation";
import { getSubjectAllocation } from "./get-subjectAllocation";
import { getOneSubjectAllocation } from "./get-one-compulsorySubject";
import { deleteSubjectAllocation } from "./delete-subjectAllocation";
import { updateSubjectAllocation } from "./update-subjectAllocation";
import { getSubjectAllocationProgranYear } from "./getSubjectAllocationProgranYear";

const router = express.Router();

router.post(
  "/subject-allocation/create/",
  createValidation,
  createSubjectAllocation
);

router.get("/subject-allocation/get-all/", getSubjectAllocation);

router.get("/subject-allocation/get-one/:id", getOneSubjectAllocation);

router.delete("/subject-allocation/delete/:id", deleteSubjectAllocation);

router.patch(
  "/subject-allocation/update/:id",
  updateValidation,
  updateSubjectAllocation
);

router.get(
  "/subject-allocation/:programName/:yearAppliedFor",
  getSubjectAllocationProgranYear
);

export { router as subjectAllocation };
