import { SubjectAllocation } from "../../models/subjectAllocation";
import { CombinationSubject } from "../../models/combinationSubject";
import { CompulsorySubject } from "../../models/compulsorySubject";
import { RequestHandler } from "express";

const createSubjectAllocation: RequestHandler = async (req, res, next) => {
  try {
    const combinationData = await CombinationSubject.findOne({
      programName: req.body.programName,
      yearAppliedFor: req.body.yearAppliedFor,
    }).exec();

    const compulsoryData = await CompulsorySubject.findOne({
      programName: req.body.programName,
      yearAppliedFor: req.body.yearAppliedFor,
    }).exec();

    if (combinationData === null) {
      return res.status(400).json({
        status: "Error",
        message: "Unable to get data of the combination subject.",
      });
    }

    if (compulsoryData === null) {
      return res.status(400).json({
        status: "Error",
        message: "Unable to get data of the compulsory subject.",
      });
    }

    req.body.combinationSubject = combinationData._id;
    req.body.compulsorySubject = compulsoryData._id;
    const item = await SubjectAllocation.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSubjectAllocation };
