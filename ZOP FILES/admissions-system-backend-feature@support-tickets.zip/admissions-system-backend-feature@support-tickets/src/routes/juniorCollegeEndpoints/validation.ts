import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const combinationSchema = Joi.object({
  subjectCode: Joi.string(),
  preference: Joi.number(),
});

const combinationSubjectSchema = Joi.array()
  .items(combinationSchema)
  .unique();

const validationSchema = {
  createJcForm: Joi.object({
    candidateId: Joi.string().required(),
    programName: Joi.string().required(),
    collegeType: Joi.string().required(),
    programCode: Joi.string().required(),
    compulsorySubject: Joi.string().required(),
    combinationSubject: Joi.alternatives().try(
      combinationSchema,
      combinationSubjectSchema
    ),
    academicYear: Joi.string(),
    yearAppliedFor: Joi.string().required(),
  }),

  updateJcApplicant: Joi.object({
    prnNumber: Joi.string().required(),
  }),

  updateJcPersonal: Joi.object({
    personalDetails: Joi.object({
      aadharNumber: Joi.string().required().min(12).max(12),
      govPorEnrollNumber: Joi.string().required(),
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      fatherName: Joi.string().required(),
      motherName: Joi.string().required(),
      placeOfBirth: Joi.string().required(),
      dateOfBirth: Joi.string().required(),
      gender: Joi.string().required(),
      nationality: Joi.string().required(),
      bloodGroup: Joi.string().required(),
      motherTongue: Joi.string().required(),
      religion: Joi.string().required(),
      subCaste: Joi.string().required(),
      maritalStatus: Joi.string().required(),
      sikhMinority: Joi.string(),
      category: Joi.string(),
      collegeSetMinority: Joi.string(),
    }),
  }),

  updateJcContact: Joi.object({
    contactDetails: Joi.object({
      mobile: Joi.string().required().min(10).max(10),
      parentMobile: Joi.string().required().min(10).max(10),
      parentEmail: Joi.string().required().email({ minDomainSegments: 2 }),
      district: Joi.string().required(),
      address: Joi.string().required(),
      pinCode: Joi.string().required().min(6).max(6),
      state: Joi.string().required(),
    }),
  }),

  updateJcAcademic: Joi.object({
    jcAcademicDetails: Joi.object({
      examName: Joi.string().required(),
      boardName: Joi.string().required(),
      schoolName: Joi.string().required(),
      passingDate: Joi.string().required(),
      seatNumber: Joi.number().required(),
      totalMarks: Joi.number().required(),
      obtainedMarks: Joi.number().required(),
      percentage: Joi.number().required(),
    }),
  }),

  updateJcLegal: Joi.object({
    legalDetails: Joi.object({
      domicile: Joi.string().required(),
      reservationInformation: Joi.string().required(),
      parentAddress: Joi.string().required(),
      parentMobile: Joi.string().required().min(10).max(10),
      parentOccupation: Joi.string().required(),
      annualIncome: Joi.number().required(),
    }),
  }),

  updateJcDeclaration: Joi.object({
    declaration: Joi.object({
      termsCondition: Joi.boolean().required(),
    }),
  }),

  mandatoryDocuments: Joi.object({
    jcMandatoryDocuments: Joi.object({
      xLeavingCertificate: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),

      xMarksheet: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),

      aadharCard: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),
      
      signature: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),

      photo: Joi.object({
        documentName: Joi.string().required(),
        url: Joi.string().required(),
        submitted: Joi.boolean().required(),
        valid: Joi.boolean(),
        message: Joi.string(),
      }).required(),
    }),
  }),
};

const createJcFormValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createJcForm, req.body, next);

const updateJcApplicantValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcApplicant, req.body, next);

const updateJcPersonalValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcPersonal, req.body, next);

const updateJcContactValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcContact, req.body, next);

const updateJcAcademicValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcAcademic, req.body, next);

const updateJcLegalValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcLegal, req.body, next);

const updateJcDeclarationValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateJcDeclaration, req.body, next);

const updateMandatoryDocumentsValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.mandatoryDocuments, req.body, next);

export {
  createJcFormValidation,
  updateJcApplicantValidation,
  updateJcPersonalValidation,
  updateJcContactValidation,
  updateJcAcademicValidation,
  updateJcLegalValidation,
  updateJcDeclarationValidation,
  updateMandatoryDocumentsValidation,
};
