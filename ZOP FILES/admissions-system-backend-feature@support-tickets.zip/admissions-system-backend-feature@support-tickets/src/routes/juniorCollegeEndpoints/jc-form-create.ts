import { ApplicationForm } from "../../models/applicationForm";
import { RequestHandler } from "express";
import {
  createFormCounter,
  getFormCount,
  generateFormNo,
} from "../globalCounter/formGlobalCounter";

const createForm: RequestHandler = async (req, res, next) => {
  try {
    const count: number = await getFormCount();
    req.body.formNo = generateFormNo(count, req.body.programName);
    createFormCounter(count);
    req.body.typeOfForm = "JUNIOR";
    const item = await ApplicationForm.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createForm };
