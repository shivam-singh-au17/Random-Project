import express from "express";

import {
  createJcFormValidation,
  updateJcApplicantValidation,
  updateJcPersonalValidation,
  updateJcContactValidation,
  updateJcAcademicValidation,
  updateJcLegalValidation,
  updateJcDeclarationValidation,
  updateMandatoryDocumentsValidation,
} from "./validation";

import { createForm } from "./jc-form-create";
import { updateApplicant } from "./jc-form-applicant";
import { updatePersonal } from "./jc-form-personal";
import { updateContact } from "./jc-form-contact";
import { updateAcademic } from "./jc-form-academic";
import { updateLegal } from "./jc-form-legal";
import { updateDeclaration } from "./jc-form-declaration";
import { updateMandatoryDocuments } from "./jc-form-mandatory-documents";
import { getAllJcForms } from "./jc-form-get-all";

const router = express.Router();

router.post("/jc-form/create/", createJcFormValidation, createForm);

router.patch(
  "/jc-form/applicant/:id",
  updateJcApplicantValidation,
  updateApplicant
);

router.patch(
  "/jc-form/personal/:id",
  updateJcPersonalValidation,
  updatePersonal
);

router.patch("/jc-form/contact/:id", updateJcContactValidation, updateContact);

router.patch(
  "/jc-form/academic/:id",
  updateJcAcademicValidation,
  updateAcademic
);

router.patch("/jc-form/legal/:id", updateJcLegalValidation, updateLegal);

router.patch(
  "/jc-form/declaration/:id",
  updateJcDeclarationValidation,
  updateDeclaration
);

router.patch(
  "/jc-form/mandatory-documents/:id",
  updateMandatoryDocumentsValidation,
  updateMandatoryDocuments
);

router.get("/jc-form/forms/", getAllJcForms);

export { router as juniorCollegeEndpoints };
