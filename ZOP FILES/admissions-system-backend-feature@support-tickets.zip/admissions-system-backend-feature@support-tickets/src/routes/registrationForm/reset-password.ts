import { RegistrationFormService } from "../../models/registrationForm";
import { RequestHandler } from "express";
import bcrypt from "bcrypt";

const resetPassword: RequestHandler = async (req, res, next) => {
  try {
    // check if a user with that email already exists
    const user = await RegistrationFormService.findOne({
      email: req.body.email,
    }).exec();

    // if not user then throw an error
    if (!user) {
      return res.status(400).json({
        status: "Error",
        message: "This email is not registered",
      });
    }

    // if user then match the password
    const passwordHash = user.password;
    const match = new Promise((resolve, reject) => {
      bcrypt.compare(req.body.currentPassword, passwordHash, (err, same) => {
        if (err) {
          return reject(err);
        }
        resolve(same);
      });
    });

    // if not match then throw an error
    if (!(await match)) {
      return res.status(400).json({
        status: "error",
        message: "Wrong Current Password... try again",
      });
    }

    // if match then update email and password
    const passwordData = await bcrypt.hash(req.body.newPassword, 10);
    const updatedData = await RegistrationFormService.findByIdAndUpdate(
      user._id,
      { password: passwordData },
      { new: true }
    );

    // return updated data to the frontend
    return res.status(200).send(updatedData);
  } catch (error) {
    return next(error);
  }
};

export { resetPassword };
