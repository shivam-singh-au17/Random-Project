import { RegistrationFormService } from "../../models/registrationForm";
import { RequestHandler } from "express";

const updateProfile: RequestHandler = async (req, res, next) => {
  try {
    const item = await RegistrationFormService.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateProfile };
