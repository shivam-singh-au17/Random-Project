import { RegistrationFormService } from "../../models/registrationForm";
import { RequestHandler } from "express";

const getRegistrations: RequestHandler = async (req, res, next) => {
  try {
    const item = await RegistrationFormService.find()
      .select(
        "_id registrationNo applicationNo joined firstName lastName email phoneNumber picture emailUpdates smsUpdates"
      )
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getRegistrations };
