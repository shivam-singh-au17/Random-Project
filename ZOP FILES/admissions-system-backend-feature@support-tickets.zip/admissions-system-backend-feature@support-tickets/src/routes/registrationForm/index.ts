import {
  registrationValidation,
  updateProfileValidation,
  loginValidation,
  resetPasswordValidation,
} from "./validation";
import express from "express";
import { registration } from "./registration";
import { getRegistrations } from "./get-registrations";
import { updateProfile } from "./update-profile";
import { login } from "./login";
import { resetPassword } from "./reset-password";
import { changePassword } from "./change-password";
import { confirmRegistration } from "./confirm-registration";
import { forgetPassword } from "./forget-password";
const router = express.Router();

router.post("/registration/", registrationValidation, registration);
router.post("/login/", loginValidation, login);
router.get("/get-registrations/", getRegistrations);
router.patch("/update-profile/:id", updateProfileValidation, updateProfile);
router.patch("/reset-password", resetPasswordValidation, resetPassword);

// IAM For Auth Users.
router.patch("/change-password", changePassword);
router.post("/confirm-registration", confirmRegistration);
router.post("/forget-password", forgetPassword);

export { router as registrationForm };
