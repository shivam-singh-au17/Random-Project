import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  registration: Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().required().email({ minDomainSegments: 2 }),
    password: Joi.string().required().min(8).max(20),
    phoneNumber: Joi.string().min(10).max(10),
    picture: Joi.string(),
  }),

  updateProfile: Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    phoneNumber: Joi.string().required().min(10).max(10),
    picture: Joi.string().required(),
    emailUpdates: Joi.boolean().required(),
    smsUpdates: Joi.boolean().required(),
  }),

  login: Joi.object({
    email: Joi.string().required().email({ minDomainSegments: 2 }),
    password: Joi.string().required().min(8).max(20),
  }),

  resetPassword: Joi.object({
    email: Joi.string().required().email({ minDomainSegments: 2 }),
    currentPassword: Joi.string().required().min(8).max(20),
    newPassword: Joi.string().required().min(8).max(20),
    confirmPassword: Joi.string().required().min(8).max(20),
  }),
};

const registrationValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.registration, req.body, next);

const updateProfileValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateProfile, req.body, next);

const loginValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.login, req.body, next);

const resetPasswordValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.resetPassword, req.body, next);

export {
  registrationValidation,
  updateProfileValidation,
  loginValidation,
  resetPasswordValidation,
};
