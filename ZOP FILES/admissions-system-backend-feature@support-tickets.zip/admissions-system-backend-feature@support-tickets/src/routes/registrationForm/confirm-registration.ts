import { IdentityNAccess } from "../../integrations/microservices/identity-management-service";

const confirmRegistration = async (req, res) => {
  const { userName, verificationCode } = req.body;

  // identity-access-management service
  const { error, resData } = await IdentityNAccess.confirmRegistration({
    userName,
    verificationCode,
  });
  if (error) {
    return res.status(400).send(error); // request fulfilled with error.
  }

  return res.status(202).send(resData); // user confirmed updated success
};

export { confirmRegistration };
