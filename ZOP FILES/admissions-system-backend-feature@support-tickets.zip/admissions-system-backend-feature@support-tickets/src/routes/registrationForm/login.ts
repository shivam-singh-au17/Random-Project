import { RequestHandler } from "express";
import jwt from "jsonwebtoken";
import _ from "lodash";

import { jwtSecretKey } from "../../config";
import { IdentityNAccess } from "../../integrations/microservices/identity-management-service";
import { RegistrationFormService } from "../../models/registrationForm";

const login: RequestHandler = async (req, res, next) => {
  const { email, password } = req.body;
  try {
    // login user with identity-management-service get jwt & set cookie on response.
    const { error, resData } = await IdentityNAccess.signInUser({
      email: email,
      password: password,
    });
    const getCookeValue = (cookie: string) => {
      const cookies = _.split(cookie, ";");
      return _.split(cookies[0], "=")[1];
    };
    // return identity-management-service error if any.
    if (error) {
      return res.status(400).send(error);
    }
    // set jwt cookie on response.
    res.cookie("jwt", getCookeValue(resData.cookie[0]));
    // get registrations form.
    const item = await RegistrationFormService.findOne({
      email: req.body.email,
    })
      .select(
        "_id registrationNo applicationNo joined firstName lastName email phoneNumber picture emailUpdates smsUpdates"
      )
      .lean()
      .exec();
    // return the token to the frontend
    return res.status(200).json({ item, data: resData.data });
  } catch (error) {
    return next(error);
  }
};

export { login };
