import { IdentityNAccess } from "../../integrations/microservices/identity-management-service";
import cookie from "cookie";
import _ from "lodash";

const forgetPassword = async (req, res) => {
  const { email, verificationCode, newPassword } = req.body;
  // parsing cookie from req to check if user has request to initiate forget password.
  const reqCookies = cookie.parse(req.headers.cookie || "");
  const reqforgetPasswordRequest = reqCookies.forgetPasswordRequest;
  const data = reqforgetPasswordRequest
    ? { email, newPassword, verificationCode }
    : { email };

  // identity-access-management service
  const { error, resData } = await IdentityNAccess.forgetPassword(data, req);
  if (error) {
    return res.status(400).send(error); // request fulfilled with error.
  }
  const getCookeValue = (cookie: string) => {
    const cookies = _.split(cookie, ";");
    return _.split(cookies[0], "=")[1];
  };
  // response forgetPasswordRequest cookie from backend.
  const resforgetPasswordRequest = getCookeValue(resData.cookie[0]);
  // if forgetPassword cookie isn't set on client then set forgetPasswordRequest cookie to true.
  if (reqforgetPasswordRequest !== "true") {
    // if sign-in success & cookie jwt present on headers. set res cookies for browser.
    res.cookie("forgetPasswordRequest", resforgetPasswordRequest as string);
  }

  // [second request with code] if password is updated on backend. then remove the forgetPasswordRequest cookie from client.
  if (resData.status === 202) {
    res.clearCookie("forgetPasswordRequest");
  }

  return res.status(202).send(resData.data); // password updated success
};

export { forgetPassword };
