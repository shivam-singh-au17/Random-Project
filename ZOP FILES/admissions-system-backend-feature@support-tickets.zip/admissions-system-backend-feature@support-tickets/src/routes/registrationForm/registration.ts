import { RequestHandler, response } from "express";
import _ from "lodash";

import { IdentityNAccess } from "../../integrations/microservices/identity-management-service";
import { Roles } from "../../middlewares/authorizations/base/auth-roles";
import { RegistrationFormService } from "../../models/registrationForm";
import { createRegistrationCounter, generateRegistrationNo, getRegistrationCount } from "../globalCounter/registrationGlobalCounter";

const registration: RequestHandler = async (req, res, next) => {
  const { email, password } = req.body;

  try {
    // check if a user with that email already exists
    const user = await RegistrationFormService.findOne({
      email: req.body.email,
    }).exec();
    // if user exists then throw me error
    if (user) {
      return res
        .status(400)
        .json({ status: "Error", message: "User already exists" });
    }
    const count: number = await getRegistrationCount();
    req.body.registrationNo = generateRegistrationNo(count);
    createRegistrationCounter(count);

    // identity-management sdk class
    const { error, resData } = await IdentityNAccess.applicantSignUp({
      email: email,
      password: password,
      roles: [Roles.UserApplication],
      modules: ["ADMISSIONS"],
    });

    if (error) {
      return res.status(400).send(error);
    }
    // otherwise create a user and then hash the password
    const data = await RegistrationFormService.create(req.body);
    const item = await RegistrationFormService.findOne(data._id)
      .select(
        "_id registrationNo applicationNo joined firstName lastName email phoneNumber picture emailUpdates smsUpdates"
      )
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { registration };
