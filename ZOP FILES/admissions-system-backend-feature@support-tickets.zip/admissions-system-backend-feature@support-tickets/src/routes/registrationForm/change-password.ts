import { IdentityNAccess } from "../../integrations/microservices/identity-management-service";

const changePassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  // identity-access-management service
  const { error, resData } = await IdentityNAccess.changePassword(
    {
      currentPassword,
      newPassword,
    },
    req
  );
  if (error) {
    return res.status(400).send(error); // request fulfilled with error.
  }

  return res.status(202).send(resData); // password updated success
};

export { changePassword };
