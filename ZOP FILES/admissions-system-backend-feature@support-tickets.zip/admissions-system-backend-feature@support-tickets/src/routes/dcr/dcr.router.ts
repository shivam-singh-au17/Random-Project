import { Router } from "express";
import { getDCR } from "../../controllers/dcr/@dcr.controllers";
import { getComputeDCR } from "../../controllers/dcr/get-compute-dcr.controller";
import { DcrPolicy } from "../../middlewares/policies/dcr/@dcr.policies";

const router = Router();
// get all dcrs from collection
router.get("/dcrs", DcrPolicy.read(), getComputeDCR);

export { router as dcrRouter };
