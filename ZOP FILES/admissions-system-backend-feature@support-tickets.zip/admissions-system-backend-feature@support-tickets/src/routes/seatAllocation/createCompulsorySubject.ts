import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const createCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const checkItem = await SeatAllocation.findOne({
      programName: req.body.programName,
      yearAppliedFor: req.body.yearAppliedFor,
    })
      .lean()
      .exec();

    if (checkItem) {
      if (checkItem.compulsorySubject[0] === undefined) {
        const itemOne = await SeatAllocation.findByIdAndUpdate(
          checkItem._id,
          req.body,
          {
            new: true,
          }
        );
        return res.status(200).send(itemOne);
      }
      
      return res.status(400).send({
        status: "Error",
        message:
          "Data already available for programName and yearAppliedFor field.",
      });
    }

    const item = await SeatAllocation.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createCompulsorySubject };
