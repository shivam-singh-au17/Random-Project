import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const subjectAllocationOne: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { subjectAllocationOne };
