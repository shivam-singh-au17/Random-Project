import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const singleSubjectListAdd: RequestHandler = async (req, res, next) => {
  try {
    const checkItem = await SeatAllocation.findOne({
      programName: req.body.programName,
      yearAppliedFor: req.body.yearAppliedFor,
    })
      .lean()
      .exec();

    if (checkItem !== null) {
      const itemOne = await SeatAllocation.findByIdAndUpdate(
        checkItem._id,
        {
          $push: {
            allSingleSubjectList: {
              subjectName: req.body.subjectName,
              totalSeat: req.body.totalSeat,
            },
          },
        },
        {
          new: true,
        }
      );
      return res.status(200).send(itemOne);
    }

    return res.status(400).send({
      status: "Error",
      message: "Data not available for programName and yearAppliedFor field.",
    });
  } catch (error) {
    return next(error);
  }
};

export { singleSubjectListAdd };
