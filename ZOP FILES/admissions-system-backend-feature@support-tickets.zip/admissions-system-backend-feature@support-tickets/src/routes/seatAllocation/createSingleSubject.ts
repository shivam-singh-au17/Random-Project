import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const createSingleSubject: RequestHandler = async (req, res, next) => {
  try {
    const checkItem = await SeatAllocation.find({
      "singleCombinationSubject.subjectCombinationName":
        req.body.subjectCombinationName,
    })
      .lean()
      .exec();

    if (checkItem[0] !== undefined) {
      return res.status(400).send({
        status: "Error",
        message: "Data already available for subjectCombinationName.",
      });
    }

    const itemOne = await SeatAllocation.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          singleCombinationSubject: {
            subjectCombinationName: req.body.subjectCombinationName,
            subjectCombinationIds: req.body.subjectCombinationIds,
          },
        },
      },
      {
        new: true,
      }
    );
    return res.status(200).send(itemOne);
  } catch (error) {
    return next(error);
  }
};

export { createSingleSubject };
