import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const updateCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.updateOne(
      {
        _id: req.params.id,
        "compulsorySubject._id": req.params.compulsoryId,
      },
      {
        $set: {
          "compulsorySubject.$.subjectName": req.body.subjectName,
        },
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateCompulsorySubject };
