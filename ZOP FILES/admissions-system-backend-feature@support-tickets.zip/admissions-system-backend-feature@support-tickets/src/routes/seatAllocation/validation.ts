import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

// 1 groupCombinationSubject
const combinationSchema = Joi.object({
  subjectName: Joi.string(),
  totalSeat: Joi.number(),
});

const combinationSubjectSchema = Joi.array()
  .items(combinationSchema)
  .unique()
  .required();
// 1 groupCombinationSubject

// 2 createSingleSubject

const combinationSingleChildSchema = Joi.string().required();

const singleSubjectCombinationChildSchema = Joi.array()
  .items(combinationSingleChildSchema)
  .unique()
  .required();
// 2 createSingleSubject

// 3 allSingleSubjectList
const allSingleSchema = Joi.object({
  subjectName: Joi.string(),
  totalSeat: Joi.number(),
});

const singleSubjectSchema = Joi.array().items(allSingleSchema).unique();
// 3 allSingleSubjectList

// 4 compulsorySubject
const compulsorySchema = Joi.object({
  subjectName: Joi.string().required(),
}).required();

const compulsorySubjectSchema = Joi.array()
  .items(compulsorySchema)
  .unique()
  .required();
// 4 compulsorySubject

const validationSchema = {
  createCombinationSubject: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    isSemesterExam: Joi.boolean().required(),
    isSubjectGroup: Joi.boolean().required(),
    allSingleSubjectList: Joi.alternatives().try(
      allSingleSchema,
      singleSubjectSchema
    ),
    groupCombinationSubject: Joi.alternatives().try(
      combinationSchema,
      combinationSubjectSchema
    ),
  }),

  createSingleSubject: Joi.object({
    subjectCombinationName: Joi.string().required(),
    subjectCombinationIds: Joi.alternatives()
      .try(combinationSingleChildSchema, singleSubjectCombinationChildSchema)
      .required(),
  }),

  createCompulsorySubject: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    compulsorySubject: Joi.alternatives()
      .try(compulsorySchema, compulsorySubjectSchema)
      .required(),
  }),

  addCombinationSubject: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    subjectName: Joi.string().required(),
    totalSeat: Joi.number().required(),
  }),

  aadCompulsorySubject: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    subjectName: Joi.string().required(),
  }),

  updateCombinationSubject: Joi.object({
    subjectName: Joi.string().required(),
    totalSeat: Joi.number().required(),
  }),

  updateCompulsorySubject: Joi.object({
    subjectName: Joi.string().required(),
  }),

  singleSubjectListAdd: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    subjectName: Joi.string().required(),
    totalSeat: Joi.number().required(),
  }),

  updateSingleSubject: Joi.object({
    subjectName: Joi.string().required(),
    totalSeat: Joi.number().required(),
  }),
};

const createCombinationSubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createCombinationSubject, req.body, next);

const createSingleSubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createSingleSubject, req.body, next);

const createCompulsorySubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createCompulsorySubject, req.body, next);

const addCombinationSubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.addCombinationSubject, req.body, next);

const aadCompulsorySubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.aadCompulsorySubject, req.body, next);

const updateCombinationSubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateCombinationSubject, req.body, next);

const updateCompulsorySubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateCompulsorySubject, req.body, next);

const singleSubjectListAddValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.singleSubjectListAdd, req.body, next);

const updateSingleSubjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.updateSingleSubject, req.body, next);

export {
  createCombinationSubjectValidation,
  createCompulsorySubjectValidation,
  addCombinationSubjectValidation,
  aadCompulsorySubjectValidation,
  updateCombinationSubjectValidation,
  updateCompulsorySubjectValidation,
  singleSubjectListAddValidation,
  updateSingleSubjectValidation,
  createSingleSubjectValidation,
};
