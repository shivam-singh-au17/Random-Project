import express from "express";

import {
  createCombinationSubjectValidation,
  createCompulsorySubjectValidation,
  addCombinationSubjectValidation,
  aadCompulsorySubjectValidation,
  updateCombinationSubjectValidation,
  updateCompulsorySubjectValidation,
  singleSubjectListAddValidation,
  updateSingleSubjectValidation,
  createSingleSubjectValidation,
} from "./validation";

import { createCombinationSubject } from "./createCombinationSubject";
import { createSingleSubject } from "./createSingleSubject";
import { createCompulsorySubject } from "./createCompulsorySubject";
import { addCombinationSubject } from "./addCombinationSubject";
import { aadCompulsorySubject } from "./aadCompulsorySubject";
import { updateCombinationSubject } from "./updateCombinationSubject";
import { updateCompulsorySubject } from "./updateCompulsorySubject";
import { subjectAllocationAll } from "./subjectAllocationAll";
import { subjectAllocationOne } from "./subjectAllocationOne";
import { subjectAllocationByProgramAndYear } from "./subjectAllocationByProgramAndYear";
import { singleSubjectListAdd } from "./singleSubjectListAdd";
import { updateSingleSubject } from "./updateSingleSubject";
import { deleteCombinationSubject } from "./deleteCombinationSubject";
import { deleteCompulsorySubject } from "./deleteCompulsorySubject";
import { deleteSingleSubject } from "./deleteSingleSubject";

const router = express.Router();

router.post(
  "/combination/subject/create",
  createCombinationSubjectValidation,
  createCombinationSubject
);

router.patch(
  "/single/subject/create/:id",
  createSingleSubjectValidation,
  createSingleSubject
);

router.post(
  "/compulsory/subject/create",
  createCompulsorySubjectValidation,
  createCompulsorySubject
);

router.patch(
  "/combination/subject/add",
  addCombinationSubjectValidation,
  addCombinationSubject
);

router.patch(
  "/compulsory/subject/add",
  aadCompulsorySubjectValidation,
  aadCompulsorySubject
);

router.patch(
  "/combination/subject/update/:id/:combinationId",
  updateCombinationSubjectValidation,
  updateCombinationSubject
);

router.delete(
  "/combination/subject/delete/:id/:combinationId",
  deleteCombinationSubject
);

router.patch(
  "/compulsory/subject/update/:id/:compulsoryId",
  updateCompulsorySubjectValidation,
  updateCompulsorySubject
);

router.delete(
  "/compulsory/subject/delete/:id/:compulsoryId",
  deleteCompulsorySubject
);

router.patch(
  "/single/subject-list/add",
  singleSubjectListAddValidation,
  singleSubjectListAdd
);

router.patch(
  "/single/subject-list/update/:id/:singleId",
  updateSingleSubjectValidation,
  updateSingleSubject
);

router.delete("/single/subject-list/delete/:id/:singleId", deleteSingleSubject);

router.get("/subject/allocation/get", subjectAllocationAll);

router.get("/subject/allocation/one/:id", subjectAllocationOne);

router.get(
  "/subject/allocation/:programName/:yearAppliedFor",
  subjectAllocationByProgramAndYear
);

export { router as seatAllocation };
