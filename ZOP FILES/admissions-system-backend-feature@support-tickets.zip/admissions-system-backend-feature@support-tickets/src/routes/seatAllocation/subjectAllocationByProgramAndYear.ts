import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const subjectAllocationByProgramAndYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.find({
      programName: req.params.programName,
      yearAppliedFor: req.params.yearAppliedFor,
    })
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { subjectAllocationByProgramAndYear };
