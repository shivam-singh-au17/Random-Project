import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const deleteCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.updateOne(
      { _id: req.params.id },
      { $pull: { compulsorySubject: { _id: req.params.compulsoryId } } }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteCompulsorySubject };
