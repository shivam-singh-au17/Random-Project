import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const createCombinationSubject: RequestHandler = async (req, res, next) => {
  try {
    if (req.body.isSemesterExam === true) {
      return res.status(400).send({
        status: "Error",
        message:
          "For now, there is no functionality available if the semester exam status is true.",
      });
    }

    if (
      req.body.isSubjectGroup === true &&
      req.body.allSingleSubjectList !== undefined
    ) {
      return res.status(400).send({
        status: "Error",
        message:
          "If you are sending the status of isSubjectGroup true then in this condition you cannot send allSingleSubjectList.",
      });
    }

    if (
      req.body.isSubjectGroup === true &&
      req.body.groupCombinationSubject === undefined
    ) {
      return res.status(400).send({
        status: "Error",
        message: "groupCombinationSubject is required",
      });
    }

    if (
      req.body.isSubjectGroup === false &&
      req.body.groupCombinationSubject !== undefined
    ) {
      return res.status(400).send({
        status: "Error",
        message:
          "If you are sending the status of isSubjectGroup false then in this condition you cannot send groupCombinationSubject.",
      });
    }

    
    if (
      req.body.isSubjectGroup === false &&
      req.body.allSingleSubjectList === undefined
    ) {
      return res.status(400).send({
        status: "Error",
        message: "allSingleSubjectList is required",
      });
    }

    const checkItem = await SeatAllocation.findOne({
      programName: req.body.programName,
      yearAppliedFor: req.body.yearAppliedFor,
    })
      .lean()
      .exec();

    if (checkItem !== null) {
      if (
        checkItem.compulsorySubject[0] !== undefined &&
        checkItem.isSubjectGroup === undefined
      ) {
        const itemOne = await SeatAllocation.findByIdAndUpdate(
          checkItem._id,
          req.body,
          {
            new: true,
          }
        );
        return res.status(200).send(itemOne);
      }

      return res.status(400).send({
        status: "Error",
        message:
          "Data already available for programName and yearAppliedFor field.",
      });
    }

    const item = await SeatAllocation.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createCombinationSubject };
