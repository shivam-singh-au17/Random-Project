import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const deleteSingleSubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.updateOne(
      { _id: req.params.id },
      { $pull: { allSingleSubjectList: { _id: req.params.singleId } } }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteSingleSubject };
