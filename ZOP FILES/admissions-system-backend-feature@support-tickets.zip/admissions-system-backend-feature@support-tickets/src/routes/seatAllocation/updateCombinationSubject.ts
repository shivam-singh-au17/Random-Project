import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const updateCombinationSubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.updateOne(
      {
        _id: req.params.id,
        "groupCombinationSubject._id": req.params.combinationId,
      },
      {
        $set: {
          "groupCombinationSubject.$.subjectName": req.body.subjectName,
          "groupCombinationSubject.$.totalSeat": req.body.totalSeat,
        },
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateCombinationSubject };
