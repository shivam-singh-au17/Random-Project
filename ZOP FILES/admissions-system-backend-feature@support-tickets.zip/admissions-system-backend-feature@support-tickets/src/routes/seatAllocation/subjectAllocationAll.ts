import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const subjectAllocationAll: RequestHandler = async (req, res, next) => {
  try {
    if (
      req.query.id !== undefined &&
      req.query.programName === undefined &&
      req.query.yearAppliedFor === undefined
    ) {
      const itemOne = await SeatAllocation.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }

    if (
      req.query.id === undefined &&
      req.query.programName !== undefined &&
      req.query.yearAppliedFor !== undefined
    ) {
      const itemSix = await SeatAllocation.find({
        programName: req.query.programName,
        yearAppliedFor: req.query.yearAppliedFor,
      })
        .lean()
        .exec();
      return res.status(200).send(itemSix);
    }

    const item = await SeatAllocation.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { subjectAllocationAll };
