import { SeatAllocation } from "../../models/seatAllocation";
import { RequestHandler } from "express";

const updateSingleSubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await SeatAllocation.updateOne(
      {
        _id: req.params.id,
        "allSingleSubjectList._id": req.params.singleId,
      },
      {
        $set: {
          "allSingleSubjectList.$.subjectName": req.body.subjectName,
          "allSingleSubjectList.$.totalSeat": req.body.totalSeat,
        },
      }
    );
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateSingleSubject };
