import { AcademicYear } from "../../models/academicYear";
import { RequestHandler } from "express";

const createAcademicYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await AcademicYear.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createAcademicYear };
