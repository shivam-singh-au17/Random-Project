import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createAcademicYear } from "./create-academicYear";
import { getAcademicYear } from "./get-academicYear";
import { getOneAcademicYear } from "./get-one-academicYear";
import { deleteAcademicYear } from "./delete-academicYear";
import { updateAcademicYear } from "./update-academicYear";

const router = express.Router();

router.post("/create-academicYear/", createValidation, createAcademicYear);

router.get("/get-academicYear/", getAcademicYear);

router.get("/get-one-academicYear/:id", getOneAcademicYear);

router.delete("/delete-academicYear/:id", deleteAcademicYear);

router.patch("/update-academicYear/:id", updateValidation, updateAcademicYear);

export { router as academicYear };
