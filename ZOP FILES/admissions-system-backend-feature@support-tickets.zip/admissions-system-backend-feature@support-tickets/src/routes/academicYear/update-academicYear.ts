import { AcademicYear } from "../../models/academicYear";
import { RequestHandler } from "express";

const updateAcademicYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await AcademicYear.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateAcademicYear };
