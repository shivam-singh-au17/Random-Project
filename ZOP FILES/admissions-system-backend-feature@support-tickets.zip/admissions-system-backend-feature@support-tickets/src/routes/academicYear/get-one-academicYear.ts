import { AcademicYear } from "../../models/academicYear";
import { RequestHandler } from "express";

const getOneAcademicYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await AcademicYear.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneAcademicYear };
