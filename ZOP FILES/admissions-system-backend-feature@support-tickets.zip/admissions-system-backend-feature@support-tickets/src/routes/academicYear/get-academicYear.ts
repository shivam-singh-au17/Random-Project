import { AcademicYear } from "../../models/academicYear";
import { RequestHandler } from "express";

const getAcademicYear: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await AcademicYear.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await AcademicYear.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAcademicYear };
