import { AcademicYear } from "../../models/academicYear";
import { RequestHandler } from "express";

const deleteAcademicYear: RequestHandler = async (req, res, next) => {
  try {
    const item = await AcademicYear.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteAcademicYear };
