import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSetupDegree } from "./create-setupDegree";
import { getSetupDegree } from "./get-setupDegree";
import { getOneSetupDegree } from "./get-one-setupDegree";
import { deleteSetupDegree } from "./delete-setupDegree";
import { updateSetupDegree } from "./update-setupDegree";
import { SetupsPolicy } from "../../middlewares/policies/setups/@setups.policies";

const router = express.Router();

router.post(
  "/create-setupDegree/",
  SetupsPolicy.create(),
  createValidation,
  createSetupDegree
);

router.get("/get-setupDegree/", SetupsPolicy.read(), getSetupDegree);

router.get("/get-one-setupDegree/:id", SetupsPolicy.read(), getOneSetupDegree);

router.delete(
  "/delete-setupDegree/:id",
  SetupsPolicy.delete(),
  deleteSetupDegree
);

router.patch(
  "/update-setupDegree/:id",
  SetupsPolicy.update(),
  updateValidation,
  updateSetupDegree
);

export { router as setupDegree };
