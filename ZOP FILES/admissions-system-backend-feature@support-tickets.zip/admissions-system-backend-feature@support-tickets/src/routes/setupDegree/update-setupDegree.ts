import { SetupDegree } from "../../models/setupDegree";
import { RequestHandler } from "express";

const updateSetupDegree: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupDegree.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateSetupDegree };
