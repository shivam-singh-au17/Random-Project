import { SetupDegree } from "../../models/setupDegree";
import { RequestHandler } from "express";

const createSetupDegree: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupDegree.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSetupDegree };
