import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createFeeStructureCodes } from "./create-feeStructureCodes";
import { getFeeStructureCodes } from "./get-feeStructureCodes";
import { deleteFeeStructureCodes } from "./delete-feeStructureCodes";
import { updateFeeStructureCodes } from "./update-feeStructureCodes";
import { FeeStructurePolicy } from "../../middlewares/policies/feeStructure/@feeStructure.policies";

const router = express.Router();
router.post(
  "/create-feeStructureCodes/",
  FeeStructurePolicy.create(),
  createValidation,
  createFeeStructureCodes
);

router.get(
  "/get-feeStructureCodes/",
  FeeStructurePolicy.read(),
  getFeeStructureCodes
);

router.delete(
  "/delete-feeStructureCodes/:id",
  FeeStructurePolicy.delete(),
  deleteFeeStructureCodes
);

router.patch(
  "/update-feeStructureCodes/:id",
  FeeStructurePolicy.update(),
  updateValidation,
  updateFeeStructureCodes
);

export { router as feeStructureCodes };
