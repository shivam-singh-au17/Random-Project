import { FeeStructureCodes } from "../../models/feeStructureCodes";
import { RequestHandler } from "express";

const getFeeStructureCodes: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await FeeStructureCodes.findById(req.query.id)
        .populate("categoryType")
        .populate("programName")
        .populate("departmentName")
        .populate("selectHeads.selectedHeads")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await FeeStructureCodes.find()
      .populate("categoryType")
      .populate("programName")
      .populate("departmentName")
      .populate("selectHeads.selectedHeads")
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getFeeStructureCodes };
