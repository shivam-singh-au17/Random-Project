import { FeeStructureCodes } from "../../models/feeStructureCodes";
import { RequestHandler } from "express";

const deleteFeeStructureCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await FeeStructureCodes.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteFeeStructureCodes };
