import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

// 1 selectHeads
const selectHeadSchema = Joi.object({
  selectedHeads: Joi.string().required(),
  amount: Joi.number().required(),
}).required();

const selectHeadArraySchema = Joi.array()
  .items(selectHeadSchema)
  .unique()
  .required();
// 1 selectHeads

// 2 TAGS
const TAGSSchema = Joi.string().required();

const TAGSTypeSchema = Joi.array().items(TAGSSchema).unique();
// 2 TAGS

const validationSchema = {
  create: Joi.object({
    name: Joi.string().required(),
    collegeType: Joi.string().required(),
    categoryType: Joi.string().required(),
    programName: Joi.string().required(),
    departmentName: Joi.string().required(),
    yearAppliedFor: Joi.string().required().max(3),
    selectHeads: Joi.alternatives()
      .try(selectHeadSchema, selectHeadArraySchema)
      .required(),
    META: Joi.object({
      TAGS: Joi.alternatives().try(TAGSSchema, TAGSTypeSchema),
    }),
  }),

  update: Joi.object({
    name: Joi.string().required(),
    collegeType: Joi.string().required(),
    categoryType: Joi.string().required(),
    programName: Joi.string().required(),
    departmentName: Joi.string().required(),
    yearAppliedFor: Joi.string().required().max(3),
    selectHeads: Joi.alternatives()
      .try(selectHeadSchema, selectHeadArraySchema)
      .required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
