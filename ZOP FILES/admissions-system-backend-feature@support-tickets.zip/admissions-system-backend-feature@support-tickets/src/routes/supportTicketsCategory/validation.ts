import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  create: Joi.object({
    categoryName: Joi.string().required(),
    assignCategoryPerson: Joi.string()
      .required()
      .email({ minDomainSegments: 2 }),
    description: Joi.string().required(),
  }),

  update: Joi.object({
    categoryName: Joi.string().required(),
    assignCategoryPerson: Joi.string()
      .required()
      .email({ minDomainSegments: 2 }),
    description: Joi.string().required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
