import { SupportTicketsCategory } from "../../models/supportTicketsCategory";
import { RequestHandler } from "express";

const getSupportTicketsCategory: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await SupportTicketsCategory.findById(req.query.id)
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await SupportTicketsCategory.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getSupportTicketsCategory };
