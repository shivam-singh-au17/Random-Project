import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSupportTicketsCategory } from "./create-supportTicketsCategory";
import { getSupportTicketsCategory } from "./get-supportTicketsCategory";
import { getOneSupportTicketsCategory } from "./get-one-supportTicketsCategory";
import { deleteSupportTicketsCategory } from "./delete-supportTicketsCategory";
import { updateSupportTicketsCategory } from "./update-supportTicketsCategory";

const router = express.Router();

router.post("/support/tickets/category", createValidation, createSupportTicketsCategory);

router.get("/support/tickets/categorys", getSupportTicketsCategory);

router.get("/support/tickets/category/:id", getOneSupportTicketsCategory);

router.delete("/support/tickets/category/:id", deleteSupportTicketsCategory);

router.patch("/support/tickets/category/:id", updateValidation, updateSupportTicketsCategory);

export { router as supportTicketsCategory };
