import { NextFunction, Request, Response } from "express";
import joi, { required, string } from "joi";

import validateParams from "../../../middlewares/validateParams";

// schema
const schema = joi.object({
  razorpayPaymentId: joi.string().required(),
  razorpayOrderId: joi.string().required(),
  razorpaySignature: joi.string().required(),
  amount: joi.string().required(),
  payment_name: joi.string().required(),
  candidateId: joi.string().required(),
  paymentMethod: joi.string(),
});

const validation = (req: Request, res: Response, next: NextFunction) =>
  validateParams(schema, req.body, next);
export { validation };
