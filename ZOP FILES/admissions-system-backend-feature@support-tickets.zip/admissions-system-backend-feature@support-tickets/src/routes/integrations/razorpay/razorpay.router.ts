import { Router } from "express";

import { createOrder, verifyPaymentAuthenticity } from "../../../controllers/integrations/razorpay/@razorpay.controllers";
import { createInvoiceAPI } from "../../../controllers/invoice/create-invoice.controller";
import { updateNewPaymentHistory } from "../../../controllers/payments/update-payment-history.controller";
import { requireAuth } from "../../../middlewares/authentications/require-auth";
import { validation } from "./_razorpay.validation";

const router = Router();

// creates new razorpay order.
router.get("/payment/:payment_name", requireAuth, createOrder);

// verify payment from client & razorpay.
router.post(
  "/payment",
  validation, // validation for paymentAuthN route
  verifyPaymentAuthenticity,
  createInvoiceAPI,
  updateNewPaymentHistory
);
export { router as razorpayIntegrationRouter };
