import { SupportTicketCounter } from "../../models/globalCounter";

const getSupportTicketCount = async () => {
  const itemData = await SupportTicketCounter.find().lean().exec();
  const countData = itemData[0];
  if (countData === undefined) {
    return 1;
  } else {
    const count = countData.supportTicketCount;
    const ans = Number(count);
    return ans;
  }
};

const generateSupportTicketCount = (countData: number) => {
  const flag = "TN";
  const newString = String(countData);
  const zeroToGentrate: number = 5 - newString.length;
  let zeroStr = "";
  let i: number;
  for (i = 0; i < zeroToGentrate; i++) {
    zeroStr += "0";
  }
  return flag + zeroStr + newString;
};

const createSupportTicketCounter = async (count: number) => {
  const itemData = await SupportTicketCounter.find().lean().exec();

  if (itemData[0] === undefined) {
    await SupportTicketCounter.create({
      supportTicketCount: count + 1,
    });
  } else {
    const itemId = itemData[0]._id;
    await SupportTicketCounter.findByIdAndUpdate(
      itemId,
      {
        supportTicketCount: count + 1,
      },
      { new: true }
    );
  }
};

export {
  createSupportTicketCounter,
  getSupportTicketCount,
  generateSupportTicketCount,
};
