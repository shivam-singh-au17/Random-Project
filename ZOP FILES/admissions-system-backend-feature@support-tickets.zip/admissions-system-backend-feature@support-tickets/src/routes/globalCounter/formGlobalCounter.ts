import { FormCounterService } from "../../models/globalCounter";

const getFormCount = async () => {
  const itemData = await FormCounterService.find().lean().exec();
  const countData = itemData[0];
  if (countData === undefined) {
    return 1;
  } else {
    const count = countData.formNoCount;
    const ans = Number(count);
    return ans;
  }
};

const generateFormNo = (countData: number, code: string) => {
  const date: number = new Date().getFullYear();
  const res: string = String(date).split("0")[1];
  const flag: string = res + (Number(res) + 1);
  const newString = String(countData);
  const zeroToGentrate: number = 5 - newString.length;
  let zeroStr = "";
  let i: number;
  for (i = 0; i < zeroToGentrate; i++) {
    zeroStr += "0";
  }
  return code + flag + zeroStr + newString;
};

const createFormCounter = async (count: number) => {
  const itemData = await FormCounterService.find().lean().exec();

  if (itemData[0] === undefined) {
    await FormCounterService.create({
      formNoCount: count + 1,
    });
  } else {
    const itemId = itemData[0]._id;
    await FormCounterService.findByIdAndUpdate(
      itemId,
      {
        formNoCount: count + 1,
      },
      { new: true }
    );
  }
};

export { createFormCounter, getFormCount, generateFormNo };
