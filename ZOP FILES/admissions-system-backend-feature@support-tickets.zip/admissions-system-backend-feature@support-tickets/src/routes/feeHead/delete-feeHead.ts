import { FeeHead } from "../../models/feeHead";
import { RequestHandler } from "express";

const deleteFeeHead: RequestHandler = async (req, res, next) => {
  try {
    const item = await FeeHead.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteFeeHead };
