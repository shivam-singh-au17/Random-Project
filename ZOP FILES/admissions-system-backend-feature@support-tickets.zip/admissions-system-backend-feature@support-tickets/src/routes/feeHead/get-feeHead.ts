import { FeeHead } from "../../models/feeHead";
import { RequestHandler } from "express";

const getFeeHead: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await FeeHead.findById(req.query.id)
        .populate("category")
        .populate("bankAccount")
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await FeeHead.find()
      .populate("category")
      .populate("bankAccount")
      .lean()
      .exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getFeeHead };
