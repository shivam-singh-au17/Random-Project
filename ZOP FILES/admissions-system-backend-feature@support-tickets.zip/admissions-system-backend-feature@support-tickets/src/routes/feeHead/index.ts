import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createFeeHead } from "./create-feeHead";
import { getFeeHead } from "./get-feeHead";
import { deleteFeeHead } from "./delete-feeHead";
import { updateFeeHead } from "./update-feeHead";

const router = express.Router();

router.post("/create-feeHead/", createValidation, createFeeHead);

router.get("/get-feeHead/", getFeeHead);

router.delete("/delete-feeHead/:id", deleteFeeHead);

router.patch("/update-feeHead/:id", updateValidation, updateFeeHead);

export { router as feeHead };
