import { FeeHead } from "../../models/feeHead";
import { RequestHandler } from "express";

const createFeeHead: RequestHandler = async (req, res, next) => {
  try {
    const item = await FeeHead.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createFeeHead };
