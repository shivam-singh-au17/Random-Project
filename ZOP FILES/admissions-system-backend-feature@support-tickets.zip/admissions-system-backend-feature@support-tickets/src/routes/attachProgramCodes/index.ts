import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createAttachProgramCodes } from "./create-attachProgramCodes";
import { getAttachProgramCodes } from "./get-attachProgramCodes";
import { deleteAttachProgramCodes } from "./delete-attachProgramCodes";
import { updateAttachProgramCodes } from "./update-attachProgramCodes";

const router = express.Router();

router.post("/create-attachProgramCodes/", createValidation, createAttachProgramCodes);

router.get("/get-attachProgramCodes/", getAttachProgramCodes);

router.delete("/delete-attachProgramCodes/:id", deleteAttachProgramCodes);

router.patch("/update-attachProgramCodes/:id", updateValidation, updateAttachProgramCodes);

export { router as attachProgramCodes };
