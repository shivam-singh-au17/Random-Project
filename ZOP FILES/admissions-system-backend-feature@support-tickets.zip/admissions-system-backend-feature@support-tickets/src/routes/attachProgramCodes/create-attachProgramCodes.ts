import { AttachProgramCodes } from "../../models/attachProgramCodes";
import { RequestHandler } from "express";

const createAttachProgramCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachProgramCodes.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createAttachProgramCodes };
