import { AttachProgramCodes } from "../../models/attachProgramCodes";
import { RequestHandler } from "express";

const getAttachProgramCodes: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await AttachProgramCodes.findById(req.query.id)
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await AttachProgramCodes.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAttachProgramCodes };
