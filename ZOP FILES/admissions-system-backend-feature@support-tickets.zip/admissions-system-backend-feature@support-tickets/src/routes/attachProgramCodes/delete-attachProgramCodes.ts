import { AttachProgramCodes } from "../../models/attachProgramCodes";
import { RequestHandler } from "express";

const deleteAttachProgramCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachProgramCodes.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteAttachProgramCodes };
