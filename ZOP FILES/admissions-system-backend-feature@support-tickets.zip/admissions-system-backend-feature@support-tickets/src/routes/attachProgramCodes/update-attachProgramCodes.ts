import { AttachProgramCodes } from "../../models/attachProgramCodes";
import { RequestHandler } from "express";

const updateAttachProgramCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachProgramCodes.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateAttachProgramCodes };
