import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSetupDepartment } from "./create-setupDepartment";
import { getSetupDepartment } from "./get-setupDepartment";
import { getOneSetupDepartment } from "./get-one-setupDepartment";
import { deleteSetupDepartment } from "./delete-setupDepartment";
import { updateSetupDepartment } from "./update-setupDepartment";
import { SetupsPolicy } from "../../middlewares/policies/setups/@setups.policies";

const router = express.Router();
router.post(
  "/create-setupDepartment/",
  SetupsPolicy.create(),
  createValidation,
  createSetupDepartment
);

router.get("/get-setupDepartment/", SetupsPolicy.read(), getSetupDepartment);

router.get(
  "/get-one-setupDepartment/:id",
  SetupsPolicy.read(),
  getOneSetupDepartment
);

router.delete(
  "/delete-setupDepartment/:id",
  SetupsPolicy.delete(),
  deleteSetupDepartment
);

router.patch(
  "/update-setupDepartment/:id",
  SetupsPolicy.update(),
  updateValidation,
  updateSetupDepartment
);

export { router as setupDepartment };
