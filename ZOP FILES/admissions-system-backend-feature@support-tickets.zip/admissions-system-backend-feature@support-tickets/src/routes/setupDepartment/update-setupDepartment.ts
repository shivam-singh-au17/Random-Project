import { SetupDepartment } from "../../models/setupDepartment";
import { RequestHandler } from "express";

const updateSetupDepartment: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupDepartment.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateSetupDepartment };
