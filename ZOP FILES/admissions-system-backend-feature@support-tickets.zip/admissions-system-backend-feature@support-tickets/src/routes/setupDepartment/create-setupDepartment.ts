import { SetupDepartment } from "../../models/setupDepartment";
import { RequestHandler } from "express";

const createSetupDepartment: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupDepartment.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSetupDepartment };
