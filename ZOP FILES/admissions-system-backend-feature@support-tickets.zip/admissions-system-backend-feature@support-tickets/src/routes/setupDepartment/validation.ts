import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  create: Joi.object({
    departmentName: Joi.string().required(),
    status: Joi.boolean(),
  }),

  update: Joi.object({
    departmentName: Joi.string().required(),
    status: Joi.boolean(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
