import { SetupDepartment } from "../../models/setupDepartment";
import { RequestHandler } from "express";

const deleteSetupDepartment: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupDepartment.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteSetupDepartment };
