import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createDisability } from "./create-disability";
import { getDisability } from "./get-disability";
import { getOneDisability } from "./get-one-disability";
import { deleteDisability } from "./delete-disability";
import { updateDisability } from "./update-disability";

const router = express.Router();

router.post("/create-disability/", createValidation, createDisability);

router.get("/get-disability/", getDisability);

router.get("/get-one-disability/:id", getOneDisability);

router.delete("/delete-disability/:id", deleteDisability);

router.patch("/update-disability/:id", updateValidation, updateDisability);

export { router as disability };
