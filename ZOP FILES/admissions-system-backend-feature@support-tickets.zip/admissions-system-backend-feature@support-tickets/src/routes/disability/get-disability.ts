import { Disability } from "../../models/disability";
import { RequestHandler } from "express";

const getDisability: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await Disability.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await Disability.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getDisability };
