import { Disability } from "../../models/disability";
import { RequestHandler } from "express";

const createDisability: RequestHandler = async (req, res, next) => {
  try {
    const item = await Disability.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createDisability };
