import {
  staffRegistrationValidation,
  staffLoginValidation,
  staffResetPasswordValidation,
} from "./validation";
import express from "express";
import { staffRegistration } from "./staff-registration";
import { getStaffRegistrations } from "./staff-get-registrations";
import { staffLogin } from "./staff-login";
import { staffResetPassword } from "./staff-reset-password";
const router = express.Router();

router.post(
  "/staff-registration/",
  staffRegistrationValidation,
  staffRegistration
);

router.post("/staff-login/", staffLoginValidation, staffLogin);

router.get("/staff-get-registrations/", getStaffRegistrations);

router.patch(
  "/staff-reset-password",
  staffResetPasswordValidation,
  staffResetPassword
);

export { router as staffAppRegistration };
