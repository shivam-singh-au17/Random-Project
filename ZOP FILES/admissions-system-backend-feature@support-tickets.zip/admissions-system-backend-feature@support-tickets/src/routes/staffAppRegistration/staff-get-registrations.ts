import { StaffAppRegistrationService } from "../../models/staffAppRegistration";
import { RequestHandler } from "express";

const getStaffRegistrations: RequestHandler = async (req, res, next) => {
  try {
    const item = await StaffAppRegistrationService.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getStaffRegistrations };
