import { StaffAppRegistrationService } from "../../models/staffAppRegistration";
import { RequestHandler } from "express";
import {
  createRegistrationCounter,
  getRegistrationCount,
  generateRegistrationNo,
} from "../globalCounter/registrationGlobalCounter";

const staffRegistration: RequestHandler = async (req, res, next) => {
  try {
    // check if a user with that email already exists
    const user = await StaffAppRegistrationService.findOne({
      email: req.body.email,
    }).exec();

    // if user exists then throw me error
    if (user) {
      return res
        .status(400)
        .json({ status: "Error", message: "User already exists" });
    }

    const count: number = await getRegistrationCount();
    req.body.registrationNo = generateRegistrationNo(count);
    createRegistrationCounter(count);

    // otherwise create a user and then hash the password
    const item = await StaffAppRegistrationService.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { staffRegistration };
