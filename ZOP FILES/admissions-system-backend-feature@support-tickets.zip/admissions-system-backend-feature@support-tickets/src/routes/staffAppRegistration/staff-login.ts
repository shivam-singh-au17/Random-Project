import { StaffAppRegistrationService } from "../../models/staffAppRegistration";
import { RequestHandler } from "express";
import jwt from "jsonwebtoken";
import { jwtSecretKey } from "../../config";
import bcrypt from "bcrypt";

const newToken = (user: object) => {
  return jwt.sign({ user: user }, jwtSecretKey);
};

const staffLogin: RequestHandler = async (req, res, next) => {
  try {
    // check if a user with that email already exists
    const user = await StaffAppRegistrationService.findOne({
      email: req.body.email,
    }).exec();

    // if not user then throw an error
    if (!user) {
      return res.status(400).json({
        status: "Error",
        message: "You are not registered so register first",
      });
    }

    // if user then match the password
    const passwordHash = user.password;

    const match = new Promise((resolve, reject) => {
      bcrypt.compare(req.body.password, passwordHash, (err, same) => {
        if (err) {
          return reject(err);
        }
        resolve(same);
      });
    });

    // if not match then throw an error
    if (!(await match)) {
      return res.status(400).json({
        status: "Error",
        message: "Wrong Password or Email... Try again",
      });
    }

    // if match then create the token
    const token = newToken(user);

    // return the token to the frontend
    return res.status(200).json({ user, token });
  } catch (error) {
    return next(error);
  }
};

export { staffLogin };
