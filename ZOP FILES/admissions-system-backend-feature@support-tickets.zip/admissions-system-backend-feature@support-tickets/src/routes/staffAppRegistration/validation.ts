import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  stafRegistration: Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().required(),
    password: Joi.string().required().min(8).max(20),
    phoneNumber: Joi.string().min(10).max(10),
    picture: Joi.string(),
  }),

  staffLogin: Joi.object({
    email: Joi.string().required(),
    password: Joi.string().required().min(8).max(20),
  }),

  staffResetPassword: Joi.object({
    email: Joi.string().required(),
    currentPassword: Joi.string().required().min(8).max(20),
    newPassword: Joi.string().required().min(8).max(20),
    confirmPassword: Joi.string().required().min(8).max(20),
  }),
};

const staffRegistrationValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.stafRegistration, req.body, next);

const staffLoginValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.staffLogin, req.body, next);

const staffResetPasswordValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.staffResetPassword, req.body, next);

export {
  staffRegistrationValidation,
  staffLoginValidation,
  staffResetPasswordValidation,
};
