import { freezeSeatController } from "../../../controllers/userActions/meritList/freezeSeat.controller";

import { Router } from "express";

const router = Router();
// takes user_id & +1 step counter for user to make eligible for payment.
router.get("/freeze-seat/:user_id", freezeSeatController);

export { router as freezeSeatRouter };
