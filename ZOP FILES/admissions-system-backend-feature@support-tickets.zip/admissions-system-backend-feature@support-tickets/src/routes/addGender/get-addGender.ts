import { AddGender } from "../../models/addGender";
import { RequestHandler } from "express";

const getAddGender: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await AddGender.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await AddGender.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAddGender };
