import { AddGender } from "../../models/addGender";
import { RequestHandler } from "express";

const deleteAddGender: RequestHandler = async (req, res, next) => {
  try {
    const item = await AddGender.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteAddGender };
