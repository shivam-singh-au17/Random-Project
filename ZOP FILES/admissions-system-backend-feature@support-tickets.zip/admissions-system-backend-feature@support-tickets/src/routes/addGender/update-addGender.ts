import { AddGender } from "../../models/addGender";
import { RequestHandler } from "express";

const updateAddGender: RequestHandler = async (req, res, next) => {
  try {
    const item = await AddGender.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateAddGender };
