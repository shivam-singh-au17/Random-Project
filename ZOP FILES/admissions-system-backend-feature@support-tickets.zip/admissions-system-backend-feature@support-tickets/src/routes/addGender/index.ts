import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createAddGender } from "./create-addGender";
import { getAddGender } from "./get-addGender";
import { getOneAddGender } from "./get-one-addGender";
import { deleteAddGender } from "./delete-addGender";
import { updateAddGender } from "./update-addGender";

const router = express.Router();

router.post("/create-addGender/", createValidation, createAddGender);

router.get("/get-addGender/", getAddGender);

router.get("/get-one-addGender/:id", getOneAddGender);

router.delete("/delete-addGender/:id", deleteAddGender);

router.patch("/update-addGender/:id", updateValidation, updateAddGender);

export { router as addGender };
