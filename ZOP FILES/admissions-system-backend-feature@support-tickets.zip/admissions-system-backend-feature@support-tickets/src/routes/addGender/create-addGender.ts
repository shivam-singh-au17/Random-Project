import { AddGender } from "../../models/addGender";
import { RequestHandler } from "express";

const createAddGender: RequestHandler = async (req, res, next) => {
  try {
    const item = await AddGender.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createAddGender };
