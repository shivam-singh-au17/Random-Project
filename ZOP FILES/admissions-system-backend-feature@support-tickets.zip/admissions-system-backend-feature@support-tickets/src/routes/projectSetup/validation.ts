import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

// 1 eligibility
const eligibilitySchema = Joi.string().required();

const eligibilityTypeSchema = Joi.array()
  .items(eligibilitySchema)
  .unique()
  .required();
// 1 eligibility

// 2 reservation

const reservationSchema = Joi.string().required();

const reservationTypeSchema = Joi.array()
  .items(reservationSchema)
  .unique()
  .required();
// 2 reservation

// 3 feeStructure
const feeStructureSchema = Joi.string().required();

const feeStructureTypeSchema = Joi.array()
  .items(feeStructureSchema)
  .unique()
  .required();
// 3 feeStructure

// 4 seats
const seatsSchema = Joi.number().required();

const seatsTypeSchema = Joi.array().items(seatsSchema).unique().required();
// 4 seats

// 5 subjectDict
const subjectDictSchema = Joi.string().required();

const subjectDictTypeSchema = Joi.array()
  .items(subjectDictSchema)
  .unique()
  .required();
// 5 subjectDict

// 6 subjectBundles
const subjectBundlesSchema = Joi.string().required();

const subjectBundlesTypeSchema = Joi.array()
  .items(subjectBundlesSchema)
  .unique()
  .required();
// 6 subjectBundles

// 7 team
const teamSchema = Joi.object({
  email: Joi.string().required().email({ minDomainSegments: 2 }),
  role: Joi.string().required(),
}).required();

const teamTypeSchema = Joi.array().items(teamSchema).unique().required();
// 7 team

const validationSchema = {
  create: Joi.object({
    projectFullName: Joi.string().required(),
    projectShortName: Joi.string().required(),
    attachProgram: Joi.string().required(),
    applicableYear: Joi.string().required(),
    academicYear: Joi.string().required(),
    eligibility: Joi.alternatives()
      .try(eligibilitySchema, eligibilityTypeSchema)
      .required(),
    reservation: Joi.alternatives()
      .try(reservationSchema, reservationTypeSchema)
      .required(),
    feeStructure: Joi.alternatives()
      .try(feeStructureSchema, feeStructureTypeSchema)
      .required(),
    seats: Joi.alternatives().try(seatsSchema, seatsTypeSchema).required(),
    subjectDict: Joi.alternatives()
      .try(subjectDictSchema, subjectDictTypeSchema)
      .required(),
    subjectBundles: Joi.alternatives()
      .try(subjectBundlesSchema, subjectBundlesTypeSchema)
      .required(),
    status: Joi.string().required(),
    team: Joi.alternatives().try(teamSchema, teamTypeSchema).required(),
  }),

  update: Joi.object({
    projectFullName: Joi.string().required(),
    projectShortName: Joi.string().required(),
    attachProgram: Joi.string().required(),
    applicableYear: Joi.string().required(),
    academicYear: Joi.string().required(),
    eligibility: Joi.array(),
    reservation: Joi.array(),
    feeStructure: Joi.array(),
    seats: Joi.array(),
    subjectDict: Joi.array(),
    subjectBundles: Joi.array(),
    status: Joi.string().required(),
    team: Joi.array(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
