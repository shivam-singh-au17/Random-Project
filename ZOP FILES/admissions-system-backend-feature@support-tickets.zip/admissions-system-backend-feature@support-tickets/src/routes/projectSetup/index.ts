import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createProjectSetup } from "./create-projectSetup";
import { getProjectSetup } from "./get-projectSetup";
import { deleteProjectSetup } from "./delete-projectSetup";
import { updateProjectSetup } from "./update-projectSetup";

const router = express.Router();

router.post("/project/setup/create", createValidation, createProjectSetup);

router.get("/project/setup/get", getProjectSetup);

router.delete("/project/setup/delete/:id", deleteProjectSetup);

router.patch("/project/setup/update/:id", updateValidation, updateProjectSetup);

export { router as projectSetup };
