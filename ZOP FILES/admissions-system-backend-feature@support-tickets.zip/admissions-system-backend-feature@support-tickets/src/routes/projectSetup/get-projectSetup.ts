import { ProjectSetup } from "../../models/projectSetup";
import { RequestHandler } from "express";

const getProjectSetup: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await ProjectSetup.findById(req.query.id)
        .populate("attachProgram")
        .populate("feeStructure")
        .lean()
        .exec();

      return res.status(200).send(itemOne);
    }

    const item = await ProjectSetup.find()
      .populate("attachProgram")
      .populate("feeStructure")
      .lean()
      .exec();

    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getProjectSetup };
