import { CompulsorySubject } from "../../models/compulsorySubject";
import { RequestHandler } from "express";

const getCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await CompulsorySubject.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getCompulsorySubject };
