import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const compulsorySchema = Joi.object({
  subjectName: Joi.string().required(),
}).required();

const compulsorySubjectSchema = Joi.array()
  .items(compulsorySchema)
  .unique()
  .required();

const validationSchema = {
  create: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    compulsorySubject: Joi.alternatives()
      .try(compulsorySchema, compulsorySubjectSchema)
      .required(),
  }),

  update: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
