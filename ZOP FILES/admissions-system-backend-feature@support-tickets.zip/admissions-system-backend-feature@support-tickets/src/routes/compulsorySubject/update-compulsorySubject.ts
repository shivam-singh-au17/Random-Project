import { CompulsorySubject } from "../../models/compulsorySubject";
import { RequestHandler } from "express";

const updateCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await CompulsorySubject.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateCompulsorySubject };
