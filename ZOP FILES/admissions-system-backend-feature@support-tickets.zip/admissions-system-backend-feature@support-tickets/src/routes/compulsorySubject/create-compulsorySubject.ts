import { CompulsorySubject } from "../../models/compulsorySubject";
import { RequestHandler } from "express";

const createCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await CompulsorySubject.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createCompulsorySubject };
