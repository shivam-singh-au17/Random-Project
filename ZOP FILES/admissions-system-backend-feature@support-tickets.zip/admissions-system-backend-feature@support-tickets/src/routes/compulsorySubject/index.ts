import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createCompulsorySubject } from "./create-compulsorySubject";
import { getCompulsorySubject } from "./get-compulsorySubject";
import { getOneCompulsorySubject } from "./get-one-compulsorySubject";
import { deleteCompulsorySubject } from "./delete-compulsorySubject";
import { updateCompulsorySubject } from "./update-compulsorySubject";

const router = express.Router();

router.post(
  "/compulsory-subject/create/",
  createValidation,
  createCompulsorySubject
);

router.get("/compulsory-subject/get-all/", getCompulsorySubject);

router.get("/compulsory-subject/get-one/:id", getOneCompulsorySubject);

router.delete("/compulsory-subject/delete/:id", deleteCompulsorySubject);

router.patch(
  "/compulsory-subject/update/:id",
  updateValidation,
  updateCompulsorySubject
);

export { router as compulsorySubject };
