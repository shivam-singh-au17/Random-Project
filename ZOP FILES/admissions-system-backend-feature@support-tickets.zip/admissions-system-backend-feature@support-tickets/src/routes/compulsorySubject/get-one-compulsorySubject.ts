import { CompulsorySubject } from "../../models/compulsorySubject";
import { RequestHandler } from "express";

const getOneCompulsorySubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await CompulsorySubject.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneCompulsorySubject };
