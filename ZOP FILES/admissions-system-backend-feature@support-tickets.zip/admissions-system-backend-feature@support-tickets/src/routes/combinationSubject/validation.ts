import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const combinationSchema = Joi.object({
  subjectName: Joi.string().required(),
});

const combinationSubjectSchema = Joi.array()
  .items(combinationSchema)
  .unique();

const validationSchema = {
  create: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
    combinationSubject: Joi.alternatives()
      .try(combinationSchema, combinationSubjectSchema),
  }),

  update: Joi.object({
    programName: Joi.string().required(),
    yearAppliedFor: Joi.string().required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
