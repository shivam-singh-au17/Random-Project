import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createCombinationSubject } from "./create-combinationSubject";
import { getCombinationSubject } from "./get-combinationSubject";
import { getOneCombinationSubject } from "./get-one-combinationSubject";
import { deleteCombinationSubject } from "./delete-combinationSubject";
import { updateCombinationSubject } from "./update-combinationSubject";

const router = express.Router();

router.post(
  "/combination-subject/create",
  createValidation,
  createCombinationSubject
);

router.get("/combination-subject/get-all", getCombinationSubject);

router.get("/combination-subject/get-one/:id", getOneCombinationSubject);

router.delete("/combination-subject/delete/:id", deleteCombinationSubject);

router.patch(
  "/combination-subject/update/:id",
  updateValidation,
  updateCombinationSubject
);

export { router as combinationSubject };
