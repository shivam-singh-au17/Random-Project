import { CombinationSubject } from "../../models/combinationSubject";
import { RequestHandler } from "express";

const createCombinationSubject: RequestHandler = async (req, res, next) => {
  try {
    const item = await CombinationSubject.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createCombinationSubject };
