import { ProjectMgmtService } from "../../models/projectMgmtService";
import { RequestHandler } from "express";
import createHttpError from "http-errors";

const deleteProjectsById: RequestHandler = async (req, res, next) => {
  try {
    const item = await ProjectMgmtService.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(createHttpError.InternalServerError);
  }
};

export { deleteProjectsById };
