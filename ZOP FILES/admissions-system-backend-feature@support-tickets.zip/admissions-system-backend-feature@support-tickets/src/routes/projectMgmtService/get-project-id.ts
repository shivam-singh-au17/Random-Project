import { ProjectMgmtService } from "../../models/projectMgmtService";
import { RequestHandler } from "express";
import createHttpError from "http-errors";

const getProjectsById: RequestHandler = async (req, res, next) => {
  try {
    const item = await ProjectMgmtService.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(createHttpError.InternalServerError);
  }
};

export { getProjectsById };
