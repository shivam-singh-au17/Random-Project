import { ProjectMgmtService } from "../../models/projectMgmtService";
import { RequestHandler } from "express";
import createHttpError from "http-errors";

const createProject: RequestHandler = async (req, res, next) => {
  const {
    project_name,
    start_date,
    end_date,
    team,
    team_name,
    course_code,
    course_year,
  }: {
    project_name: string;
    start_date: string;
    end_date: string;
    team: string[];
    team_name: string;
    course_code: number;
    course_year: number;
  } = req.body;

  try {
    const item = new ProjectMgmtService({
      project_name,
      start_date,
      end_date,
      team,
      team_name,
      course_code,
      course_year,
    });
    await item.save();
    return res.status(200).send(item);
  } catch (error) {
    return next(createHttpError.InternalServerError);
  }
};

export { createProject };
