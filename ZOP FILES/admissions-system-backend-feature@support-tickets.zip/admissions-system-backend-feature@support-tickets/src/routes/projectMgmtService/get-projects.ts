import { ProjectMgmtService } from "../../models/projectMgmtService";
import { RequestHandler } from "express";
import createHttpError from "http-errors";

const getProjects: RequestHandler = async (req, res, next) => {

  try {
      const item = await ProjectMgmtService.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(createHttpError.InternalServerError);
  }
};

export { getProjects };
