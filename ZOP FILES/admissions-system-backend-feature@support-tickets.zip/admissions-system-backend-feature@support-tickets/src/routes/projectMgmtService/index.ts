import { createProjectValidation } from "./validation";
import express from "express";
import { createProject } from "./create-project";
import { getProjects } from "./get-projects";
import { getProjectsById } from "./get-project-id";
import { deleteProjectsById } from "./delete-project";
const router = express.Router();

router.post("/create-project/", createProjectValidation, createProject);
router.get("/get-projects/", getProjects);
router.get("/get-project/:id", getProjectsById);
router.delete("/delete-project/:id", deleteProjectsById);

export { router as projectMgmtService };
