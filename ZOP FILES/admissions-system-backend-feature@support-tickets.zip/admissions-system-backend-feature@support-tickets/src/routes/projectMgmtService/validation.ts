import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  createProject: Joi.object({
    project_name: Joi.string().required(),
    start_date: Joi.string().required(),
    end_date: Joi.string().required(),
    team: Joi.array().required(),
    team_name: Joi.string().required(),
    course_code: Joi.number().required(),
    course_year: Joi.number().required(),
  }),

  closeProject: Joi.object({
    project_name: Joi.string().required(),
    start_date: Joi.string().required(),
    end_date: Joi.string().required(),
    team: Joi.array().required(),
    team_name: Joi.string().required(),
    course_code: Joi.number().required(),
    course_year: Joi.number().required(),
  }),
};

const createProjectValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.createProject, req.body, next);

export { createProjectValidation };
