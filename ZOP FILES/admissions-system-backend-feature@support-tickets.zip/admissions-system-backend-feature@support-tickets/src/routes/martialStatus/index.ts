import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createMartialStatus } from "./create-martialStatus";
import { getMartialStatus } from "./get-martialStatus";
import { getOneMartialStatus } from "./get-one-martialStatus";
import { deleteMartialStatus } from "./delete-martialStatus";
import { updateMartialStatus } from "./update-martialStatus";

const router = express.Router();

router.post("/create-martialStatus/", createValidation, createMartialStatus);

router.get("/get-martialStatus/", getMartialStatus);

router.get("/get-one-martialStatus/:id", getOneMartialStatus);

router.delete("/delete-martialStatus/:id", deleteMartialStatus);

router.patch("/update-martialStatus/:id", updateValidation, updateMartialStatus);

export { router as martialStatus };
