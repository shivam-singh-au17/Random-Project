import { MartialStatus } from "../../models/martialStatus";
import { RequestHandler } from "express";

const updateMartialStatus: RequestHandler = async (req, res, next) => {
  try {
    const item = await MartialStatus.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateMartialStatus };
