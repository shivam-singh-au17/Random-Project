import { MartialStatus } from "../../models/martialStatus";
import { RequestHandler } from "express";

const getMartialStatus: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await MartialStatus.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await MartialStatus.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getMartialStatus };
