import { MartialStatus } from "../../models/martialStatus";
import { RequestHandler } from "express";

const createMartialStatus: RequestHandler = async (req, res, next) => {
  try {
    const item = await MartialStatus.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createMartialStatus };
