import { Router } from "express";

// DCRs -->
import { assertDcr } from "../../controllers/dcr/assert-dcr.controller";
// Controllers
// Invoices-->
import { createInvoiceAPI, getInvoices } from "../../controllers/invoice/@invoice.controllers";
import { updateNewPaymentHistory } from "../../controllers/payments/update-payment-history.controller";
import { InvoicePolicy } from "../../middlewares/policies/invoice/@invoice.policies";
import { validation } from "./_invoice.validation";

const router = Router();
// generates invoice
router.post(
  "/invoice",
  InvoicePolicy.create(),
  validation,
  createInvoiceAPI,
  updateNewPaymentHistory
);
// query based invoices getter.
router.get("/invoice", InvoicePolicy.read(), getInvoices);
export { router as invoiceRouter };
