import { NextFunction, Request, Response } from "express";
import joi, { required } from "joi";

import validateParams from "../../middlewares/validateParams";

// schema
const schema = joi.object({
  name: joi.string().required(),
  amount: joi.number().required(),
  total: joi.number().required(),
  userId: joi.string().required(),
  beneficiaryAccount: {
    bankName: joi.string().required(),
    branch: joi.string().required(),
    bankAddress: joi.string().required(),
    ifscCode: joi.string().required(),
    accountNo: joi.string().required(),
  },
  signatures: joi.required(),
  feeStructure: joi.required(),
  mode: joi.object(),
  remarks: joi.string(),
  installmentNo: joi.number(),
});

const validation = (req: Request, res: Response, next: NextFunction) =>
  validateParams(schema, req.body, next);
export { validation };
