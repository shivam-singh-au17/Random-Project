import validateParams from "../../middlewares/validateParams";
import { RequestHandler } from "express";
import Joi from "joi";

const validationSchema = {
  create: Joi.object({
    addUrl: Joi.string().required(),
    addNumber: Joi.string().required(),
    user: Joi.string().required(),
  }),

  update: Joi.object({
    addUrl: Joi.string().required(),
    addNumber: Joi.string().required(),
    user: Joi.string().required(),
  }),
};

const createValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.create, req.body, next);

const updateValidation: RequestHandler = (req, res, next) =>
  validateParams(validationSchema.update, req.body, next);

export { createValidation, updateValidation };
