import { Sms } from "../../models/sms";
import { RequestHandler } from "express";

const getSms: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await Sms.findById(req.query.id).lean().exec();
      return res.status(200).send(itemOne);
    }
    const item = await Sms.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getSms };
