import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSms } from "./create-sms";
import { getSms } from "./get-sms";
import { getOneSms } from "./get-one-sms";
import { deleteSms } from "./delete-sms";
import { updateSms } from "./update-sms";

const router = express.Router();

router.post("/create-sms/", createValidation, createSms);

router.get("/get-sms/", getSms);

router.get("/get-one-sms/:id", getOneSms);

router.delete("/delete-sms/:id", deleteSms);

router.patch("/update-sms/:id", updateValidation, updateSms);

export { router as sms };
