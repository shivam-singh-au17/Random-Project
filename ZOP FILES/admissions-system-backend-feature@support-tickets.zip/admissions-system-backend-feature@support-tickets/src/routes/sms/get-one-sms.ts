import { Sms } from "../../models/sms";
import { RequestHandler } from "express";

const getOneSms: RequestHandler = async (req, res, next) => {
  try {
    const item = await Sms.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneSms };
