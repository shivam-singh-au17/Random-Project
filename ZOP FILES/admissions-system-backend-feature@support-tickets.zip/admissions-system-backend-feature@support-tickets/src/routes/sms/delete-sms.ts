import { Sms } from "../../models/sms";
import { RequestHandler } from "express";

const deleteSms: RequestHandler = async (req, res, next) => {
  try {
    const item = await Sms.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteSms };
