import { Sms } from "../../models/sms";
import { RequestHandler } from "express";

const createSms: RequestHandler = async (req, res, next) => {
  try {
    const item = await Sms.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSms };
