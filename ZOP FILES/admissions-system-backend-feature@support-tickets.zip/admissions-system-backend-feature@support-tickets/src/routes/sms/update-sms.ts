import { Sms } from "../../models/sms";
import { RequestHandler } from "express";

const updateSms: RequestHandler = async (req, res, next) => {
  try {
    const item = await Sms.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateSms };
