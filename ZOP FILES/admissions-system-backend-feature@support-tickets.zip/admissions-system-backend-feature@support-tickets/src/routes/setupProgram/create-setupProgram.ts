import { SetupProgram } from "../../models/setupProgram";
import { RequestHandler } from "express";

const createSetupProgram: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupProgram.create(req.body);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { createSetupProgram };
