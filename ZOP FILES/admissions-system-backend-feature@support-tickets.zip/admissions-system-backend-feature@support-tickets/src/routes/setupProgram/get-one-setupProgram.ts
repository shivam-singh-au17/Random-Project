import { SetupProgram } from "../../models/setupProgram";
import { RequestHandler } from "express";

const getOneSetupProgram: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupProgram.findById(req.params.id).lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getOneSetupProgram };
