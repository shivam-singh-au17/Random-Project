import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createSetupProgram } from "./create-setupProgram";
import { getSetupProgram } from "./get-setupProgram";
import { getOneSetupProgram } from "./get-one-setupProgram";
import { deleteSetupProgram } from "./delete-setupProgram";
import { updateSetupProgram } from "./update-setupProgram";
import { SetupsPolicy } from "../../middlewares/policies/setups/@setups.policies";

const router = express.Router();

router.post(
  "/create-setupProgram/",
  SetupsPolicy.create(),
  createValidation,
  createSetupProgram
);

router.get("/get-setupProgram/", SetupsPolicy.read(), getSetupProgram);

router.get(
  "/get-one-setupProgram/:id",
  SetupsPolicy.read(),
  getOneSetupProgram
);

router.delete(
  "/delete-setupProgram/:id",
  SetupsPolicy.delete(),
  deleteSetupProgram
);

router.patch(
  "/update-setupProgram/:id",
  SetupsPolicy.update(),
  updateValidation,
  updateSetupProgram
);

export { router as setupProgram };
