import { SetupProgram } from "../../models/setupProgram";
import { RequestHandler } from "express";

const deleteSetupProgram: RequestHandler = async (req, res, next) => {
  try {
    const item = await SetupProgram.findByIdAndDelete(req.params.id);
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { deleteSetupProgram };
