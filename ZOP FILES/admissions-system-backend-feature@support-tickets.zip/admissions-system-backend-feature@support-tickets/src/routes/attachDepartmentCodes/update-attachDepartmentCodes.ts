import { AttachDepartmentCodes } from "../../models/attachDepartmentCodes";
import { RequestHandler } from "express";

const updateAttachDepartmentCodes: RequestHandler = async (req, res, next) => {
  try {
    const item = await AttachDepartmentCodes.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { updateAttachDepartmentCodes };
