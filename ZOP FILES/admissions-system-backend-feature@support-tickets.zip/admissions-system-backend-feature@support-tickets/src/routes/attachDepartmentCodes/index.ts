import express from "express";

import { createValidation, updateValidation } from "./validation";

import { createAttachDepartmentCodes } from "./create-attachDepartmentCodes";
import { getAttachDepartmentCodes } from "./get-attachDepartmentCodes";
import { deleteAttachDepartmentCodes } from "./delete-attachDepartmentCodes";
import { updateAttachDepartmentCodes } from "./update-attachDepartmentCodes";

const router = express.Router();

router.post("/create-attachDepartmentCodes/", createValidation, createAttachDepartmentCodes);

router.get("/get-attachDepartmentCodes/", getAttachDepartmentCodes);

router.delete("/delete-attachDepartmentCodes/:id", deleteAttachDepartmentCodes);

router.patch("/update-attachDepartmentCodes/:id", updateValidation, updateAttachDepartmentCodes);

export { router as attachDepartmentCodes };
