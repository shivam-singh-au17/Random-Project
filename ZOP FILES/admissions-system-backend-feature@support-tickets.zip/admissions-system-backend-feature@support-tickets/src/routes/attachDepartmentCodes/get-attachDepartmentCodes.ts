import { AttachDepartmentCodes } from "../../models/attachDepartmentCodes";
import { RequestHandler } from "express";

const getAttachDepartmentCodes: RequestHandler = async (req, res, next) => {
  try {
    if (req.query.id) {
      const itemOne = await AttachDepartmentCodes.findById(req.query.id)
        .lean()
        .exec();
      return res.status(200).send(itemOne);
    }
    const item = await AttachDepartmentCodes.find().lean().exec();
    return res.status(200).send(item);
  } catch (error) {
    return next(error);
  }
};

export { getAttachDepartmentCodes };
