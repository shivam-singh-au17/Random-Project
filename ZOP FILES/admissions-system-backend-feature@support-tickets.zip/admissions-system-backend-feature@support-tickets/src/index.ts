import { port } from "./config";
import { app } from "./app";

app.listen(port, () => {
  console.log("Service Started On Port: " + port);
});
