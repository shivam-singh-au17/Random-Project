import { Policies } from "../../authorizations/roles-authorizations/base-policies";
import { context, SetupsAccess } from "./config";

// creating new derived polices class based on base class "Policies"
// extending & attaching identity management service polices custom policies to for forming derived polices for setups feature.
class SetupsPolicies extends Policies {
  accessControl = SetupsAccess;
  context: string = context;
}
export const SetupsPolicy = new SetupsPolicies();
