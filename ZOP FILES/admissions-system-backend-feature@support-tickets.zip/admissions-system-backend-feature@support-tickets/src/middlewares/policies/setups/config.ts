import { AccessControl } from "accesscontrol";
import { Roles } from "../../authorizations/base/auth-roles";

// feature context to build policy for.
const context = "setups";

// creating fresh access control for Project Management Service
const SetupsAccess = new AccessControl();

// granted action for user with "ROOT" role.
SetupsAccess.grant(Roles.UserRoot)
  .readAny(context)
  .createAny(context)
  .deleteAny(context)
  .updateAny(context);

// granted action for user with "ADMIN-GLOBAL" role.
SetupsAccess.grant(Roles.UserAdminGlobal)
  .readAny(context)
  .createAny(context)
  .deleteAny(context)
  .updateAny(context);

// granted action for user with "ADMIN-MODULE" role.
SetupsAccess.grant(Roles.UserAdminModule)
  .readAny(context)
  .createAny(context)
  .deleteAny(context)
  .updateAny(context);

// granted action for user with "STAFF-ACC" role.
SetupsAccess.grant(Roles.UserFacultyACC).readAny(context);

// granted action for user with "STAFF-ADM" role.
SetupsAccess.grant(Roles.UserFacultyADM).readAny(context);

export { SetupsAccess, context };
