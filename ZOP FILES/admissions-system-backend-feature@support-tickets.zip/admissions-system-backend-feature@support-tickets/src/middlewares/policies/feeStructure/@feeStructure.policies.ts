import { Policies } from "../../authorizations/roles-authorizations/base-policies";
import { context, FeeStructureAccess } from "./config";

// creating new derived polices class based on base class "Policies"
// extending & attaching identity management service polices custom policies to for forming derived polices for feeStructure feature.
class FeeStructurePolicies extends Policies {
  accessControl = FeeStructureAccess;
  context: string = context;
}
export const FeeStructurePolicy = new FeeStructurePolicies();
