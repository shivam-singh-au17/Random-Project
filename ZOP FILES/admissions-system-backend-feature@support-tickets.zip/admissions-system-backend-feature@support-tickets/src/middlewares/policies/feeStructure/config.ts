import { AccessControl } from "accesscontrol";
import { Roles } from "../../authorizations/base/auth-roles";

// feature context to build policy for.
const context = "feeStructure";

// creating fresh access control for Project Management Service
const FeeStructureAccess = new AccessControl();

// granted action for user with "ROOT" role.
FeeStructureAccess.grant(Roles.UserRoot)
  .readAny(context)
  .createAny(context)
  .updateAny(context)
  .deleteAny(context);

// granted action for user with "ADMIN-GLOBAL" role.
FeeStructureAccess.grant(Roles.UserAdminGlobal)
  .readAny(context)
  .createAny(context)
  .updateAny(context)
  .deleteAny(context);

// granted action for user with "ADMIN-GLOBAL" role.
FeeStructureAccess.grant(Roles.UserAdminModule)
  .readAny(context)
  .createAny(context)
  .updateAny(context)
  .deleteAny(context);

// granted action for user with "STAFF-ACC" role.
FeeStructureAccess.grant(Roles.UserFacultyACC).readAny(context);

// granted action for user with "STAFF-ADM" role.
FeeStructureAccess.grant(Roles.UserFacultyADM).readAny(context);

export { FeeStructureAccess, context };
