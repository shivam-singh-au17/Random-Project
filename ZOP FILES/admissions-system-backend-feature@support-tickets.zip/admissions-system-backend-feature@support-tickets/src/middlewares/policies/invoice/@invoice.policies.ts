import { Policies } from "../../authorizations/roles-authorizations/base-policies";
import { context, InvoiceAccess } from "./config";

// creating new derived polices class based on base class "Policies"
// extending & attaching identity management service polices custom policies to for forming derived polices for invoicing feature.
class InvoicePolicies extends Policies {
  accessControl = InvoiceAccess;
  context: string = context;
}
export const InvoicePolicy = new InvoicePolicies();
