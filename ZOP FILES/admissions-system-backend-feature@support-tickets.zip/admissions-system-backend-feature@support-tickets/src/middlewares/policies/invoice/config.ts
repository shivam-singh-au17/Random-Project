import { AccessControl } from "accesscontrol";
import { Roles } from "../../authorizations/base/auth-roles";

// feature context to build policy for.
const context = "invoice";

// creating fresh access control for Project Management Service
const InvoiceAccess = new AccessControl();

// granted action for user with "ROOT" role.
InvoiceAccess.grant(Roles.UserRoot).readAny(context).createAny(context);

// granted action for user with "ADMIN-GLOBAL" role.
InvoiceAccess.grant(Roles.UserAdminGlobal).readAny(context).createAny(context);

// granted action for user with "STAFF-ACC" role.
InvoiceAccess.grant(Roles.UserFacultyACC).readAny(context).create(context);

// granted action for user with "STAFF-ADM" role.
InvoiceAccess.grant(Roles.UserFacultyADM).readAny(context);

export { InvoiceAccess, context };
