import { AccessControl } from "accesscontrol";
import { Roles } from "../../authorizations/base/auth-roles";
// feature context to build policy for.
const context = "DCR";
// creating fresh access control for Project Management Service
const DcrAccess = new AccessControl();

// granted action for user with "ROOT" role.
DcrAccess.grant(Roles.UserRoot)
  .readAny(context)
  .createAny(context)
  .deleteAny(context)
  .updateAny(context);
// granted action for user with "ADMIN-GLOBAL" role.
DcrAccess.grant(Roles.UserAdminGlobal)
  .readAny(context)
  .createAny(context)
  .deleteAny(context)
  .updateAny(context);

// granted action for user with "STAFF-ACC" role.
DcrAccess.grant(Roles.UserFacultyACC).readAny(context);

// granted action for user with "STAFF-ADM" role.
DcrAccess.grant(Roles.UserFacultyADM).deny(context);

export { DcrAccess, context };
