import { Policies } from "../../authorizations/roles-authorizations/base-policies";
import { context, DcrAccess } from "./config";

// creating new derived polices class based on base class "Policies"
// extending & attaching identity management service polices custom policies to for forming derived polices for dcr feature.
class DcrPolicies extends Policies {
  accessControl = DcrAccess;
  context: string = context;
}
export const DcrPolicy = new DcrPolicies();
