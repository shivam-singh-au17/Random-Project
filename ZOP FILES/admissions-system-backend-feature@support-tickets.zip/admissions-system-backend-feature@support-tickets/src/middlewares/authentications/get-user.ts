import { verifierFactory } from "@southlane/cognito-jwt-verifier";
import { RequestHandler } from "express";

// configuring token verifier
// downloads jwt config of user from aws & set the buffer keystore for verifying jwt token on request.
const verifier = verifierFactory({
  region: process.env.region,
  userPoolId: process.env.userPoolId,
  appClientId: process.env.appClientId,
  tokenType: "id", // either "access" or "id"
});

// jwt payload decode abstraction type
interface UserPayload {
  sub: string;
  email_verified: boolean;
  iss: string;
  ["cognito:username"]: string;
  origin_jti: string;
  ["custom:tenantId"]: string;
  aud: string;
  event_id: string;
  token_use: string;
  auth_time: number;
  exp: number;
  ["custom:roles"]: string | string[];
  ["custom:modules"]: string | string[];
  iat: number;
  jti: string;
  email: string;
}
// declare req.user as request extended for global
declare module "express-serve-static-core" {
  interface Request {
    user?: UserPayload;
  }
}

// to avoid typescript overloading error while using this middleware, assign "RequestHandler" without assigning any "res:Request,res:Response,next:NextFunction"on request,response & next parameters.
export const getUser: RequestHandler = async (req, res, next) => {
  // if cookie doesn't find on request.
  if (!req.cookies?.jwt) {
    return next();
  }
  // if jwt exist on the req cookie.
  // getting jwt token from cookie
  const token = req.cookies.jwt;
  // verifying the jwt token
  try {
    const userPayload = (await verifier.verify(token)) as UserPayload;
    // converging userRoles & modules access to array
    const userRoles = (userPayload["custom:roles"] as string).includes(",")
      ? Object.assign(
          [],

          (userPayload["custom:roles"] as string).split(",")
        )
      : [userPayload["custom:roles"]];

    // updating roles,modules array output to existing payload
    userPayload["custom:roles"] = userRoles as string[];
    // attaching payload to req.user
    req.user = userPayload;
  } catch (err) {
    console.log(err);
  }
  return next();
};
