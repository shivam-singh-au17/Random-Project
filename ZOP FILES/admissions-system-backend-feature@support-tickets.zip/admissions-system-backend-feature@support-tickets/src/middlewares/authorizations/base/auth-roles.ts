export enum Roles {
  UserRoot = "ROOT",
  UserAdminGlobal = "ADMIN-GLOBAL",
  UserAdminModule = "ADMIN-MODULE",
  UserApplication = "APPLICANT",
  UserFaculty = "STAFF",
  UserFacultyADM = "STAFF-ADM",
  UserFacultyACC = "STAFF-ACC",
}
export enum ModuleAccess {
  ADMISSIONS = "ADMISSIONS",
  EXAMINATIONS = "EXAMINATIONS",
}
