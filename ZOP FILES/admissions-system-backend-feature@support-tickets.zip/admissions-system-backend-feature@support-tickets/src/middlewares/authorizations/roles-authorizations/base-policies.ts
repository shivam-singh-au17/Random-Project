import { AccessControl } from "accesscontrol";
import { NextFunction, Request, Response } from "express";

// Policies is the base policies builder class, which take AccessControl & context as abstract field.
// Methods :  Policies.create(), Policies.read(), Policies.delete(), Policies.update()
// get user roles from request jwt & check with access control if the roles have permission to perform the action.
// declare req.user as request extended for global

abstract class Policies {
  abstract accessControl: AccessControl;
  abstract context: string;
  validateAuth() {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!req.user) {
        res.send({ message: "Not Authenticated" });
      }
      next();
    };
  }
  create() {
    return (req: Request, res: Response, next: NextFunction) => {
      this.validateAuth();
      const roles = req.user?.["custom:roles"];
      try {
        const permission = this.accessControl
          .can(roles as string[])
          .create(this.context);
        if (!permission.granted) {
          throw Error("To Perform This Action.");
        }
        next();
      } catch (err) {
        res.status(401).send({
          message: ("Not Authorized, " + (err as Error).message) as string,
        });
      }
    };
  }
  read() {
    return (req: Request, res: Response, next: NextFunction) => {
      this.validateAuth();
      const roles = req.user?.["custom:roles"];
      try {
        const permission = this.accessControl
          .can(roles as string[])
          .read(this.context);
        if (!permission.granted) {
          throw Error("To Perform This Action.");
        }
        next();
      } catch (err) {
        res.status(401).send({
          message: ("Not Authorized, " + (err as Error).message) as string,
        });
      }
    };
  }
  update() {
    return (req: Request, res: Response, next: NextFunction) => {
      this.validateAuth();
      const roles = req.user?.["custom:roles"];
      try {
        const permission = this.accessControl
          .can(roles as string[])
          .update(this.context);
        if (!permission.granted) {
          throw Error("To Perform This Action.");
        }
        next();
      } catch (err) {
        res.status(401).send({
          message: ("Not Authorized, " + (err as Error).message) as string,
        });
      }
    };
  }
  delete() {
    return (req: Request, res: Response, next: NextFunction) => {
      this.validateAuth();
      const roles = req.user?.["custom:roles"];
      try {
        const permission = this.accessControl
          .can(roles as string[])
          .delete(this.context);
        if (!permission.granted) {
          throw Error("To Perform This Action.");
        }
        next();
      } catch (err) {
        res.status(401).send({
          message: ("Not Authorized, " + (err as Error).message) as string,
        });
      }
    };
  }
}
export { Policies };
