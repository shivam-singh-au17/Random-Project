import path from "path";
import multer from "multer";

const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(
      null,
      path.join(__dirname, "../../src/routes/supportTicket/uploads")
    );
  },
  filename: function (req, file, callback) {
    const uniquePrefix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    callback(null, uniquePrefix + "-" + file.originalname);
  },
});

const fileFilter = function (req, file, callback) {
  if (
    file.mimetype === "application/pdf" ||
    file.mimetype == "image/png" ||
    file.mimetype == "image/jpg" ||
    file.mimetype == "image/jpeg"
  ) {
    callback(null, true);
  } else {
    callback(null, false);
    return callback(new Error("Only PDF, PNG, JPG and JPEG format allowed!"));
  }
};

const uplode = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5,
  },
  fileFilter: fileFilter,
});

export default uplode ;
