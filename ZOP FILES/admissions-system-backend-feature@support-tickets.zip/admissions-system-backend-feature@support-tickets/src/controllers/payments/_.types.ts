export enum PaymentStatus {
  created = "CREATED",
  partial = "PARTIAL",
  paid = "PAID",
}

export type HEAD = {
  head: string;
  amount: number;
};

export interface payment {
  name: string;
  status: string;
  dues: HEAD[];
  paid: HEAD[];
  invoices: string[];
}
