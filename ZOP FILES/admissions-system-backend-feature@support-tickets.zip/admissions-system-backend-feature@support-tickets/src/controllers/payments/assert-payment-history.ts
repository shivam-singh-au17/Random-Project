import { Request, Response } from "express";
import _ from "lodash";

import { FeeStructureCodes } from "../../models/feeStructureCodes";
import { Payment, paymentAttrs } from "../../models/paymentHistory";
import { HEAD, payment, PaymentStatus } from "./_.types";
import { headMapper } from "./helper/headMappers";

// handles bulks + payment attachment to user payment history.
const assertNewPaymentToPaymentHistory = async (
  req: Request,
  res: Response
) => {
  const { user_id, feeStructureName } = req.body;

  // get fee structure
  const feeStructure = await FeeStructureCodes.findOne({
    name: feeStructureName,
  }).populate("selectHeads.selectedHeads");

  if (_.isEmpty(feeStructure)) {
    return res.status(404).send({ error: "No Fee Structure Found." });
  }

  let data;
  try {
    // map payments heads
    data =
      feeStructure?.selectHeads &&
      headMapper(
        feeStructure?.selectHeads as {
          [key: string]: string | number | object;
        }[],
        "selectedHeads"
      );
  } catch (error) {
    return res
      .status(400)
      .send({ message: "Computation Error: Couldn't Map Heads." });
  }
  //   create new payment for asserting into payment history
  const payment: payment = {
    name: feeStructure?.name as string,
    status: PaymentStatus.created,
    dues: data?.mappedFields as HEAD[],
    paid: data?.zeroAmountFields as HEAD[],
    invoices: [],
  };

  // Bulk Creation Payment History Attachment With Users Id.
  if (_.isArray(user_id)) {
    try {
      const bulkPaymentWrite: { insertOne: { document: paymentAttrs } }[] = [];
      user_id.forEach((user) => {
        const newPaymentHistory = Payment.build({
          user_id: user,
          payments: [payment],
        });
        const userDocument = {
          insertOne: { document: newPaymentHistory },
        };
        bulkPaymentWrite.push(userDocument);
      });
      // create new payment history & allot payment
      const paymentWriteData = await Payment.bulkWrite(bulkPaymentWrite);
      return res
        .status(201)
        .send({ message: "Bulk Payment Alloted Successfully." });
    } catch (_err) {
      return res.status(400).send({
        error: `Couldn't Allot Payment To Users, ${
          (_err as Error).message as string
        }`,
      });
    }
  }
  // find payment history for the user
  const paymentHistory = await Payment.findOne({ user_id });

  // if payment history doesn't exist then create new payment history for the user. [Create]
  if (_.isEmpty(paymentHistory)) {
    const newPaymentHistory = await Payment.build({
      user_id: user_id,
      payments: [payment],
    });

    try {
      // create new payment history & allot payment
      await Payment.create(newPaymentHistory);
      return res.status(201).send({ message: "Payment Alloted Successfully." });
    } catch (_err) {
      return res.status(400).send({
        error: `Couldn't Allot Payment To User: ${user_id}, ${
          (_err as Error).message as string
        }`,
      });
    }
  }

  try {
    //   if payment history exists then attach new payment
    const ops = await Payment.findOneAndUpdate(
      { user_id, "payments.name": { $ne: feeStructureName } },
      {
        $push: {
          payments: payment,
        },
      }
    );
    // if payment already exist on payment history
    if (_.isNull(ops)) {
      throw new Error(
        "Fee Structure Is Already Alloted To The User Payments History."
      );
    }
    // return created response created
    return res.status(201).send({ message: "Payment Alloted Successfully." });
  } catch (_err) {
    return res.status(400).send({
      error: `Couldn't Allot Payment To User: ${user_id}, ${
        (_err as Error).message as string
      }`,
    });
  }
};

export { assertNewPaymentToPaymentHistory };
