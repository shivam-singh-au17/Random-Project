import { HEAD } from "../_.types";
import _ from "lodash";
// this maps the head with in relative & concise data.
export const headMapper: (
  fields: { [key: string | number | symbol]: string | number | object }[],
  headName: string
) => { mappedFields: HEAD[]; zeroAmountFields: HEAD[] } = (
  fields,
  headName
) => {
  const mappedFields: HEAD[] = [];
  const zeroAmountFields: HEAD[] = [];

  fields.forEach((field) => {
    const mappedField: HEAD = { head: "", amount: 0 };
    const zeroAmountField: HEAD = { head: "", amount: 0 };
    _.forIn(field, (value: any, key) => {
      if (key === "amount") mappedField.amount = parseInt(value);
      if (key === headName) {
        mappedField.head = value.feeHeadName;
        zeroAmountField.head = value.feeHeadName;
      }
    });
    mappedFields.push(mappedField);
    zeroAmountFields.push(zeroAmountField);
  });
  return { mappedFields, zeroAmountFields };
};
