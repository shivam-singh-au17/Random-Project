import _ from "lodash"; // utils & clean code lib.

// algo & for calculating dues & paid heads with new paid amounts
type HEAD = {
  head: string;
  amount: number | string;
};

const sumsMatchingHead = (array1: HEAD[], array2: HEAD[], ops?: string) => {
  // zipping matching keys together to make chunk combining
  return _.zipWith(array1, array2, (...args) => {
    const calculatedHead: any = {
      head: "",
      amount: 0,
    };

    // filtering all undefined values from similar head array.
    const similarHead = args.filter((head) => head);
    similarHead.forEach((head) => {
      calculatedHead.head = head.head;
      calculatedHead.amount =
        ops === "-"
          ? parseInt(head.amount as string) - calculatedHead.amount
          : parseInt(head.amount as string) + calculatedHead.amount;
    });
    return calculatedHead;
  });
};

const sumsMatchNTotal: (
  heads: HEAD[],
  heads2: HEAD[],
  ops?: string
) => {
  updatedHeads: HEAD[];
  total: number;
} = (heads, heads2, ops) => {
  // Sum New Value To Dcr & Save To Database
  const updatedHeads = sumsMatchingHead(heads as HEAD[], heads2, ops);
  // get total head from heads.
  const getTotalUpdatedHeads: any = _.filter(
    updatedHeads,
    _.conforms({ head: (head: string) => head === "total" })
  );
  const total: number = parseInt(getTotalUpdatedHeads[0].amount);

  return { updatedHeads, total };
};

const newPaid = [
  { head: "tutions", amount: 3000 },
  { head: "gym", amount: 200 },
  { head: "lab", amount: 10000 },
  { head: "paper", amount: 500 },
  { head: "utils", amount: 2000 },
  { head: "id", amount: 100 },
  { head: "total", amount: 0 },
];

const dues = [
  { head: "tutions", amount: 5000 },
  { head: "gym", amount: 0 },
  { head: "lab", amount: 20000 },
  { head: "paper", amount: 600 },
  { head: "utils", amount: 4000 },
  { head: "id", amount: 200 },
  { head: "total", amount: 500 },
];

const paid = [
  { head: "tutions", amount: 0 },
  { head: "gym", amount: 0 },
  { head: "lab", amount: 0 },
  { head: "paper", amount: 0 },
  { head: "utils", amount: 0 },
  { head: "id", amount: 0 },
  { head: "total", amount: 0 },
];

// compute new heads with previous payment history for the payment.
const { updatedHeads: newPaids, total } = sumsMatchNTotal(
  paid, // previous heads from database
  newPaid // new heads to be added.
);
const { updatedHeads: newDues, total: subsTotal } = sumsMatchNTotal(
  newPaid, // new heads to be subs.
  dues, // previous heads from database
  "-"
);

console.log("new paids", newPaids);
console.log("new dues", newDues, subsTotal);
