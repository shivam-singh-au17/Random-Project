import { Request, Response } from "express";
import _ from "lodash";

import { Payment } from "../../models/paymentHistory";
import { timeFormatted } from "../dcr/helper/date";

const getPaymentHistory = async (req: Request, res: Response) => {
  const { date, dateTo, applicantId, programName } = req.query;
  const dateFromTo =
    dateTo === undefined
      ? {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(date, 24), // forward 24hr time.
        }
      : {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(dateTo, 0),
        };
  const generateFilterExpress = {
    createdAt: date !== undefined ? dateFromTo : undefined,
    user_id: applicantId,
    "payments.name": programName,
  };
  // filtering out undefined query mapping.
  const filterQuery = _.omitBy(generateFilterExpress, function (...args) {
    return args.includes(undefined);
  });

  try {
    // if query is present then attach filterQuery, Other get all invoices
    const filter = _.isEmpty(req.query) ? {} : filterQuery;

    const aggPipeline = [
      { $match: filter },
      {
        $lookup: {
          from: "applicationforms",
          localField: "user_id",
          foreignField: "candidateId",
          as: "applicationData",
        },
      },
      {
        $lookup: {
          from: "registrationforms",
          localField: "user_id",
          foreignField: "_id",
          as: "registrationData",
        },
      },
      {
        $project: {
          user_id: 1,
          dues: 1,
          paid: 1,
          payments: 1,
          "applicationData.personalDetails": 1,
          "registrationData.email": 1,
          "registrationData.phoneNumber": 1,
        },
      },
      {
        $addFields: {
          adhaar: "$applicationData.personalDetails.aadharNumber",
          firstName: "$applicationData.personalDetails.firstName",
          lastName: "$applicationData.personalDetails.lastName",
          email: "$registrationData.email",
          phoneNumber: "$registrationData.phoneNumber",
        },
      },
      {
        $project: {
          user_id: 1,
          dues: 1,
          paid: 1,
          payments: 1,
          adhaar: {
            $arrayElemAt: ["$adhaar", 0],
          },
          email: {
            $arrayElemAt: ["$email", 0],
          },
          phoneNumber: {
            $arrayElemAt: ["$phoneNumber", 0],
          },
          fullName: {
            $concat: [
              {
                $arrayElemAt: ["$firstName", 0],
              },
              " ",
              {
                $arrayElemAt: ["$lastName", 0],
              },
            ],
          },
        },
      },
    ];
    // const paymentsHistories = await Payment.find(filter).lean().exec();
    const paymentsHistories = await Payment.aggregate(aggPipeline);

    if (_.isEmpty(paymentsHistories)) {
      return res.status(404).send({ error: "No Payments Found." });
    }
    return res.send({ data: paymentsHistories });
  } catch (_err) {
    return res.status(400).send({ error: (_err as Error).message });
  }
};

export { getPaymentHistory };
