import { Request, Response } from "express";
import { Payment } from "../../models/paymentHistory";
import _ from "lodash";
import { headMapper } from "../dcr/helper/headsMapper";
import { sumsMatchNTotal } from "../dcr/helper/sumMatchNTotal";
import { HEAD, PaymentStatus, payment } from "./_.types";
import { Invoice } from "../../models/invoice";
import { ApplicationForm } from "../../models/applicationForm";

const updateNewPaymentHistory = async (req: Request, res: Response) => {
  // get invoice
  const { user_id, paymentName, heads, invoiceNo } = req.body;

  const rollBackInvoice = async () => {
    await Invoice.remove({ "USER ID": user_id, "INVOICE NO": invoiceNo });
  };

  // map heads with relevant info.
  const newInvoiceHeads = headMapper(heads);
  // get previous payment history for the invoice has been generated
  const paymentHistory = await Payment.findOne({
    user_id,
    "payments.name": paymentName,
  });
  // if payment history exists on student report [UPDATE THE HISTORY]
  if (_.isEmpty(paymentHistory)) {
    await rollBackInvoice(); // deleting invoice if error with heads
    return res.send("No Payment History Found.");
  }
  //   filter & get payment for payments name within history
  const payment = _.filter(paymentHistory?.payments, (payment) => {
    return payment.name === paymentName;
  })[0];

  // compute new heads with previous payment history for the payment.
  const { updatedHeads: newPaid, total: subsTotal } = sumsMatchNTotal(
    payment.paid, // previous heads from database
    newInvoiceHeads // new heads to be added.
  );
  const { updatedHeads: newDues, total: duesTotal } = sumsMatchNTotal(
    newInvoiceHeads, // new heads to be subs.
    payment.dues, // previous heads from database
    "-"
  );

  //   filter out not zero dues.
  const getAllDuesNotZeroAmount = _.filter(
    newDues,
    _.conforms({
      amount: (amount: number) => {
        return amount !== 0;
      },
    })
  );

  //   filter out negative dues.
  const duesNegatives = _.filter(
    newDues,
    _.conforms({
      amount: (amount: number) => {
        return amount < 0;
      },
    })
  );
  const duesPaid = _.filter(
    newDues,
    _.conforms({
      amount: (amount: number) => {
        return amount === 0;
      },
    })
  );
  if (!_.isEmpty(duesNegatives) && !_.isEmpty(duesNegatives)) {
    await rollBackInvoice(); // deleting invoice if error with heads
    return res.status(400).send({
      error:
        "Dues Can't Be In Negatives Values Nor Invoice Can be Generated After Dues Have Been Paid",
      data: duesNegatives ? duesNegatives : duesPaid,
    });
  }
  const updatedInvoices = payment?.invoices
    ? [...payment.invoices, invoiceNo]
    : [invoiceNo];
  //   create new payment for asserting into payment history
  const updatedPayment: payment = {
    name: paymentName,
    status: _.isEmpty(getAllDuesNotZeroAmount)
      ? PaymentStatus.paid
      : PaymentStatus.partial,
    dues: newDues as HEAD[],
    paid: newPaid as HEAD[],
    invoices: updatedInvoices,
  };

  // filter currentPayments
  //   filter & get payment for payments name within history
  const allPayments = _.filter(paymentHistory?.payments, (payment) => {
    return payment.name !== paymentName;
  });

  try {
    await Payment.updateOne(
      {
        user_id,
        "payments.name": paymentName,
      },
      {
        $set: {
          payments: [updatedPayment, ...allPayments],
        },
      }
    );
    // update user step counter to +1
    await ApplicationForm.updateOne(
      { candidateId: user_id },
      { $set: { stepCounter: 6 } }
    );

    return res.status(202).send({ message: "Invoice Generated Successfully" });
  } catch (_err) {
    await rollBackInvoice();
    res.status(400).send({
      message: ("Cannot Create Invoice, " +
        "Reasons: " +
        (_err as Error).message) as string,
    });
  }
};

export { updateNewPaymentHistory };
