export const RefPopulatePipeline = (payment_name: string) => {
  return [
    // * Comment Out Each Aggregation Operation To See Better Transformation.
    // step 1. populated all fields in "selectHeads.selectedHeads" using objectId ref.
    // get fee structure with payment name
    { $match: { name: payment_name } },
    // unwind array object with ObjectId
    {
      $unwind: {
        path: "$selectHeads",
      },
    },
    // join collection name "fee-heads" with ObjectId of "selectHeads.selectedHeads"
    {
      $lookup: {
        from: "feeheads",
        localField: "selectHeads.selectedHeads",
        foreignField: "_id",
        as: "selectHeads.head", // saving populated array of heads as "head"
      },
    },
    // unwind new  "selectedHeads.head"
    {
      $unwind: {
        path: "$selectHeads.head",
      },
    },
    // group all heads with _id
    {
      $group: {
        _id: "$_id",
        selectedHeads: {
          $push: "$selectHeads",
        },
      },
    },
    // step 2. retrieve all lost fields and attach result of step into new fields structure with step 1 populated fields.
    // get this fee-structure again id as previous gets unmapped.
    {
      $lookup: {
        from: "feestructurecodes",
        localField: "_id",
        foreignField: "_id",
        as: "feeStructure",
      },
    },
    // unwind new fee-structure again for retrieving lost fields.
    {
      $unwind: {
        path: "$feeStructure",
      },
    },
    // attaching previous populated fields into new feeStructure.
    {
      $addFields: {
        "feeStructure.selectHeads": "$selectedHeads",
      },
    },
    // delete result of step 1 populated fields.
    {
      $replaceRoot: {
        newRoot: "$feeStructure",
      },
    },
    // filter out necessary fields
    {
      $project: {
        _id: 1,
        name: 1,
        collegeType: 1,
        aidedType: 1,
        programName: 1,
        departmentName: 1,
        yearAppliedFor: 1,
        bankAccount: 1,
        "selectHeads.selectedHeads": 1,
        "selectHeads.amount": 1,
        "selectHeads._id": 1,
        "selectHeads.head": 1,
      },
    },

    // lookup other reference which aren't array of objects.
    {
      $lookup: {
        from: "attachprogramcodes",
        localField: "programName",
        foreignField: "_id",
        as: "programName",
      },
    },
    {
      $lookup: {
        from: "attachdepartmentcodes",
        localField: "departmentName",
        foreignField: "_id",
        as: "departmentName",
      },
    },
    {
      $lookup: {
        from: "bankaccounts",
        localField: "bankAccount",
        foreignField: "_id",
        as: "bankAccount",
      },
    },
    // deflate / unwind it to root level.
    { $unwind: "$programName" },
    { $unwind: "$departmentName" },
    {
      $addFields: {
        programName: "$programName.selectProgramName",
        departmentName: "$departmentName.selectedDepartment",
      },
    },
  ];
};
