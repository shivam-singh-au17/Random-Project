// Utils
import crypto from "crypto";
// Server
import { NextFunction, Request, Response } from "express";
import _ from "lodash";

// Database Models
import { FeeStructureCodes } from "../../../models/feeStructureCodes";
import { Invoice } from "../../../models/invoice";
import { Payment, paymentAttrs } from "../../../models/paymentHistory";
import { validateOrderValue } from "../../../services/integration/razorpay/create-order";
import { totalHeadSplitterPaid } from "../../../services/integration/razorpay/total-head-splitter";
import { payment } from "../../payments/_.types";
import { RefPopulatePipeline } from "./utils/PopulatePipeline";

const verifyPaymentAuthenticity = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const {
    razorpayPaymentId,
    razorpayOrderId,
    razorpaySignature,
    amount,
    payment_name,
    candidateId,
    paymentMethod,
  } = req.body;

  // razorpay hash verifications.
  const signatureHash = razorpayOrderId + "|" + razorpayPaymentId;
  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_SECRET_KEY as string)
    .update(signatureHash.toString())
    .digest("hex");

  // checking if the expectedSignature match response razorpay signature.
  // if not true ? transaction is not legit from front-end.
  if (expectedSignature !== razorpaySignature) {
    return res
      .status(403)
      .json({ message: "Can't Verify Payment Authenticity." });
  }

  // If the signature hash matches with the razorpay signature then transaction is verified.
  const mode = {
    paymentMode: "online", // razorpay mode
  };

  // fetch necessary references form distributed collections.
  const getRefPopulatePipeline = await FeeStructureCodes.aggregate(
    RefPopulatePipeline(payment_name)
  );

  if (_.isEmpty(getRefPopulatePipeline)) {
    return res.status(404).send({ error: "No Payment Name Found." });
  }
  // feeStructure from aggregation pipeline.
  const feeStructure = _.omit(getRefPopulatePipeline[0], "bankAccount");

  //  get dues values & split total amount into heads.
  //  2. GET PAYMENT WITHIN PAYMENT HISTORY WITH PAYMENT NAME.
  const getUserPaymentHistory: paymentAttrs | null = await Payment.findOne({
    user_id: candidateId,
  });

  // No Payment Found Within User Payment History.
  if (_.isEmpty(getUserPaymentHistory)) {
    return res
      .status(404)
      .send({ message: "Couldn't Find Any Payment History For The User." });
  }

  const getUserPayment: () => payment = () =>
    _.filter(
      getUserPaymentHistory?.payments,
      (payment) => payment.name === payment_name
    )[0];

  const getDuesTotal: () => number = () =>
    _.filter(
      getUserPayment().dues,
      (head) => _.toLower(head.head) === "total"
    )[0].amount;

  const getPaidTotal: () => number = () =>
    _.filter(
      getUserPayment().paid,
      (head) => _.toLower(head.head) === "total"
    )[0].amount;

  // sums of total paid & due amount.
  const getTotalFeeStructureValue = getPaidTotal() + getDuesTotal();

  try {
    // create and validate order with payment method selected by users.
    validateOrderValue({
      selectedPaymentMethod: paymentMethod as string,
      duesTotal: getDuesTotal(),
      paidTotal: getPaidTotal(),
      paidAmount: parseInt(amount as string),
      totalFeeValue: getTotalFeeStructureValue, // for partial payment, check for fee structure value
    });
  } catch (err) {
    // return error if new order cannot be initialize on razorpay api.
    return res
      .status(400)
      .send({ error: [{ message: (err as Error).message as string }] });
  }

  // get all dues for the payment.
  const paymentDues = getUserPayment().dues;

  //  fill all values for fee structure for the user & automatic split heads.
  const newSelectedHead = totalHeadSplitterPaid(amount / 100, paymentDues);

  // update latest selectedHead with new subs dues.
  feeStructure.selectHeads = newSelectedHead;

  // get default bank account from aggregation pipeline
  const beneficiaryAccount = getRefPopulatePipeline[0].bankAccount[0];

  // get next installment no
  const getNextInstallment: () => Promise<number> = async () => {
    const getAllPaymentInvoice = await Invoice.countDocuments({
      NAME: payment_name,
      "USER ID": candidateId,
    }).exec();
    return getAllPaymentInvoice + 1;
  };
  // generate new invoice
  const fields = {
    name: payment_name,
    amount: amount / 100,
    total: _.filter(paymentDues, (head) => _.toLower(head.head) === "total")[0]
      .amount,
    feeStructure: feeStructure,
    mode: mode,
    beneficiaryAccount,
    userId: candidateId,
    signatures: {
      razorpayPaymentId,
      razorpayOrderId,
    },
    installmentNo: await getNextInstallment(),
  };

  // set body to fields for invoice api o
  req.body = fields;
  next();
};
export { verifyPaymentAuthenticity };
