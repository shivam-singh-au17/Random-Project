// Utils
import crypto from "crypto";
// Server imports
import { Request, Response } from "express";
import _ from "lodash";

// Integrations
import { Razorpay } from "../../../integrations/razorpay/razorpay.integration";
// Database Models
import { Payment, paymentAttrs } from "../../../models/paymentHistory";
import { RegistrationFormService } from "../../../models/registrationForm";
import { validateOrderValue } from "../../../services/integration/razorpay/create-order";
import { payment } from "../../payments/_.types";

// create new order on razor pay with rzp sdk & send order config to client.
const createOrder = async (req: Request, res: Response) => {
  // get payment name to fetch fee structure & payment configuration.
  const { payment_name } = req.params;
  const { paymentMethod, customAmount } = req.query;

  if (!payment_name) {
    return res.send(
      "payment-name is required. use '/payment/{payment-name}' route structure"
    );
  }

  //  1. FETCH PAYMENT HISTORY FOR THE USER
  const getRegistrationByEmail = await RegistrationFormService.findOne({
    email: req.user?.email,
  });
  const candidateId: string = getRegistrationByEmail?._id;

  //  2. GET PAYMENT WITHIN PAYMENT HISTORY WITH PAYMENT NAME.
  const getUserPaymentHistory: paymentAttrs | null = await Payment.findOne({
    user_id: candidateId,
  });

  // No Payment Fount Within User Payment History.
  if (_.isEmpty(getUserPaymentHistory)) {
    return res
      .status(404)
      .send({ error: "Couldn't Find Any Payment History For The User." });
  }

  const getUserPayment: () => payment = () =>
    _.filter(
      getUserPaymentHistory?.payments,
      (payment) => payment.name === payment_name
    )[0];

  //  3. GET TOTAL DUE AMOUNT
  const getDuesTotal: () => number = () =>
    _.filter(
      getUserPayment().dues,
      (head) => _.toLower(head.head) === "total"
    )[0].amount;
  //  3. GET TOTAL DUE AMOUNT
  const getPaidTotal: () => number = () =>
    _.filter(
      getUserPayment().paid,
      (head) => _.toLower(head.head) === "total"
    )[0].amount;

  // sums of total paid & due amount.
  const getTotalFeeStructureValue = getPaidTotal() + getDuesTotal();

  try {
    // create and validate order with payment method selected by users.
    const orderValue = validateOrderValue({
      selectedPaymentMethod: paymentMethod as string,
      duesTotal: getDuesTotal(),
      paidTotal: getPaidTotal(),
      paidAmount: parseInt(customAmount as string),
      totalFeeValue: getTotalFeeStructureValue, // for partial payment, check for fee structure value
    });

    // check for total value.
    if ((orderValue as number) <= 0) {
      return res.status(400).send({
        error:
          "Sum order value is zero, Couldn't create zero value order on Razor pay.",
      });
    }

    // create new receipt id & amount, current configuration for razorpay api.
    const rzpOptions = {
      amount: ((orderValue as number) * 100).toString(),
      currency: "INR",
      receipt: crypto.randomBytes(32),
    };
    // create new order with options and payment configuration. (RAZOR PAY SDK)
    const newOrder = await Razorpay.orders.create(rzpOptions);
    const { id, currency, amount } = newOrder;

    // send new order to client.
    return res.status(200).send({ id, currency, amount });
  } catch (err) {
    // return error if new order cannot be initialize on razorpay api.
    return res
      .status(400)
      .send({ error: [{ message: (err as Error).message as string }] });
  }
};

export { createOrder };
