import _ from "lodash";

import { ApplicationForm } from "../../../models/applicationForm";
import { bankAccountDocument } from "../../../models/bankAccount";
import { feeStructureCodesDocument } from "../../../models/feeStructureCodes";
import { Invoice } from "../../../models/invoice";

// get next sequence number
async function getNextSequenceValue() {
  const ret: any = await Invoice.find().sort({ _id: -1 }).limit(1);
  if (_.isEmpty(ret)) {
    return "1";
  }
  const parseInvoice = parseInt(ret[0]["INVOICE NO"]);
  return (parseInvoice + 1).toString();
}

const invoiceMapper = async (fields: {
  name: string;
  amount: number;
  total: number;
  feeStructure: feeStructureCodesDocument;
  mode: Record<string, object>;
  userId: string;
  signatures: Record<string, object>;
  installmentNo?: number;
  beneficiaryAccount: bankAccountDocument;
  remarks?: string;
}) => {
  const {
    name,
    amount,
    total,
    feeStructure,
    mode,
    userId,
    signatures,
    installmentNo,
    beneficiaryAccount,
    remarks,
  } = fields;
  // get user details
  const candidateApplicationDetails: any = await ApplicationForm.find(
    { candidateId: userId },
    {
      "personalDetails.firstName": 1,
      "contactDetails.mobile": 1,
      "contactDetails.parentEmail": 1,
    }
  )
    .lean()
    .exec();
  if (_.isEmpty(candidateApplicationDetails)) {
    throw new Error("No User Found With The ID");
  }

  // configuring detail to match invoice
  const userDetails = {
    ...candidateApplicationDetails[0].personalDetails,
    ...candidateApplicationDetails[0].contactDetails,
  };
  // create invoice
  const NewInvoice = Invoice.build({
    ["INVOICE NO"]: await getNextSequenceValue(),
    ["NAME"]: feeStructure.name,
    ["AMOUNT PAID"]: amount,
    ["TOTAL"]: total,
    ["SUB TOTAL"]: amount - total,
    ["FEE STRUCTURE"]: feeStructure,
    ["USER ID"]: userId,
    REMARKS: remarks,
    ["INSTALLMENT NO"]: installmentNo,
    ["BENEFICIARY ACCOUNT"]: beneficiaryAccount,
    SIGNATURES: signatures,
    ["USER DETAILS"]: {
      NAME: userDetails.firstName,
      CONTACT: userDetails.mobile,
      EMAIL: userDetails.parentEmail,
    },
    MODE: mode,
  });
  return NewInvoice;
};
export { invoiceMapper };
