import { Request, Response } from "express";
import _ from "lodash";
import { Invoice } from "../../models/invoice";
import { timeFormatted } from "../dcr/helper/date";

const getInvoices = async (req: Request, res: Response) => {
  const {
    date,
    dateTo,
    applicantId,
    collegeType,
    aidedType,
    programName,
    invoiceNo,
  } = req.query;
  const dateFromTo =
    dateTo === undefined
      ? {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(date, 24), // forward 24hr time.
        }
      : {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(dateTo, 0),
        };
  const generateFilterExpress = {
    createdAt: date !== undefined ? dateFromTo : undefined,
    "USER ID": applicantId,
    "INVOICE NO": invoiceNo,
    "FEE STRUCTURE.programName": programName,
    "FEE STRUCTURE.aidedType": aidedType,
    "FEE STRUCTURE.collegeType": collegeType,
  };
  // filtering out undefined query mapping.
  const filterQuery = _.omitBy(generateFilterExpress, function (...args) {
    return args.includes(undefined);
  });

  try {
    // if query is present then attach filterQuery, Other get all invoices
    const filter = _.isEmpty(req.query) ? {} : filterQuery;
    const invoices = await Invoice.find(filter).lean().exec();
    if (_.isEmpty(invoices)) {
      return res.status(404).send({ error: "No Invoice Found." });
    }
    return res.send({ data: invoices });
  } catch (_err) {
    return res.status(400).send({ error: (_err as Error).message });
  }
};

export { getInvoices };
