import { NextFunction, Request, Response } from "express";

// MONGO MODELS
import { Invoice } from "../../models/invoice";
// HELPERS
import { invoiceMapper } from "./helper/invoice-mapper";

// createInvoice API.
const createInvoiceAPI = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // map body with schema fields
    const GenerateInvoice = await invoiceMapper(req.body);
    // save invoice to database.
    await Invoice.create(GenerateInvoice);
    // attach fee to body for DCR to process the invoice.
    req.body = {
      user_id: GenerateInvoice["USER ID"],
      paymentName: GenerateInvoice["FEE STRUCTURE"].name,
      heads: GenerateInvoice["FEE STRUCTURE"].selectHeads,
      invoiceNo: GenerateInvoice["INVOICE NO"],
    };

    // pass request to assertDCR Controller
    next();
    //  deconstruct fee heads & save to dcr reports.
  } catch (_err) {
    res.status(400).send({
      message: ("Cannot Create Invoice, " +
        "Reasons: " +
        (_err as Error).message) as string,
    });
  }
};

export { createInvoiceAPI };
