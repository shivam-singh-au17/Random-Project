import { Request, Response } from "express";
import _ from "lodash";

import { DCR } from "../../models/dcrReport";
import { headMapper } from "./helper/headsMapper";
import { sumsMatchNTotal } from "./helper/sumMatchNTotal";

// head type
type HEAD = {
  head: string;
  amount: number | string;
};
const assertDcr = async (req: Request, res: Response) => {
  const { collegeType, aidedType, selectHeads } = req.body;
  // map heads with relevant info.
  const heads = headMapper(selectHeads);

  const date = {
    $gte: new Date().setHours(0, 0, 0),
    $lte: new Date().setHours(24, 0, 0), // forward 24hr time.
  };

  // filter to get current date with category bifurcations.
  const getByCurrentDateFilter = {
    createdAt: date,
    "TYPE OF COLLEGE": collegeType,
    "REPORT CATEGORY": aidedType,
  };

  // get existing dcr for today
  const getDCR = await DCR.findOne(getByCurrentDateFilter).lean().exec();
  // if no dcr report exists then create new dcr. [CREATE NEW]
  if (_.isEmpty(getDCR)) {
    // get total head from heads.
    const getTotal: any = _.filter(
      heads,
      _.conforms({ head: (head: string) => head === "total" })
    );
    const total: number = parseInt(getTotal[0].amount);

    // get next sequence number
    async function getNextSequenceValue() {
      const ret: any = await DCR.find().sort({ _id: -1 }).limit(1);
      if (_.isEmpty(ret)) {
        return "1";
      }
      const parseInvoice = parseInt(ret[0]["INVOICE NO"]);
      return (parseInvoice + 1).toString();
    }

    try {
      const report = DCR.build({
        ["INVOICE NO"]: await getNextSequenceValue(),
        ["TYPE OF COLLEGE"]: collegeType,
        ["REPORT CATEGORY"]: aidedType,
        TOTAL: total,
        HEADS: heads,
      });
      // create new dcr
      await DCR.create(report);
      return res
        .status(201)
        .send({ message: "Invoice Generated Successfully." });
    } catch (_err) {
      // unknown err type would support for custom & mongoose error.
      return res.status(400).send({
        error: `Couldn't Generate Invoice, ${
          (_err as Error).message as string
        }`,
      });
    }
  }

  // get total sums of head & total key from head to escalate total value. [UPDATE]
  try {
    const { updatedHeads, total } = sumsMatchNTotal(
      getDCR?.HEADS as HEAD[], // previous heads from database
      heads // new heads to be added.
    );
    // update doc in dcrs collections.
    await DCR.findOneAndUpdate(getByCurrentDateFilter, {
      HEADS: updatedHeads,
      TOTAL: total,
    });
    return res.status(201).send({ message: "Invoice Generated Successfully." });
  } catch (_err) {
    // unknown err type would support for custom & mongoose error.
    return res.status(400).send({
      error: `Couldn't Generate Invoice, ${(_err as Error).message as string}`,
    });
  }
};
export { assertDcr };
