import { Request, Response } from "express";
import _ from "lodash";
import { DCR } from "../../models/dcrReport";
import { timeFormatted } from "./helper/date";

const getDCR = async (req: Request, res: Response) => {
  const { date, dateTo, typeOfCollege, reportCategory, invoiceNo } = req.query;
  const dateFromTo =
    dateTo === undefined
      ? {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(date, 24), // forward 24hr time.
        }
      : {
          $gte: timeFormatted(date, 0),
          $lte: timeFormatted(dateTo, 0),
        };
  const generateFilterExpress = {
    createdAt: date !== undefined ? dateFromTo : undefined,
    "TYPE OF COLLEGE": typeOfCollege,
    "REPORT CATEGORY": reportCategory,
    "INVOICE NO": invoiceNo,
  };
  // filtering out undefined query mapping.
  const filterQuery = _.omitBy(generateFilterExpress, function (...args) {
    return args.includes(undefined);
  });

  try {
    // if query is present then attach filterQuery, Other get all dcrs
    const filter = _.isEmpty(req.query) ? {} : filterQuery;
    const dcrs = await DCR.find(filter).lean().exec();
    if (_.isEmpty(dcrs)) {
      return res.status(404).send({ error: "No DCR Reports Found." });
    }
    return res.status(200).send({ data: dcrs });
  } catch (_err) {
    return res.status(400).send({ error: "Couldn't Get DCR Reports " });
  }
};

export { getDCR };
