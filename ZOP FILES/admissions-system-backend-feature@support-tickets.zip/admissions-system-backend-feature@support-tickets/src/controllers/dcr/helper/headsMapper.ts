import _ from "lodash";

import { getFeeHead } from "../../../routes/feeHead/get-feeHead";

type HEAD = {
  head: string;
  amount: number | string;
};
// this maps the head with in relative & concise data.
const headMapper = (
  fields: { [key: string | number | symbol]: string | number | object }[]
) => {
  const mappedFields: HEAD[] = [];

  fields.forEach((field) => {
    const mappedField: HEAD = { head: "", amount: 0 };
    _.forIn(field, (value: any, key) => {
      if (key === "amount") mappedField.amount = parseInt(value);
      if (key === "head") mappedField.head = value.feeHeadName;
    });
    mappedFields.push(mappedField);
  });
  return mappedFields;
};
export { headMapper };

// example eg:
// const heads = headMapper([
//   {
//     selectedHeads: "626b356a7c85cdf364636bcb",
//     amount: 0,
//     _id: "626b364d7c85cdf364636bd4",
//     head: {
//       _id: "626b356a7c85cdf364636bcb",
//       feeHeadName: "lab",
//       priority: "string",
//       assignTo: "string",
//       createdAt: "2022-04-29T00:46:34.647Z",
//       updatedAt: "2022-04-29T00:46:34.647Z",
//     },
//   },
//   {
//     selectedHeads: "626b5b7bc320d6cd26ae79e1",
//     amount: "1000",
//     head: {
//       _id: "626b5b7bc320d6cd26ae79e1",
//       feeHeadName: "tuitions",
//       priority: "string",
//       assignTo: "string",
//       createdAt: "2022-04-29T00:46:34.647Z",
//       updatedAt: "2022-04-29T00:46:34.647Z",
//     },
//   },
// ]);

// output : [{amount:0,head:"lab"},{amount:1000,head:"tuitions"}]
