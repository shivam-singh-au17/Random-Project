// dependencies & helper
import _ from "lodash";

import { sumsMatchingHead } from "./sumMatchingHeads";

type HEAD = {
  head: string;
  amount: number | string;
  _id?: any;
};

const sumsMatchNTotal: (
  heads: HEAD[],
  heads2: HEAD[],
  ops?: string
) => {
  updatedHeads: HEAD[];
  total: number;
} = (heads, heads2, ops) => {
  // Sum New Value To Dcr & Save To Database
  const updatedHeads = sumsMatchingHead(heads as HEAD[], heads2 as HEAD[], ops);
  // get total head from heads.
  const getTotalUpdatedHeads: any = _.filter(
    updatedHeads,
    _.conforms({ head: (head: string) => head === "total" })
  );
  const total: number = parseInt(getTotalUpdatedHeads[0].amount);

  return { updatedHeads, total };
};

export { sumsMatchNTotal };
