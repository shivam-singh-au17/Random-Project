import _ from "lodash";

type HEAD = {
  head: string;
  amount: number | string;
  _id?: any;
};

export const sumsMatchingHead = (
  array1: HEAD[],
  array2: HEAD[],
  ops?: string
) => {
  const mergeArray = [...array1, ...array2];
  const getHeads = () => {
    const newarr: string[] = [];
    _.forEach(mergeArray, (value) => {
      newarr.push(value.head);
    });
    return Array.from(new Set(newarr));
  };
  const allHeads = getHeads();
  const calculatedHeads: any = [];
  allHeads.forEach((head) => {
    const similarHead = _.filter(mergeArray, (entry) => entry.head === head);
    const calculatedHead: HEAD = {
      head: "",
      amount: 0,
    };
    similarHead.forEach((head: HEAD) => {
      calculatedHead.head = head.head;
      calculatedHead.amount =
        ops === "-"
          ? parseInt(head.amount as string) - (calculatedHead.amount as number)
          : (calculatedHead.amount as number) + parseInt(head.amount as string);
    });
    calculatedHeads.push(calculatedHead);
  });
  return calculatedHeads;
};

// example e.g
// const array1 = [
//   { head: "LAB FEE", amount: 10 },
//   { head: "TERM FEE", amount: 10 },
//   { head: "ADMN..FEE", amount: 0 },
//   { head: "CAUTION MONEY", amount: 0 },
//   { head: "EXAM FEE", amount: 0 },
//   { head: "STUDENTS L.I.C", amount: 0 },
//   { head: "I. CARD FFEE", amount: 0 },
//   { head: "DEVLOPMENT FEE", amount: 0 },
//   { head: "S.P. FEE SOCIOLOGY", amount: 0 },
//   { head: "H.SC. EXAM FEE", amount: 0 },
//   { head: "L.C.", amount: 0 },
//   { head: "PROJECT /JOURNAL", amount: 0 },
//   { head: "ELE /COMP.", amount: 0 },
//   { head: "TUTION FEE", amount: 0 },
//   { head: "total", amount: 20 },
// ];
// const array2 = [
//   { head: "LAB FEE", amount: 10 },
//   { head: "TERM FEE", amount: 10 },
//   { head: "ADMN..FEE", amount: 0 },
//   { head: "CAUTION MONEY", amount: 0 },
//   { head: "EXAM FEE", amount: 0 },
//   { head: "STUDENTS L.I.C", amount: 0 },
//   { head: "I. CARD FFEE", amount: 0 },
//   { head: "DEVLOPMENT FEE", amount: 0 },
//   { head: "S.P. FEE SOCIOLOGY", amount: 0 },
//   { head: "H.SC. EXAM FEE", amount: 0 },
//   { head: "L.C.", amount: 0 },
//   { head: "PROJECT /JOURNAL", amount: 0 },
//   { head: "ELE /COMP.", amount: 0 },
//   { head: "TUTION FEE", amount: 0 },
//   { head: "total", amount: 20 },
// ];
// const newTrim = (arr) => {
//   const newArr: any = [];
//   _.forEach(arr, (item) => {
//     const headVal = item.head;
//     const trimHead = headVal.replace(" ", "");
//     const newObject = {
//       head: trimHead.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ""),
//       amount: item.amount,
//     };
//     newArr.push(newObject);
//   });
//   return newArr;
// };

// const results = sumsMatchingHead(array1, array2);
// console.log(results);
