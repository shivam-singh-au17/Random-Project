export const getDayMonthYear = (getDate?: any) => {
  const date = getDate !== undefined ? new Date(getDate) : new Date();
  const formattedDate = `${date.getDate()}-${date.getMonth()}-${date.getFullYear()}`;
  return formattedDate;
};

export const timeFormatted = (getDate: any, hours: number) => {
  const date = new Date(getDate).setHours(hours, 0, 0);
  return new Date(date);
};
