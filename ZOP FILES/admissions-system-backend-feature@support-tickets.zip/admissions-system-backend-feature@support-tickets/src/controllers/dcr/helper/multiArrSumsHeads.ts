import _ from "lodash";

type HEAD = {
  head: string;
  amount: number | string;
};
export const multiArrSumsHeads = (data: any[]) => {
  const feeStructures: any[] = [];
  _.forEach(data, function (invoice) {
    const heads: HEAD[] = [];
    if (invoice["FEE STRUCTURE"]?.selectHeads) {
      _.forEach(invoice["FEE STRUCTURE"].selectHeads, function (head) {
        const mappedHead = {
          head: head.head.feeHeadName,
          amount: head.amount,
        };
        heads.push(mappedHead);
      });
      feeStructures.push(heads);
    }
  });

  const newMergedAllInvoices: HEAD[] = [];
  feeStructures.forEach((invoice) => {
    newMergedAllInvoices.push(...invoice);
  });

  const getHeads = () => {
    const newarr: string[] = [];
    _.forEach(newMergedAllInvoices, (value) => {
      newarr.push(value.head);
    });
    return Array.from(new Set(newarr));
  };
  const allHeads = getHeads();
  const calculatedHeads: HEAD[] = [];
  allHeads.forEach((head) => {
    const similarHead = _.filter(
      newMergedAllInvoices,
      (entry) => entry.head === head
    );
    const calculatedHead: HEAD = {
      head: "",
      amount: 0,
    };
    similarHead.forEach((head: HEAD) => {
      calculatedHead.head = head.head;
      calculatedHead.amount =
        (calculatedHead.amount as number) + parseInt(head.amount as string);
    });
    calculatedHeads.push(calculatedHead);
  });
  return calculatedHeads;
};
