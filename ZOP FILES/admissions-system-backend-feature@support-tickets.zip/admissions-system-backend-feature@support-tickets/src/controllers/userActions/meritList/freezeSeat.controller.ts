import { ApplicationForm } from "../../../models/applicationForm";
import { Request, Response } from "express";

const freezeSeatController = async (req: Request, res: Response) => {
  const { user_id } = req.params;
  try {
    // update user step counter to +1
    await ApplicationForm.updateOne(
      { candidateId: user_id },
      { $set: { stepCounter: 5 } }
    );
    return res.status(202).send({ message: "Seat Freezed Successfully." });
  } catch (err) {
    return res.status(202).send({ message: "Seat Couldn't Be Freeze." });
  }
};
export { freezeSeatController };
