import dotenv from "dotenv";
dotenv.config();

export const dbUrl = process.env.DBURL!;
export const port = process.env.PORT || parseInt("3001");
export const jwtSecretKey = process.env.JWT_SECRET_KEY!;
export const mailService = process.env.MAIL_SERVICE!;
export const mailUser = process.env.MAIL_USER!;
export const mailPass = process.env.MAIL_PASS!;
export const senderAddress = process.env.SENDER_ADDRESS!;
export const adminEmail = process.env.ADMIN_EMAIL!;
