import axios from "axios";
import _ from "lodash";

class IAM {
  public api = process.env.MS_IAM;

  public requestService = async (data, path, req?: any) => {
    let error, resData;

    const options = req
      ? {
          method: "POST",
          url: this.api + path,
          data: data,
          headers: req.headers.cookie
            ? {
                Cookie: req.headers.cookie,
              }
            : undefined,
        }
      : {
          method: "POST",
          url: this.api + path,
          data: data,
        };

    // filtering out undefined options for axios mapping.
    const filterOptions = _.omitBy(options, function (...args) {
      return args.includes(undefined);
    });
    await axios(filterOptions)
      .then((response) => {
        response.headers["set-cookie"]
          ? (resData = {
              data: response.data,
              cookie: response.headers["set-cookie"],
              status: response.status,
            })
          : (resData = response.data);
      })
      .catch((_err) => {
        error = _err.response.data;
      });
    return { error, resData };
  };

  // applicant sign-up with identity-management-service
  async applicantSignUp(data: {
    email: string;
    password: string;
    roles: string[];
    modules: string[];
  }) {
    return await this.requestService(data, `/${process.env.tenantId}/sign-up`);
  }
  // roles signIn
  async signInUser(data: { email: string; password: string }) {
    return await this.requestService(data, `/sign-in/user`);
  }
  // change password for auth user.
  async changePassword(
    data: { currentPassword: string; newPassword: string },
    req
  ) {
    return await this.requestService(data, "/change-password", req);
  }
  // confirm registration after signUp
  async confirmRegistration(data: {
    userName: string;
    verificationCode: string;
  }) {
    return await this.requestService(data, "/confirm-registration");
  }
  // confirm registration after signUp
  async resendConfirmRegistration(data: { userName: string }) {
    return await this.requestService(data, "/resend-confirmation-code");
  }

  // confirm registration after signUp
  async forgetPassword(
    data: {
      email: string;
      verificationCode?: string;
      newPassword?: string;
    },
    req
  ) {
    return await this.requestService(data, "/forget-password", req);
  }
}

const IdentityNAccess = new IAM();
export { IdentityNAccess };
