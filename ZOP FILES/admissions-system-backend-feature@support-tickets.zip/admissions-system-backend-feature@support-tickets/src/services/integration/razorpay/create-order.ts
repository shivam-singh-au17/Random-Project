import _ from "lodash";

// bare minium amount for accepting allow dynamics payments
const minimumThreshold: number =
  parseInt(process.env.PAYMENT_BARE_MINIMUM_PERCENTAGE as string) / 100;
// payment methods
enum paymentMethod {
  PARTIAL = "PARTIAL",
  FULL = "FULL",
  HALF = "HALF",
  CUSTOM = "CUSTOM",
  REMAINING = "REMAINING",
}
const createOrderValue = () => {
  return {
    partial: (total: number) => {
      return Math.round(total * minimumThreshold);
    },
    half: (total: number) => {
      return Math.round(total * 0.5);
    },
    custom: (total: number, amount: number) => {
      if (amount >= Math.round(total * minimumThreshold)) {
        return amount;
      }
      return null;
    },
  };
};

const validateOrderValue = (order: {
  selectedPaymentMethod: string;
  duesTotal: number;
  paidTotal: number;
  paidAmount?: number;
  totalFeeValue?: number;
}) => {
  const { selectedPaymentMethod, duesTotal, paidAmount, totalFeeValue } = order;
  // instance for order value
  const orderValue = createOrderValue();

  // tracking user payment eligibility
  const eligible = {
    HALF: false,
    FULL: true,
    PARTIAL: false,
    CUSTOM: false,
  };

  const PaymentMethods = {
    halfEligibleCheck: () => {
      const orderVal = orderValue.half(totalFeeValue as number);
      if (duesTotal >= (totalFeeValue as number) / 2) {
        eligible.HALF = true;
        return orderVal;
      }
    },
    partialEligibleCheck: () => {
      const orderVal = orderValue.partial(totalFeeValue as number);
      // T-1000 | I-200,200,200 | C-300 | P-200 D-100
      if (duesTotal >= orderVal) {
        eligible.PARTIAL = true;
        return orderVal;
      }
    },
    customEligibleCheck: () => {
      const orderVal = orderValue.custom(duesTotal, paidAmount as number);
      // T-1000 | I-200,200,200 | C-300 | P-200 D-100
      if (orderVal != null && duesTotal >= (orderVal as number)) {
        eligible.CUSTOM = true;
        return orderVal;
      }
    },
    validateAll: () => {
      PaymentMethods.customEligibleCheck();
      PaymentMethods.halfEligibleCheck();
      PaymentMethods.partialEligibleCheck();
      const eligibleMethods: string[] = [];
      _.forIn(eligible, (value, key) => {
        if (value === true) {
          eligibleMethods.push(key);
        }
      });
      return eligibleMethods;
    },
  };

  if (selectedPaymentMethod === paymentMethod.PARTIAL) {
    const orderVal = orderValue.partial(totalFeeValue as number);
    // T-1000 | I-200,200,200 | C-300 | P-200 D-100
    if (duesTotal >= orderVal) {
      return orderVal;
    }
    // validation all eligible method for the user & get all eligible methods.
    const userEligibleMethods = PaymentMethods.validateAll();
    throw new Error(
      "Couldn't Pay In Partial, You're Eligible To Pay In " +
        userEligibleMethods.toString() +
        " Payment Method"
    );
  }

  if (selectedPaymentMethod === paymentMethod.HALF) {
    // T-1000 | I-500 | P-200,| D-300 | Dues = 500 >= A
    const orderVal = orderValue.half(totalFeeValue as number);
    if (duesTotal >= (totalFeeValue as number) / 2) {
      return orderVal;
    }
    // validation all eligible method for the user & get all eligible methods.
    const userEligibleMethods = PaymentMethods.validateAll();
    throw new Error(
      "Couldn't Pay In Half, You're Eligible To Pay In " +
        userEligibleMethods.toString() +
        " Payment Method"
    );
  }

  if (selectedPaymentMethod === paymentMethod.CUSTOM) {
    const orderVal = orderValue.custom(
      totalFeeValue as number,
      paidAmount as number
    );
    if (orderVal === null) {
      throw new Error(
        `Custom Amount Should Be Greater Than Bare Minium Amount Of : ${Math.round(
          (totalFeeValue as number) * minimumThreshold
        )}`
      );
    }
    if (orderVal != null && duesTotal >= (orderVal as number)) {
      // T-1000 | I-200,200,200 | C-300 | P-200 D-100
      return orderVal;
    }
    const userEligibleMethods = PaymentMethods.validateAll();
    throw new Error(
      "Couldn't Pay In Custom, You're Eligible To Pay In " +
        userEligibleMethods.toString() +
        " Payment Method"
    );

    // validation all eligible method for the user & get all eligible methods.
  }

  if (
    selectedPaymentMethod === paymentMethod.FULL ||
    selectedPaymentMethod === paymentMethod.REMAINING
  ) {
    return duesTotal;
  }
};

export { createOrderValue, validateOrderValue };
