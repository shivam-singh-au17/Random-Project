import { HEAD } from "../../../controllers/payments/_.types";
import _ from "lodash";

const totalHeadSplitter = (amount: number, dues: HEAD[]) => {
  let duesAssociator = amount;
  const newDues: HEAD[] = [];
  const getTotalHead = _.filter(
    dues,
    (head) => _.toLower(head.head) === "total"
  )[0];
  const headTotal = { head: "total", amount: getTotalHead.amount };
  dues.forEach((dueHead) => {
    const newDueHead = { head: dueHead.head, amount: dueHead.amount };
    if (duesAssociator > 0) {
      if (duesAssociator >= dueHead.amount) {
        newDueHead.amount = newDueHead.amount - dueHead.amount;
        headTotal.amount = headTotal.amount - dueHead.amount;
        duesAssociator -= dueHead.amount;
        newDues.push(newDueHead);
        return;
      }
      if (duesAssociator <= dueHead.amount) {
        newDueHead.amount = newDueHead.amount - duesAssociator;
        headTotal.amount = headTotal.amount - duesAssociator;
        duesAssociator -= dueHead.amount;
        newDues.push(newDueHead);
        return;
      }
    }
    return newDues.push(newDueHead);
  });
  // filter out previous total head
  const newDuesWithOutTotal = _.filter(
    newDues,
    (head) => _.toLower(head.head) !== "total"
  );

  return [newDuesWithOutTotal, headTotal];
};

const totalHeadSplitterPaid = (amount: number, dues: HEAD[]) => {
  let duesAssociator = amount;
  const newDues: { head: { feeHeadName: string }; amount: number }[] = [];
  const headTotal = { head: { feeHeadName: "total" }, amount: amount };
  dues.forEach((dueHead) => {
    const newDueHead = {
      head: { feeHeadName: dueHead.head },
      amount: dueHead.amount,
    };
    if (duesAssociator > 0) {
      if (duesAssociator >= dueHead.amount) {
        newDueHead.amount = dueHead.amount;
        duesAssociator -= dueHead.amount;
        newDues.push(newDueHead);
        return;
      }
      if (duesAssociator <= dueHead.amount) {
        newDueHead.amount = duesAssociator;
        duesAssociator -= dueHead.amount;
        newDues.push(newDueHead);
        return;
      }
    }
    return newDues.push({ head: { feeHeadName: dueHead.head }, amount: 0 });
  });
  // filter out previous total head
  const newDuesWithOutTotal = _.filter(
    newDues,
    (head) => _.toLower(head.head.feeHeadName) !== "total"
  );
  return [...newDuesWithOutTotal, headTotal];
};
export { totalHeadSplitter, totalHeadSplitterPaid };

// eg:
// const paymentDues = [
//   {
//     head: "LAB FEE",
//     amount: 70,
//     _id: "6295474ddc64568641bd5e91",
//   },
//   {
//     head: "TERM FEE",
//     amount: 44,
//     _id: "6295474ddc64568641bd5e92",
//   },
//   {
//     head: "ADMN..FEE",
//     amount: 0,
//     _id: "6295474ddc64568641bd5e93",
//   },
//   {
//     head: "CAUTION MONEY",
//     amount: 100,
//     _id: "6295474ddc64568641bd5e94",
//   },
//   {
//     head: "EXAM FEE",
//     amount: 700,
//     _id: "6295474ddc64568641bd5e95",
//   },
//   {
//     head: "STUDENTS L.I.C",
//     amount: 40,
//     _id: "6295474ddc64568641bd5e96",
//   },
//   {
//     head: "I. CARD FFEE",
//     amount: 150,
//     _id: "6295474ddc64568641bd5e97",
//   },
//   {
//     head: "DEVLOPMENT FEE",
//     amount: 0,
//     _id: "6295474ddc64568641bd5e98",
//   },
//   {
//     head: "S.P. FEE SOCIOLOGY",
//     amount: 0,
//     _id: "6295474ddc64568641bd5e99",
//   },
//   {
//     head: "H.SC. EXAM FEE",
//     amount: 530,
//     _id: "6295474ddc64568641bd5e9a",
//   },
//   {
//     head: "L.C.",
//     amount: 100,
//     _id: "6295474ddc64568641bd5e9b",
//   },
//   {
//     head: "PROJECT /JOURNAL",
//     amount: 1050,
//     _id: "6295474ddc64568641bd5e9c",
//   },
//   {
//     head: "ELE /COMP.",
//     amount: 0,
//     _id: "6295474ddc64568641bd5e9d",
//   },
//   {
//     head: "TUTION FEE",
//     amount: 254,
//     _id: "6295474ddc64568641bd5e9e",
//   },
//   {
//     head: "total",
//     amount: 3038,
//     _id: "6295474ddc64568641bd5e9f",
//   },
// ];

// const cal = totalHeadSplitterPaid(3038, paymentDues);
// console.log(cal);
