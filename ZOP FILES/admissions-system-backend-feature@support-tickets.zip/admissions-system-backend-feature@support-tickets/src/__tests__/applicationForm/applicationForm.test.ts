import { app } from "../../app";
import request from "supertest";

describe("All POST & GET related Application Form Routers", () => {
  describe("POST /create-form", () => {
    it("It should response 200 for POST /create-form method", async () => {
      await request(app).post("/registration").send({
        firstName: "Shivam",
        lastName: "Singh",
        email: "shivamsingh4458@gmail.com",
        password: "Shivam@123",
        phoneNumber: "8823457899",
        picture:
          "https://www.kindpng.com/picc/m/72-723761_student-png-sammilani-mahavidyalaya-undergraduate-and-dummy-user.png",
      });

      const temp = await request(app).get("/get-registrations");

      const res = await request(app)
        .post("/create-form")
        .send({
          candidateId: `${temp.body[0]._id}`,
          programName: "BSC",
          programCode: "BC8756",
          preferenceArray: [
            {
              streamCode: "SC44",
              preference: 1,
            },
            {
              streamCode: "BC23",
              preference: 2,
            },
          ],
          academicYear: "2021-22",
          yearAppliedFor: "FY",
        });

      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-forms", () => {
    it("It should response 200 for GET /get-forms method", async () => {
      const res = await request(app).get("/get-forms");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-form-id/:id", () => {
    it("It should response 200 for GET /get-form-id/:id method", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app).get(`/get-form-id/${temp.body[0]._id}`);
      expect(res.statusCode).toEqual(200);
    });
  });
});

describe("All STEP 1 & 2 UPDATE related Application Form Routers", () => {
  describe("PATCH /update-applicant/:id", () => {
    it("It should response 400 for PATCH /update-personal/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-personal/${temp.body[0]._id}`)
        .send({
          personalDetails: {
            aadharNumber: "012345678912",
            firstName: "First Name",
            lastName: "Last Name",
            fatherName: "Father Name",
            motherName: "Mother Name",
            placeOfBirth: "Place Of Birth",
            dateOfBirth: "Date Of Birth",
            motherTongue: "Mother Tongue",
            sikhMinority: "Sikh Minority",
            category: "Category",
            bloodGroup: "Blood Group",
            nationality: "Nationality",
            religion: "Religion",
            gender: "Gender",
            maritalStatus: "Marital Status",
            subCaste: "Sub Caste",
            collegeSetMinority: "College Set Minority",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-contact/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-contact/${temp.body[0]._id}`)
        .send({
          contactDetails: {
            mobile: "0123456789",
            parentMobile: "9876543210",
            parentEmail: "test@gmail.com",
            district: "District",
            address: "Address",
            pinCode: "123456",
            state: "State",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-academic/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-academic/${temp.body[0]._id}`)
        .send({
          academicDetails: {
            matricEducation: {
              yearOfPassing: "2014",
              instituteName: "A. B. I. C.",
              gradeAwarded: "A",
              percentage: "80%",
              physicsMarks: "70",
              chemistryMarks: "80",
              mathsMarks: "75",
              biologyMarks: "85",
            },
            intermediateEducation: {
              yearOfPassing: "2016",
              instituteName: "S. P. I. C.",
              gradeAwarded: "A",
              percentage: "70%",
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-legal/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-legal/${temp.body[0]._id}`)
        .send({
          legalDetails: {
            domicile: "Domicile",
            parentOccupation: "Parent Occupation",
            annualIncome: 10000,
            reservationInformation: "Reservation Information",
            panNumber: "ABCDE4458F",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-declaration/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-applicant/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-applicant/${temp.body[0]._id}`)
        .send({
          prnNumber: "TEST4458",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-personal/:id", () => {
    it("It should response 400 for PATCH /update-contact/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-contact/${temp.body[0]._id}`)
        .send({
          contactDetails: {
            mobile: "0123456789",
            parentMobile: "9876543210",
            parentEmail: "test@gmail.com",
            district: "District",
            address: "Address",
            pinCode: "123456",
            state: "State",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-academic/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-academic/${temp.body[0]._id}`)
        .send({
          academicDetails: {
            matricEducation: {
              yearOfPassing: "2014",
              instituteName: "A. B. I. C.",
              gradeAwarded: "A",
              percentage: "80%",
              physicsMarks: "70",
              chemistryMarks: "80",
              mathsMarks: "75",
              biologyMarks: "85",
            },
            intermediateEducation: {
              yearOfPassing: "2016",
              instituteName: "S. P. I. C.",
              gradeAwarded: "A",
              percentage: "70%",
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-legal/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-legal/${temp.body[0]._id}`)
        .send({
          legalDetails: {
            domicile: "Domicile",
            parentOccupation: "Parent Occupation",
            annualIncome: 10000,
            reservationInformation: "Reservation Information",
            panNumber: "ABCDE4458F",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-declaration/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-personal/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-personal/${temp.body[0]._id}`)
        .send({
          personalDetails: {
            aadharNumber: "012345678912",
            firstName: "First Name",
            lastName: "Last Name",
            fatherName: "Father Name",
            motherName: "Mother Name",
            placeOfBirth: "Place Of Birth",
            dateOfBirth: "Date Of Birth",
            motherTongue: "Mother Tongue",
            sikhMinority: "Sikh Minority",
            category: "Category",
            bloodGroup: "Blood Group",
            nationality: "Nationality",
            religion: "Religion",
            gender: "Gender",
            maritalStatus: "Marital Status",
            subCaste: "Sub Caste",
            collegeSetMinority: "College Set Minority",
          },
        });
      expect(res.statusCode).toEqual(200);
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });
  });

  describe("PATCH /update-contact/:id", () => {
    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-academic/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-academic/${temp.body[0]._id}`)
        .send({
          academicDetails: {
            matricEducation: {
              yearOfPassing: "2014",
              instituteName: "A. B. I. C.",
              gradeAwarded: "A",
              percentage: "80%",
              physicsMarks: "70",
              chemistryMarks: "80",
              mathsMarks: "75",
              biologyMarks: "85",
            },
            intermediateEducation: {
              yearOfPassing: "2016",
              instituteName: "S. P. I. C.",
              gradeAwarded: "A",
              percentage: "70%",
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-legal/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-legal/${temp.body[0]._id}`)
        .send({
          legalDetails: {
            domicile: "Domicile",
            parentOccupation: "Parent Occupation",
            annualIncome: 10000,
            reservationInformation: "Reservation Information",
            panNumber: "ABCDE4458F",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-declaration/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-contact/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-contact/${temp.body[0]._id}`)
        .send({
          contactDetails: {
            mobile: "0123456789",
            parentMobile: "9876543210",
            parentEmail: "test@gmail.com",
            district: "District",
            address: "Address",
            pinCode: "123456",
            state: "State",
          },
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-academic/:id", () => {
    it("It should response 400 for PATCH /update-legal/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-legal/${temp.body[0]._id}`)
        .send({
          legalDetails: {
            domicile: "Domicile",
            parentOccupation: "Parent Occupation",
            annualIncome: 10000,
            reservationInformation: "Reservation Information",
            panNumber: "ABCDE4458F",
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-declaration/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-academic/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-academic/${temp.body[0]._id}`)
        .send({
          academicDetails: {
            matricEducation: {
              yearOfPassing: "2014",
              instituteName: "A. B. I. C.",
              gradeAwarded: "A",
              percentage: "80%",
              physicsMarks: "70",
              chemistryMarks: "80",
              mathsMarks: "75",
              biologyMarks: "85",
            },
            intermediateEducation: {
              yearOfPassing: "2016",
              instituteName: "S. P. I. C.",
              gradeAwarded: "A",
              percentage: "70%",
            },
          },
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-legal/:id", () => {
    it("It should response 400 for PATCH /update-declaration/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-legal/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-legal/${temp.body[0]._id}`)
        .send({
          legalDetails: {
            domicile: "Domicile",
            parentOccupation: "Parent Occupation",
            annualIncome: 10000,
            reservationInformation: "Reservation Information",
            panNumber: "ABCDE4458F",
          },
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-declaration/:id", () => {
    it("It should response 400 for PATCH /update-mandatory-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-declaration/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-declaration/${temp.body[0]._id}`)
        .send({
          declaration: {
            place: "India",
            date: "Today",
            termsCondition: true,
          },
        });
      expect(res.statusCode).toEqual(200);
    });
  });
});

describe("All STEP 3 UPDATE related Application Form Routers", () => {
  describe("PATCH /update-mandatory-documents/:id", () => {
    it("It should response 400 for PATCH /update-other-documents/:id method because filling BACK form without filling FRONT form", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-other-documents/${temp.body[0]._id}`)
        .send({
          documentName: "TEST NAME",
          url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
          submitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 400 for PATCH /update-status/:id method because we are submitted the form wrong way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Not authorized",
        message: "Fill the front form data first and then the back data",
      });
    });

    it("It should response 200 for PATCH /update-mandatory-documents/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-mandatory-documents/${temp.body[0]._id}`)
        .send({
          mandatoryDocuments: {
            signature: {
              documentName: "PAN CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
            photo: {
              documentName: "AADHAR CARD",
              url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
              submitted: true,
            },
          },
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-other-documents/:id", () => {
    it("It should response 200 for PATCH /update-status/:id method because we are submitted the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(200);
    });

    it("It should response 200 for PATCH /update-other-documents/:id method because we are filling the form correct way", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-other-documents/${temp.body[0]._id}`)
        .send({
          documentName: "TEST NAME",
          url: "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/thumbnails/image/file.jpg",
          submitted: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-one-other-doc/:id/:odId", () => {
    it("It should response 200 for PATCH /update-one-other-doc/:id/:odId method", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(
          `/update-one-other-doc/${temp.body[0]._id}/${temp.body[0].otherDocuments[0]._id}`
        )
        .send({
          documentName: "TEST Document Name",
          url: "http://localhost:3001/get-forms",
          submitted: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });
});

describe("All FORM STATUS related Application Form Routers", () => {
  describe("PATCH /update-status/:id", () => {
    it("It should response 200 for PATCH /update-status/:id method", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-status/${temp.body[0]._id}`)
        .send({
          formSubmitted: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-application-fee/:id", () => {
    it("It should response 200 for PATCH /update-application-fee/:id method", async () => {
      const temp = await request(app).get("/get-forms");
      const res = await request(app)
        .patch(`/update-application-fee/${temp.body[0]._id}`)
        .send({
          applicationFee: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });
});

describe("All Staff App Routers", () => {
  describe("All GET related Application Form Routers For Staff App", () => {
    describe("GET /get-by-candidateId/:id", () => {
      it("It should response 200 for GET /get-by-candidateId/:id method", async () => {
        const res = await request(app).get(
          `/get-by-candidateId/625638e250c433571c5919c1`
        );
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-forms/:programName", () => {
      it("It should response 200 for GET /get-forms/:programName method", async () => {
        const res = await request(app).get("/get-forms/BTECH");
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-forms/:academicYear", () => {
      it("It should response 200 for GET /get-forms/:academicYear method", async () => {
        const res = await request(app).get("/get-forms/2022-23");
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-forms/:yearAppliedFor", () => {
      it("It should response 200 for GET /get-forms/:yearAppliedFor method", async () => {
        const res = await request(app).get("/get-forms/FY");
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-forms/:programName/:academicYear", () => {
      it("It should response 200 for GET /get-forms/:programName/:academicYear method", async () => {
        const res = await request(app).get("/get-forms/BTECH/2022-23");
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-forms/:programName/:academicYear/:yearAppliedFor", () => {
      it("It should response 200 for GET /get-forms/:programName/:academicYear/:yearAppliedFor method", async () => {
        const res = await request(app).get("/get-forms/BTECH/2022-23/FY");
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Documents UPDATE related Application Form Routers For Staff App", () => {
    describe("PATCH /update-documents-status/:id/:mdId", () => {
      it("It should response 200 for PATCH /update-documents-status/:id/:mdId method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(
            `/update-documents-status/${temp.body[0]._id}/${temp.body[0].otherDocuments[0]._id}`
          )
          .send({
            message: "TEST Message",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("PATCH /all-documents-status/:id", () => {
      it("It should response 200 for PATCH /all-documents-status/:id method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/all-documents-status/${temp.body[0]._id}`)
          .send({
            message: "TEST Message",
          });
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Submitted Forms Routers For Staff App", () => {
    describe("PATCH /update-status/:id", () => {
      it("It should response 200 for PATCH /update-status/:id method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/update-status/${temp.body[0]._id}`)
          .send({
            formSubmitted: true,
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("PATCH /update-application-fee/:id", () => {
      it("It should response 200 for PATCH /update-application-fee/:id method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/update-application-fee/${temp.body[0]._id}`)
          .send({
            applicationFee: true,
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /candidates", () => {
      it("It should response 200 for GET /candidates method because right now applicationFee and formSubmitted status are true", async () => {
        const res = await request(app).get("/candidates");
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Review Forms Routers For Staff App", () => {
    describe("PATCH /candidates/update-review-status/", () => {
      it("It should response 400 for PATCH /candidates/update-scrutiny-status/:id method because not submit the form, not pay the fee", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/update-scrutiny-status/${temp.body[0]._id}`)
          .send({
            inScrutiny: true,
            scrutinizedPerson: "scrutinytest@gmail.com",
          });
        expect(res.statusCode).toEqual(400);
        expect(res.body).toEqual({
          status: "Not authorized",
          message: "First, submit the form, pay the fee and review the form",
        });
      });

      it("It should response 200 for PATCH /candidates/update-review-status/ method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/update-review-status`)
          .send({
            formIdArray: [`${temp.body[0]._id}`],
            adminEmail: "shivamsingh4458@gmail.com",
            inReview: true,
            reviewedPerson: "reviewtest@gmail.com",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /reviewed-candidates/", () => {
      it("It should response 200 for GET /reviewed-candidates/ method because right now inReview status are true", async () => {
        const res = await request(app).get("/reviewed-candidates/");
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Scrutinized Forms Routers For Staff App", () => {
    describe("PATCH /candidates/update-scrutiny-status/:id", () => {
      it("It should response 400 for PATCH /candidates/allocate-department/:id method because not passed the Scrutiny Round", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/allocate-department/${temp.body[0]._id}`)
          .send({
            isAllocatedDept: true,
            allocatedDeptCode: ["626fd9c87ad5be525d8c8506"],
            allocatedDeptPerson: "allocatetest@gmail.com",
          });
        expect(res.statusCode).toEqual(400);
        expect(res.body).toEqual({
          status: "Not authorized",
          message: "Application Form has not passed the Scrutiny Round",
        });
      });

      it("It should response 200 for PATCH /candidates/update-scrutiny-status/:id method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/update-scrutiny-status/${temp.body[0]._id}`)
          .send({
            inScrutiny: true,
            scrutinizedPerson: "scrutinytest@gmail.com",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /scrutinized-candidates/", () => {
      it("It should response 200 for GET /scrutinized-candidates/ method because right now scrutiny status are true", async () => {
        const res = await request(app).get("/scrutinized-candidates/");
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Allocate Department And Merit List Forms Routers For Staff App", () => {
    describe("PATCH /candidates/allocate-department/:id", () => {
      it("It should response 200 for PATCH /candidates/allocate-department/:id method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/allocate-department/${temp.body[0]._id}`)
          .send({
            isAllocatedDept: true,
            allocatedDeptCode: ["626fd9c87ad5be525d8c8506"],
            allocatedDeptPerson: "allocatetest@gmail.com",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("PATCH /candidates/update-merit-list-status", () => {
      it("It should response 200 for PATCH /candidates/update-merit-list-status method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .patch(`/candidates/update-merit-list-status`)
          .send({
            formIdArray: [`${temp.body[0]._id}`],
            verificationRoundPerson: "verificationtest@gmail.com",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /merit-list-candidates/", () => {
      it("It should response 200 for GET /merit-list-candidates/ method because right now verificationRound status are PASS", async () => {
        const res = await request(app).get("/merit-list-candidates/");
        expect(res.statusCode).toEqual(200);
      });
    });
  });

  describe("All Merit List Information Forms Routers For Staff App", () => {
    describe("POST /candidates/publish-merit-list/", () => {
      it("It should response 200 for POST /candidates/publish-merit-list/ method", async () => {
        const temp = await request(app).get("/get-forms");
        const res = await request(app)
          .post(`/candidates/publish-merit-list/`)
          .send({
            name: "TEST Name",
            number: 10,
            branch: "Science",
            department: "BAFY",
            publishDate: "08/05/2022 - 12:37 PM",
            programName: "BSC",
            programCode: "1234ADST",
            selectedStudents: [`${temp.body[0]._id}`],
            publishMeritListPerson: "publishtest@gmail.com",
          });
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-merit-list-info/", () => {
      it("It should response 200 for GET /get-merit-list-info/ method", async () => {
        const res = await request(app).get("/get-merit-list-info/");
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("GET /get-one-merit-list-info/:id", () => {
      it("It should response 200 for GET /get-one-merit-list-info/:id method", async () => {
        const temp = await request(app).get("/get-merit-list-info/");
        const res = await request(app).get(
          `/get-one-merit-list-info/${temp.body[0]._id}`
        );
        expect(res.statusCode).toEqual(200);
      });
    });

    describe("DELETE /delete-merit-list-info/:id", () => {
      it("It should response 200 for DELETE /delete-merit-list-info/:id method", async () => {
        const temp = await request(app).get("/get-merit-list-info/");
        const res = await request(app).delete(
          `/delete-merit-list-info/${temp.body[0]._id}`
        );
        expect(res.statusCode).toEqual(200);
      });
    });
  });
});
