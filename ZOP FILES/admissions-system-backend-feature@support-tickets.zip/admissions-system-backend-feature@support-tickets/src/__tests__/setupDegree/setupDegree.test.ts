import { app } from "../../app";
import request from "supertest";

describe("All Setup Degree Routers", () => {
  describe("POST /create-setupDegree", () => {
    it("It should response 200 for POST /create-setupDegree method", async () => {
      const res = await request(app).post("/create-setupDegree").send({
        degreeFullName: "Degree Full Name",
        degreeShortName: "Degree Short Name",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-setupDegree", () => {
    it("It should response 200 for GET /get-setupDegree method", async () => {
      const res = await request(app).get("/get-setupDegree");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-setupDegree/:id", () => {
    it("It should response 200 for GET /get-one-setupDegree/:id method", async () => {
      const resId = await request(app).get("/get-setupDegree");
      const res = await request(app).get(
        `/get-one-setupDegree/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-setupDegree/:id", () => {
    it("It should response 200 for PATCH /update-setupDegree/:id method", async () => {
      const resId = await request(app).get("/get-setupDegree");
      const res = await request(app)
        .patch(`/update-setupDegree/${resId.body[0]._id}`)
        .send({
          degreeFullName: "TEST Degree Full Name",
          degreeShortName: "TEST Degree Short Name",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-setupDegree/:id", () => {
    it("It should response 200 for DELETE /delete-setupDegree/:id method", async () => {
      const resId = await request(app).get("/get-setupDegree");
      const res = await request(app).delete(
        `/delete-setupDegree/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
