import { app } from "../../app";
import request from "supertest";

describe("All Disability Routers", () => {
  describe("POST /create-disability", () => {
    it("It should response 200 for POST /create-disability method", async () => {
      const res = await request(app).post("/create-disability").send({
        disability: "Disability",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-disability", () => {
    it("It should response 200 for GET /get-disability method", async () => {
      const res = await request(app).get("/get-disability");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-disability/:id", () => {
    it("It should response 200 for GET /get-one-disability/:id method", async () => {
      const resId = await request(app).get("/get-disability");
      const res = await request(app).get(
        `/get-one-disability/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-disability/:id", () => {
    it("It should response 200 for PATCH /update-disability/:id method", async () => {
      const resId = await request(app).get("/get-disability");
      const res = await request(app)
        .patch(`/update-disability/${resId.body[0]._id}`)
        .send({
          disability: "TEST Disability",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-disability/:id", () => {
    it("It should response 200 for DELETE /delete-disability/:id method", async () => {
      const resId = await request(app).get("/get-disability");
      const res = await request(app).delete(
        `/delete-disability/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
