import { app } from "../../app";
import request from "supertest";

describe("All Attach Medium Codes Routers", () => {
  describe("POST /create-attachMediumCodes", () => {
    it("It should response 200 for POST /create-attachMediumCodes method", async () => {
      const res = await request(app).post("/create-attachMediumCodes").send({
        selectLanguageMedium: "Select Language Medium",
        addCode: "Add Code",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-attachMediumCodes", () => {
    it("It should response 200 for GET /get-attachMediumCodes method", async () => {
      const res = await request(app).get("/get-attachMediumCodes");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-attachMediumCodes/:id", () => {
    it("It should response 200 for GET /get-one-attachMediumCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachMediumCodes");
      const res = await request(app).get(
        `/get-one-attachMediumCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-attachMediumCodes/:id", () => {
    it("It should response 200 for PATCH /update-attachMediumCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachMediumCodes");
      const res = await request(app)
        .patch(`/update-attachMediumCodes/${resId.body[0]._id}`)
        .send({
          selectLanguageMedium: "TEST Select Language Medium",
          addCode: "TEST Add Code",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-attachMediumCodes/:id", () => {
    it("It should response 200 for DELETE /delete-attachMediumCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachMediumCodes");
      const res = await request(app).delete(
        `/delete-attachMediumCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
