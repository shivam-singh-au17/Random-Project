import { app } from "../../app";
import request from "supertest";

describe("All Fee Structure Codes Routers", () => {
  describe("POST /create-feeStructureCodes", () => {
    it("It should response 200 for POST /create-feeStructureCodes method", async () => {
      const res = await request(app)
        .post("/create-feeStructureCodes")
        .send({
          name: "Name",
          collegeType: "College Type",
          aidedType: "Aided Type",
          programName: "626fd9c87ad5be525d8c8506",
          departmentName: "626fd9c87ad5be525d8c8506",
          bankAccount: "626fd9c87ad5be525d8c8506",
          yearAppliedFor: "FY",
          selectHeads: [
            {
              selectedHeads: "626fd9c87ad5be525d8c8506",
              amount: 100,
            },
          ],
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-feeStructureCodes", () => {
    it("It should response 200 for GET /get-feeStructureCodes method", async () => {
      const res = await request(app).get("/get-feeStructureCodes");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-feeStructureCodes/:id", () => {
    it("It should response 200 for GET /get-one-feeStructureCodes/:id method", async () => {
      const resId = await request(app).get("/get-feeStructureCodes");
      const res = await request(app).get(
        `/get-one-feeStructureCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-feeStructureCodes/:id", () => {
    it("It should response 200 for PATCH /update-feeStructureCodes/:id method", async () => {
      const resId = await request(app).get("/get-feeStructureCodes");
      const res = await request(app)
        .patch(`/update-feeStructureCodes/${resId.body[0]._id}`)
        .send({
          name: "TEST Name",
          collegeType: "TEST College Type",
          aidedType: "TEST Aided Type",
          programName: "626fd9c87ad5be525d8c8506",
          departmentName: "626fd9c87ad5be525d8c8506",
          bankAccount: "626fd9c87ad5be525d8c8506",
          yearAppliedFor: "FY",
          selectHeads: [
            {
              selectedHeads: "626fd9c87ad5be525d8c8506",
              amount: 1000,
            },
          ],
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-feeStructureCodes/:id", () => {
    it("It should response 200 for DELETE /delete-feeStructureCodes/:id method", async () => {
      const resId = await request(app).get("/get-feeStructureCodes");
      const res = await request(app).delete(
        `/delete-feeStructureCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
