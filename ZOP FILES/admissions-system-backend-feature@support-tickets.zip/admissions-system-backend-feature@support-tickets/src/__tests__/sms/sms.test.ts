import { app } from "../../app";
import request from "supertest";

describe("All SMS Routers", () => {
  describe("POST /create-sms", () => {
    it("It should response 200 for POST /create-sms method", async () => {
      const res = await request(app).post("/create-sms").send({
        addUrl: "Add Url",
        addNumber: "Add Number",
        user: "User",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-sms", () => {
    it("It should response 200 for GET /get-sms method", async () => {
      const res = await request(app).get("/get-sms");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-sms/:id", () => {
    it("It should response 200 for GET /get-one-sms/:id method", async () => {
      const resId = await request(app).get("/get-sms");
      const res = await request(app).get(
        `/get-one-sms/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-sms/:id", () => {
    it("It should response 200 for PATCH /update-sms/:id method", async () => {
      const resId = await request(app).get("/get-sms");
      const res = await request(app)
        .patch(`/update-sms/${resId.body[0]._id}`)
        .send({
          addUrl: "TEST Add Url",
          addNumber: "TEST Add Number",
          user: "TEST User",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-sms/:id", () => {
    it("It should response 200 for DELETE /delete-sms/:id method", async () => {
      const resId = await request(app).get("/get-sms");
      const res = await request(app).delete(
        `/delete-sms/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
