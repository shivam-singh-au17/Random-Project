import { app } from "../../app";
import request from "supertest";

describe("All Bank Account Routers", () => {
  describe("POST /create-bankAccount", () => {
    it("It should response 200 for POST /create-bankAccount method", async () => {
      const res = await request(app).post("/create-bankAccount").send({
        bankName: "Bank Name",
        branch: "Branch",
        bankAddress: "Bank Address",
        ifscCode: "IFSC Code",
        accountNo: "Account No",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-bankAccount", () => {
    it("It should response 200 for GET /get-bankAccount method", async () => {
      const res = await request(app).get("/get-bankAccount");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-bankAccount/:id", () => {
    it("It should response 200 for GET /get-one-bankAccount/:id method", async () => {
      const resId = await request(app).get("/get-bankAccount");
      const res = await request(app).get(
        `/get-one-bankAccount/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-bankAccount/:id", () => {
    it("It should response 200 for PATCH /update-bankAccount/:id method", async () => {
      const resId = await request(app).get("/get-bankAccount");
      const res = await request(app)
        .patch(`/update-bankAccount/${resId.body[0]._id}`)
        .send({
          bankName: "TEST Bank Name",
          branch: "TEST Branch",
          bankAddress: "TEST Bank Address",
          ifscCode: "TEST IFSC Code",
          accountNo: "TEST Account No",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-bankAccount/:id", () => {
    it("It should response 200 for DELETE /delete-bankAccount/:id method", async () => {
      const resId = await request(app).get("/get-bankAccount");
      const res = await request(app).delete(
        `/delete-bankAccount/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
