import { app } from "../../app";
import request from "supertest";

describe("All Attach Department Codes Routers", () => {
  describe("POST /create-attachDepartmentCodes", () => {
    it("It should response 200 for POST /create-attachDepartmentCodes method", async () => {
      const res = await request(app)
        .post("/create-attachDepartmentCodes")
        .send({
          selectDepartmentName: "Select Department Name",
          addCode: "Add Code",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-attachDepartmentCodes", () => {
    it("It should response 200 for GET /get-attachDepartmentCodes method", async () => {
      const res = await request(app).get("/get-attachDepartmentCodes");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-attachDepartmentCodes/:id", () => {
    it("It should response 200 for GET /get-one-attachDepartmentCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachDepartmentCodes");
      const res = await request(app).get(
        `/get-one-attachDepartmentCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-attachDepartmentCodes/:id", () => {
    it("It should response 200 for PATCH /update-attachDepartmentCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachDepartmentCodes");
      const res = await request(app)
        .patch(`/update-attachDepartmentCodes/${resId.body[0]._id}`)
        .send({
          selectDepartmentName: "TEST Select Department Name",
          addCode: "TEST Add Code",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-attachDepartmentCodes/:id", () => {
    it("It should response 200 for DELETE /delete-attachDepartmentCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachDepartmentCodes");
      const res = await request(app).delete(
        `/delete-attachDepartmentCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
