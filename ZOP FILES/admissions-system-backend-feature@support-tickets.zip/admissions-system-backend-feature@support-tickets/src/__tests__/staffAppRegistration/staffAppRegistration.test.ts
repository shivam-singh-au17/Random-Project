import { app } from "../../app";
import request from "supertest";

const testForm = {
  firstName: "Ramesh",
  lastName: "Prasad",
  email: "rameshprasad@gmail.com",
  password: "Ramesh@123",
};

describe("All Staff App Registration Routers", () => {
  describe("POST /staff-registration", () => {
    it("It should response 200 for POST /staff-registration method if USER not exists", async () => {
      const res = await request(app).post("/staff-registration").send(testForm);
      expect(res.statusCode).toEqual(200);
    });

    it("It should response 400 for POST /staff-registration method if USER already exists", async () => {
      const res = await request(app).post("/staff-registration").send(testForm);
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "User already exists",
      });
    });
  });

  describe("POST /staff-login", () => {
    it("It should response 400 for POST /staff-login method if EMAIL not registered", async () => {
      const res = await request(app).post("/staff-login").send({
        email: "rames@gmail.com",
        password: "Ramesh@123",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "You are not registered so register first",
      });
    });

    it("It should response 400 for POST /staff-login method if PASSWORD is wrong", async () => {
      const res = await request(app).post("/staff-login").send({
        email: "rameshprasad@gmail.com",
        password: "Rame@123",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "Wrong Password or Email... Try again",
      });
    });

    it("It should response 200 for POST /staff-login method if PASSWORD & EMAIL is correct", async () => {
      const res = await request(app).post("/staff-login").send({
        email: "rameshprasad@gmail.com",
        password: "Ramesh@123",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /staff-reset-password", () => {
    it("It should response 400 for PATCH /staff-reset-password method if EMAIL not registered", async () => {
      const res = await request(app).patch("/staff-reset-password").send({
        email: "rameshprasa@gmail.com",
        currentPassword: "Ramesh@123",
        newPassword: "Ramesh@12345",
        confirmPassword: "Ramesh@12345",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "This email is not registered",
      });
    });

    it("It should response 400 for PATCH /staff-reset-password method if CURRENT PASSWORD is wrong", async () => {
      const res = await request(app).patch("/staff-reset-password").send({
        email: "rameshprasad@gmail.com",
        currentPassword: "Rmesh@123",
        newPassword: "Ramesh@12345",
        confirmPassword: "Ramesh@12345",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "error",
        message: "Wrong Current Password... try again",
      });
    });

    it("It should response 200 for PATCH /staff-reset-password method if CURRENT PASSWORD & EMAIL is correct", async () => {
      const res = await request(app).patch("/staff-reset-password").send({
        email: "rameshprasad@gmail.com",
        currentPassword: "Ramesh@123",
        newPassword: "Ramesh@12345",
        confirmPassword: "Ramesh@12345",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /staff-get-registrations", () => {
    it("It should response 200 for GET /staff-get-registrations method", async () => {
      const res = await request(app).get("/staff-get-registrations");
      expect(res.statusCode).toEqual(200);
    });
  });
});
