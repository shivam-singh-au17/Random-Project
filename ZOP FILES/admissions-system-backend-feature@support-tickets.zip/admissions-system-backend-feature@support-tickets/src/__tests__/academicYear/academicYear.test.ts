import { app } from "../../app";
import request from "supertest";

describe("All Academic Year Routers", () => {
  describe("POST /create-academicYear", () => {
    it("It should response 200 for POST /create-academicYear method", async () => {
      const res = await request(app).post("/create-academicYear").send({
        academicYear: "2020-21",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-academicYear", () => {
    it("It should response 200 for GET /get-academicYear method", async () => {
      const res = await request(app).get("/get-academicYear");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-academicYear/:id", () => {
    it("It should response 200 for GET /get-one-academicYear/:id method", async () => {
      const resId = await request(app).get("/get-academicYear");
      const res = await request(app).get(
        `/get-one-academicYear/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-academicYear/:id", () => {
    it("It should response 200 for PATCH /update-academicYear/:id method", async () => {
      const resId = await request(app).get("/get-academicYear");
      const res = await request(app)
        .patch(`/update-academicYear/${resId.body[0]._id}`)
        .send({
          academicYear: "2022-23",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-academicYear/:id", () => {
    it("It should response 200 for DELETE /delete-academicYear/:id method", async () => {
      const resId = await request(app).get("/get-academicYear");
      const res = await request(app).delete(
        `/delete-academicYear/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
