import { app } from "../../app";
import request from "supertest";

describe("All Attach Program Codes Routers", () => {
  describe("POST /create-attachProgramCodes", () => {
    it("It should response 200 for POST /create-attachProgramCodes method", async () => {
      const res = await request(app).post("/create-attachProgramCodes").send({
        selectProgramName: "Select Program Name",
        addCode: "Add Code",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-attachProgramCodes", () => {
    it("It should response 200 for GET /get-attachProgramCodes method", async () => {
      const res = await request(app).get("/get-attachProgramCodes");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-attachProgramCodes/:id", () => {
    it("It should response 200 for GET /get-one-attachProgramCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachProgramCodes");
      const res = await request(app).get(
        `/get-one-attachProgramCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-attachProgramCodes/:id", () => {
    it("It should response 200 for PATCH /update-attachProgramCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachProgramCodes");
      const res = await request(app)
        .patch(`/update-attachProgramCodes/${resId.body[0]._id}`)
        .send({
          selectProgramName: "TEST Select Program Name",
          addCode: "TEST Add Code",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-attachProgramCodes/:id", () => {
    it("It should response 200 for DELETE /delete-attachProgramCodes/:id method", async () => {
      const resId = await request(app).get("/get-attachProgramCodes");
      const res = await request(app).delete(
        `/delete-attachProgramCodes/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
