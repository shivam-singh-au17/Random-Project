import { app } from "../../app";
import request from "supertest";

describe("All Martial Status Routers", () => {
  describe("POST /create-martialStatus", () => {
    it("It should response 200 for POST /create-martialStatus method", async () => {
      const res = await request(app).post("/create-martialStatus").send({
        addMartialStatus: "Add Martial Status",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-martialStatus", () => {
    it("It should response 200 for GET /get-martialStatus method", async () => {
      const res = await request(app).get("/get-martialStatus");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-martialStatus/:id", () => {
    it("It should response 200 for GET /get-one-martialStatus/:id method", async () => {
      const resId = await request(app).get("/get-martialStatus");
      const res = await request(app).get(
        `/get-one-martialStatus/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-martialStatus/:id", () => {
    it("It should response 200 for PATCH /update-martialStatus/:id method", async () => {
      const resId = await request(app).get("/get-martialStatus");
      const res = await request(app)
        .patch(`/update-martialStatus/${resId.body[0]._id}`)
        .send({
          addMartialStatus: "TEST Add Martial Status",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-martialStatus/:id", () => {
    it("It should response 200 for DELETE /delete-martialStatus/:id method", async () => {
      const resId = await request(app).get("/get-martialStatus");
      const res = await request(app).delete(
        `/delete-martialStatus/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
