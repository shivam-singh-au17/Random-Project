import { app } from "../../app";
import request from "supertest";

describe("All Setup Language Routers", () => {
  describe("POST /create-setupLanguage", () => {
    it("It should response 200 for POST /create-setupLanguage method", async () => {
      const res = await request(app).post("/create-setupLanguage").send({
        languageName: "Language Name",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-setupLanguage", () => {
    it("It should response 200 for GET /get-setupLanguage method", async () => {
      const res = await request(app).get("/get-setupLanguage");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-setupLanguage/:id", () => {
    it("It should response 200 for GET /get-one-setupLanguage/:id method", async () => {
      const resId = await request(app).get("/get-setupLanguage");
      const res = await request(app).get(
        `/get-one-setupLanguage/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-setupLanguage/:id", () => {
    it("It should response 200 for PATCH /update-setupLanguage/:id method", async () => {
      const resId = await request(app).get("/get-setupLanguage");
      const res = await request(app)
        .patch(`/update-setupLanguage/${resId.body[0]._id}`)
        .send({
          languageName: "TEST Language Name",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-setupLanguage/:id", () => {
    it("It should response 200 for DELETE /delete-setupLanguage/:id method", async () => {
      const resId = await request(app).get("/get-setupLanguage");
      const res = await request(app).delete(
        `/delete-setupLanguage/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
