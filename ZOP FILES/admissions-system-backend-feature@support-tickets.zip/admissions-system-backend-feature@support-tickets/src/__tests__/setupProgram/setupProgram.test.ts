import { app } from "../../app";
import request from "supertest";

describe("All Setup Program Routers", () => {
  describe("POST /create-setupProgram", () => {
    it("It should response 200 for POST /create-setupProgram method", async () => {
      const res = await request(app).post("/create-setupProgram").send({
        programFullName: "Program Full Name",
        programShortName: "Program Short Name",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-setupProgram", () => {
    it("It should response 200 for GET /get-setupProgram method", async () => {
      const res = await request(app).get("/get-setupProgram");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-setupProgram/:id", () => {
    it("It should response 200 for GET /get-one-setupProgram/:id method", async () => {
      const resId = await request(app).get("/get-setupProgram");
      const res = await request(app).get(
        `/get-one-setupProgram/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-setupProgram/:id", () => {
    it("It should response 200 for PATCH /update-setupProgram/:id method", async () => {
      const resId = await request(app).get("/get-setupProgram");
      const res = await request(app)
        .patch(`/update-setupProgram/${resId.body[0]._id}`)
        .send({
          programFullName: "TEST Program Full Name",
          programShortName: "TEST Program Short Name",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-setupProgram/:id", () => {
    it("It should response 200 for DELETE /delete-setupProgram/:id method", async () => {
      const resId = await request(app).get("/get-setupProgram");
      const res = await request(app).delete(
        `/delete-setupProgram/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
