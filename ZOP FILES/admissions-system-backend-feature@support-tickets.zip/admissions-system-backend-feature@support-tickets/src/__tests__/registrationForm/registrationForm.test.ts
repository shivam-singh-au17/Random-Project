import { app } from "../../app";
import request from "supertest";

const testForm = {
  firstName: "Subham",
  lastName: "Singh",
  email: "shivam.singh@develearn.in",
  password: "Subham@123",
};

describe("All Registration Form Routers", () => {
  describe("POST /registration", () => {
    it("It should response 200 for POST /registration method if USER not exists", async () => {
      const res = await request(app).post("/registration").send(testForm);
      expect(res.statusCode).toEqual(200);
    });

    it("It should response 400 for POST /registration method if USER already exists", async () => {
      const res = await request(app).post("/registration").send(testForm);
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "User already exists",
      });
    });
  });

  describe("POST /login", () => {
    it("It should response 400 for POST /login method if EMAIL not registered", async () => {
      const res = await request(app).post("/login").send({
        email: "shivam@gmail.com",
        password: "Subham@123",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "You are not registered so register first",
      });
    });

    it("It should response 400 for POST /login method if PASSWORD is wrong", async () => {
      const res = await request(app).post("/login").send({
        email: "shivam.singh@develearn.in",
        password: "Shiv@123",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "Wrong Password or Email... Try again",
      });
    });

    it("It should response 200 for POST /login method if PASSWORD & EMAIL is correct", async () => {
      const res = await request(app).post("/login").send({
        email: "shivam.singh@develearn.in",
        password: "Subham@123",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /reset-password", () => {
    it("It should response 400 for PATCH /reset-password method if EMAIL not registered", async () => {
      const res = await request(app).patch("/reset-password").send({
        email: "shivamsing@gmail.com",
        currentPassword: "Subham@123",
        newPassword: "Subham@12345",
        confirmPassword: "Subham@12345",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "Error",
        message: "This email is not registered",
      });
    });

    it("It should response 400 for PATCH /reset-password method if CURRENT PASSWORD is wrong", async () => {
      const res = await request(app).patch("/reset-password").send({
        email: "shivam.singh@develearn.in",
        currentPassword: "Sivam@123",
        newPassword: "Subham@12345",
        confirmPassword: "Subham@12345",
      });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        status: "error",
        message: "Wrong Current Password... try again",
      });
    });

    it("It should response 200 for PATCH /reset-password method if CURRENT PASSWORD & EMAIL is correct", async () => {
      const res = await request(app).patch("/reset-password").send({
        email: "shivam.singh@develearn.in",
        currentPassword: "Subham@123",
        newPassword: "Subham@12345",
        confirmPassword: "Subham@12345",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-registrations", () => {
    it("It should response 200 for GET /get-registrations method", async () => {
      const res = await request(app).get("/get-registrations");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-profile/:id", () => {
    it("It should response 400 for PATCH /update-profile/:id method if we want to update EMAIL", async () => {
      const resId = await request(app).get("/get-registrations");
      const res = await request(app)
        .patch(`/update-profile/${resId.body[0]._id}`)
        .send({
          email: "shivam.singh@develearn.in",
          firstName: "Ram",
          lastName: "Prasad",
          phoneNumber: "8823457899",
          picture:
            "https://www.pngfind.com/pngs/m/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.png",
          emailUpdates: true,
          smsUpdates: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        message: '"email" is not allowed',
      });
    });
      
    it("It should response 400 for PATCH /update-profile/:id method if we want to update PASSWORD", async () => {
      const resId = await request(app).get("/get-registrations");
      const res = await request(app)
        .patch(`/update-profile/${resId.body[0]._id}`)
        .send({
          password: "Subham@123",
          firstName: "Ram",
          lastName: "Prasad",
          phoneNumber: "8823457899",
          picture:
            "https://www.pngfind.com/pngs/m/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.png",
          emailUpdates: true,
          smsUpdates: true,
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body).toEqual({
        message: '"password" is not allowed',
      });
    });

    it("It should response 200 for PATCH /update-profile/:id method if we update only FIRSTNAME, LASTNAME, NUMBER & PICTURE", async () => {
      const resId = await request(app).get("/get-registrations");
      const res = await request(app)
        .patch(`/update-profile/${resId.body[0]._id}`)
        .send({
          firstName: "Ram",
          lastName: "Prasad",
          phoneNumber: "8823457899",
          picture:
            "https://www.pngfind.com/pngs/m/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.png",
          emailUpdates: true,
          smsUpdates: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });
});
