import { app } from "../../app";
import request from "supertest";

describe("All Setup Department Routers", () => {
  describe("POST /create-setupDepartment", () => {
    it("It should response 200 for POST /create-setupDepartment method", async () => {
      const res = await request(app).post("/create-setupDepartment").send({
        departmentName: "Department Name",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-setupDepartment", () => {
    it("It should response 200 for GET /get-setupDepartment method", async () => {
      const res = await request(app).get("/get-setupDepartment");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-setupDepartment/:id", () => {
    it("It should response 200 for GET /get-one-setupDepartment/:id method", async () => {
      const resId = await request(app).get("/get-setupDepartment");
      const res = await request(app).get(
        `/get-one-setupDepartment/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-setupDepartment/:id", () => {
    it("It should response 200 for PATCH /update-setupDepartment/:id method", async () => {
      const resId = await request(app).get("/get-setupDepartment");
      const res = await request(app)
        .patch(`/update-setupDepartment/${resId.body[0]._id}`)
        .send({
          departmentName: "TEST Department Name",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-setupDepartment/:id", () => {
    it("It should response 200 for DELETE /delete-setupDepartment/:id method", async () => {
      const resId = await request(app).get("/get-setupDepartment");
      const res = await request(app).delete(
        `/delete-setupDepartment/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
