import { app } from "../../app";
import request from "supertest";

describe("All Add Gender Routers", () => {
  describe("POST /create-addGender", () => {
    it("It should response 200 for POST /create-addGender method", async () => {
      const res = await request(app).post("/create-addGender").send({
        addGender: "Add Gender",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-addGender", () => {
    it("It should response 200 for GET /get-addGender method", async () => {
      const res = await request(app).get("/get-addGender");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-addGender/:id", () => {
    it("It should response 200 for GET /get-one-addGender/:id method", async () => {
      const resId = await request(app).get("/get-addGender");
      const res = await request(app).get(
        `/get-one-addGender/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-addGender/:id", () => {
    it("It should response 200 for PATCH /update-addGender/:id method", async () => {
      const resId = await request(app).get("/get-addGender");
      const res = await request(app)
        .patch(`/update-addGender/${resId.body[0]._id}`)
        .send({
          addGender: "TEST Add Gender",
          status: true,
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-addGender/:id", () => {
    it("It should response 200 for DELETE /delete-addGender/:id method", async () => {
      const resId = await request(app).get("/get-addGender");
      const res = await request(app).delete(
        `/delete-addGender/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
