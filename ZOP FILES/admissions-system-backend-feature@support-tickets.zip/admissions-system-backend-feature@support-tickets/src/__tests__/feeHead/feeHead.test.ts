import { app } from "../../app";
import request from "supertest";

describe("All Fee Head Routers", () => {
  describe("POST /create-feeHead", () => {
    it("It should response 200 for POST /create-feeHead method", async () => {
      const res = await request(app).post("/create-feeHead").send({
        feeHeadName: "TEST BY SHIVAM",
      });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-feeHead", () => {
    it("It should response 200 for GET /get-feeHead method", async () => {
      const res = await request(app).get("/get-feeHead");
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("GET /get-one-feeHead/:id", () => {
    it("It should response 200 for GET /get-one-feeHead/:id method", async () => {
      const resId = await request(app).get("/get-feeHead");
      const res = await request(app).get(
        `/get-one-feeHead/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("PATCH /update-feeHead/:id", () => {
    it("It should response 200 for PATCH /update-feeHead/:id method", async () => {
      const resId = await request(app).get("/get-feeHead");
      const res = await request(app)
        .patch(`/update-feeHead/${resId.body[0]._id}`)
        .send({
          feeHeadName: "TEST Fee Head Name",
          priority: "TEST Priority",
          assignTo: "TEST Assign To",
        });
      expect(res.statusCode).toEqual(200);
    });
  });

  describe("DELETE /delete-feeHead/:id", () => {
    it("It should response 200 for DELETE /delete-feeHead/:id method", async () => {
      const resId = await request(app).get("/get-feeHead");
      const res = await request(app).delete(
        `/delete-feeHead/${resId.body[0]._id}`
      );
      expect(res.statusCode).toEqual(200);
    });
  });
});
