declare module "@southlane/cognito-jwt-verifier";
