
(function() {
    console.log('Abhishek');
})();