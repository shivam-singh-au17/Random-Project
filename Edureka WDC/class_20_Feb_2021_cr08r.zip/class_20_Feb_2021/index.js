
/****************** IIFE ************************/

// IIFE - Immediately Invoked Function Expressions

const abc = function() {
    // some code
    console.log("Abhishek");
}

// abc() in order to execute the function abc

(function() {
    // some code
    
    // MAKE API CALL to FETCH the DATA

    // you will see all the responses
})();


/************************* Query String *******************************/

// is used to transfer the information from one page to another using the URL

// https://learning.edureka.co/my-classroom/full-stack-web-development/coursecontent?courseId=1113&fromMasterCourse=0&batchId=19030

// after question mark the information is 
// courseId=1113&fromMasterCourse=0&batchId=19030
// ? <key=value> & <key=value> & <key=value>


/*************************** Object de-structuring **************************/

var obj = {
    name: "Abhishek",
    course: "Edureka",
    "my city": "Chandiagrh"
}

obj.name // Abhishek
obj["name"] // Abhishek

obj.my city // Error

obj["my city"] // Chandigarh

let { name, course } = obj; // object de-structuring



/************************ DOM ****************************/

// DOM - Document Object Model
// Tree like structure created by the browser for every HTML web page

/* 

HTML
    - Head
        - title
            - content (My page)
        - script
        - script
        - script
    - Body
        - button
        - div
            - span
            - div
*/

// get hold of the element from the DOM
var ele = document.getElementById("myDiv");

// playing with the attributes
ele.setAttribute("style", "color:red");

// change the contents of the element on the DOM
ele.innerHTML = "Welcome to Edureka !";


/******************* Form Validation ********************/
const formSubmitted = function() {
    const ele = document.getElementById("mobNum");
    const val = ele.value;
  
    // validate for 10 digits - India
    if (val.length != 10) {
      alert("Invalid mobile number");
    } else {
      alert("Valid mobile number")
    }
    
  }

/******************* Concise functions ******************/

let obj = {
    firstName: "Abhishek",
    course: "MERN stack",
    printName() {
        console.log("Edureka");
    }
}

obj.printName();


/******************* Spread operator ******************/

// is denoted by ... (tripple dot)

// in case of arrays

var array1 = ['a', 'b', 'c'];
var array2 = ['d', 'e', 'f'];

//array1 = array1.concat(array2);

array1 = [...array1, ...array2];

// in case of objects

var obj1 = {
    name1: "Abhishek",
    course1: "MERN Stack"
}

var obj2 = {
    name2: "Amit",
    course2: "Full Stack"
}

var obj3 = {
    ...obj1,
    ...obj2
}


// outputs

var array1 = ['a', 'b', 'c'];
var array2 = ['d', 'e', 'f'];

array1 = [...array1, ...array2];

let array3 = [1, 2, 3, ...array1, 4, 5, 6] 

console.log(array3) // [1, 2, 3, "a", "b", "c", "d", "e", "f", 4, 5, 6] 

var obj1 = {
  name1: "Abhishek",
  course1: "MERN Stack"
}

var obj2 = {
  name2: "Amit",
  course1: "Full Stack"
}

var obj3 = {
	printName: () => {},
    myName: "Edureka",
    ...obj1,
    ...obj2
}

console.log(obj3) 

/*
    {
        course1: "Full Stack",
        myName: "Edureka",
        name1: "Abhishek",
        name2: "Amit",
        printName: () => {}
    }
*/



/******************* Rest operator ******************/

// denoted by ... (tripple dot)


function sum(a, b, ...allParams) {

    console.log(allParams); // [30, 40, 50, 60, 70]

    let sumofAllParams = allParams.reduce((x, y) => {
        return x + y;
    })

    // reduce
    /*
    iteration 1: value 30 and 40 copied in x and y, retrun the sum as 70
    iteration 2: value 70 and 50 copied in x and y, retrun the sum as 120
    iteration 3: value 120 and 60 copied in x and y, retrun the sum as 180
    iteration 4: value 180 and 70 copied in x and y, retrun the sum as 250
    */

    console.log("Sum of all params " + sumofAllParams); // "Sum of all params 250"
    return a + b + sumofAllParams;
}
  
//sum(10, 20);

//sum(10,20,30,40,50);
console.log(sum(10, 20, 30, 40, 50, 60, 70)); // 280
  


