
(function() {
    console.log('AMIT');
})();